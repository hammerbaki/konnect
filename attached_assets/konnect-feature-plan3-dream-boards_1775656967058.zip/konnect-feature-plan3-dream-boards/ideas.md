# Konnect 디자인 브레인스토밍

## 프로젝트 맥락
대한민국 고3 대상 인터랙티브 입시 상담 플랫폼. 퀴즈, AI 챗봇 상담, 밸런스 게임, 커뮤니티 등 다양한 상호작용 기능을 제공.

---

<response>
<text>

## Idea 1: "네온 아케이드" — Retro-Futurism 게이미피케이션

**Design Movement**: 레트로 퓨처리즘 + 아케이드 게임 미학

**Core Principles**:
1. 입시를 '게임'처럼 — 스테이지 클리어 감각의 진행 구조
2. 네온 사인 + 다크 배경으로 밤늦게 공부하는 고3의 감성 반영
3. 픽셀 아트와 모던 UI의 하이브리드

**Color Philosophy**: 딥 네이비(#0A0E27) 배경 위에 시안(#00F5FF), 마젠타(#FF00FF), 라임(#39FF14) 네온 악센트. 밤새 공부하는 고3의 모니터 빛을 연상.

**Layout Paradigm**: 카드 기반 대시보드 + 사이드 네비게이션. 각 기능이 '게임 스테이지'처럼 배치.

**Signature Elements**: 글로우 이펙트 버튼, 프로그레스 바가 XP 게이지처럼 동작, 8비트 사운드 피드백

**Interaction Philosophy**: 모든 액션에 즉각적 시각 피드백 (포인트 획득 시 파티클 이펙트)

**Animation**: 네온 깜빡임, 글리치 트랜지션, 타이핑 이펙트

**Typography System**: "Press Start 2P" (제목) + "Pretendard" (본문) — 레트로와 가독성의 균형

</text>
<probability>0.05</probability>
</response>

---

<response>
<text>

## Idea 2: "캠퍼스 브리즈" — Organic Modernism

**Design Movement**: 오가닉 모더니즘 + 스칸디나비안 미니멀리즘

**Core Principles**:
1. 따뜻하고 안정감 있는 톤으로 입시 스트레스 완화
2. 유기적 곡선과 부드러운 그라데이션으로 친근함 전달
3. 여백의 미 — 정보 과부하 방지, 호흡 있는 레이아웃

**Color Philosophy**: 크림 화이트(#FEFCF3) 베이스에 테라코타(#C4704B), 세이지 그린(#8B9E7C), 소프트 코랄(#F4A896) 조합. 캠퍼스의 가을 풍경에서 영감. 따뜻하지만 세련된 느낌.

**Layout Paradigm**: 비대칭 그리드 + 풀 블리드 섹션. 좌측 고정 사이드바 + 우측 콘텐츠 영역. 카드들이 유기적으로 흐르는 매거진 스타일.

**Signature Elements**: 물결 모양 섹션 디바이더, 손글씨 느낌의 하이라이트 언더라인, 둥근 아바타와 소프트 그림자

**Interaction Philosophy**: 부드럽고 자연스러운 전환. 호버 시 카드가 살짝 떠오르며 그림자 확장. 스크롤에 따른 패럴랙스.

**Animation**: 스프링 기반 마이크로 인터랙션, 페이드인 + 슬라이드업 엔트런스, 부드러운 모달 트랜지션

**Typography System**: "Gowun Batang" (제목, 한글 세리프) + "Pretendard" (본문) — 전통과 현대의 조화

</text>
<probability>0.08</probability>
</response>

---

<response>
<text>

## Idea 3: "시그널" — Neo-Brutalism meets Gen-Z Energy

**Design Movement**: 네오 브루탈리즘 + Z세대 그래픽 트렌드

**Core Principles**:
1. 대담한 컬러 블록과 두꺼운 보더로 시선 집중
2. 스티커/태그 UI로 Z세대 감성 반영 (인스타 스토리, 틱톡 에디터 느낌)
3. 정보의 계층을 극단적 크기 대비로 표현

**Color Philosophy**: 순백(#FFFFFF) 베이스에 일렉트릭 블루(#2563EB), 핫 옐로우(#FACC15), 비비드 레드(#EF4444), 차콜(#1E1E1E) 조합. 교과서 위 형광펜 하이라이트에서 영감. 에너지 넘치지만 정돈된 느낌.

**Layout Paradigm**: 카드 스택 + 탭 네비게이션. 하단 네비게이션 바(모바일 앱 느낌). 콘텐츠가 스티커처럼 겹쳐지는 레이어드 구조.

**Signature Elements**: 3px 솔리드 블랙 보더, 4px 오프셋 드롭 섀도우, 라벨/태그 형태의 카테고리 뱃지, 회전된 텍스트 악센트

**Interaction Philosophy**: 즉각적이고 촉각적인 피드백. 클릭 시 버튼이 눌리는 느낌(translateY + 그림자 제거). 드래그 가능한 카드.

**Animation**: 바운스 이펙트, 스냅 트랜지션, 카운트업 숫자 애니메이션, 셰이크 피드백

**Typography System**: "Black Han Sans" (제목, 임팩트) + "Pretendard" (본문) — 대담함과 가독성

</text>
<probability>0.07</probability>
</response>
