# Konnect v2 디자인 브레인스토밍

커뮤니티 중심 + AI 콘텐츠 + 마켓플레이스 + 크레딧 시스템을 갖춘 입시 플랫폼

---

<response>
<text>
## Idea 1: "디지털 캠퍼스" — Academic Modernism

### Design Movement
학술적 모더니즘과 대학 캠퍼스의 정돈된 미학을 결합. 오르비의 기능성은 유지하되, 더 세련되고 체계적인 학술 플랫폼 느낌.

### Core Principles
1. **정보 밀도 최적화**: 오르비처럼 많은 정보를 담되, 시각적 위계를 명확히
2. **학술적 신뢰감**: 대학교 포털 사이트의 권위감 + 현대적 UI
3. **기능적 아름다움**: 장식보다 기능이 디자인을 이끄는 구조
4. **일관된 그리드 시스템**: 12컬럼 그리드 기반 정밀한 레이아웃

### Color Philosophy
- Primary: Deep Navy (#1B2A4A) — 학술적 권위와 신뢰
- Secondary: Warm Gold (#D4A843) — 크레딧/보상의 가치감
- Accent: Teal (#2BBFBF) — AI 기능의 혁신성
- Surface: Warm Gray (#F7F5F2) — 종이 질감의 따뜻함

### Layout Paradigm
좌측 고정 사이드바(카테고리) + 중앙 피드 + 우측 위젯(크레딧, 인기글, 마켓)의 3컬럼 구조. 오르비와 유사하지만 더 넓은 여백과 카드 기반.

### Signature Elements
1. 대학 노트 느낌의 밑줄 강조 텍스트
2. 학위증/인증서 느낌의 크레딧 카드

### Interaction Philosophy
호버 시 부드러운 언더라인 확장, 클릭 시 잉크 번짐 효과

### Animation
페이지 전환 시 책 넘기는 듯한 슬라이드, 카드 등장 시 아래에서 위로 부드럽게

### Typography System
- 제목: Noto Serif KR (학술적 권위)
- 본문: Pretendard (가독성)
</text>
<probability>0.07</probability>
</response>

<response>
<text>
## Idea 2: "시그널 v2" — Neo-Brutalism Community Edition

### Design Movement
기존 Konnect의 네오 브루탈리즘을 커뮤니티 플랫폼에 맞게 진화. 두꺼운 보더와 대담한 컬러 블록을 유지하되, 정보 밀도가 높은 커뮤니티 UI에 최적화.

### Core Principles
1. **대담한 구조**: 두꺼운 보더와 오프셋 그림자로 각 영역을 명확히 구분
2. **컬러 코딩**: 카테고리별 고유 컬러로 즉각적 인식
3. **스티커 문화**: Z세대의 꾸미기 문화를 UI에 반영
4. **촉각적 피드백**: 클릭 시 눌리는 버튼, 바운스 효과

### Color Philosophy
- Primary: Electric Blue (#2563EB) — 핵심 액션
- Credit Gold: (#FACC15) — 크레딧/보상
- Market Red: (#EF4444) — 마켓플레이스
- AI Teal: (#06B6D4) — AI 콘텐츠
- Community Green: (#22C55E) — 커뮤니티

### Layout Paradigm
좌측 아이콘 사이드바(접이식) + 중앙 피드 + 우측 크레딧 위젯. 모바일에서는 하단 탭 바.

### Signature Elements
1. 스티커형 태그/배지 시스템
2. 크레딧 코인 아이콘과 애니메이션

### Interaction Philosophy
버튼 누름 효과(translate + shadow 변화), 카드 호버 시 살짝 들어올림

### Animation
카드 등장 시 스프링 바운스, 크레딧 획득 시 코인 떨어지는 효과

### Typography System
- 제목: Black Han Sans (대담함)
- 본문: Pretendard (가독성)
</text>
<probability>0.05</probability>
</response>

<response>
<text>
## Idea 3: "인크웰" — Editorial Ink & Paper

### Design Movement
에디토리얼 디자인과 활자 인쇄의 미학. 신문/잡지 레이아웃에서 영감받은 타이포그래피 중심 디자인. 정보의 위계를 활자 크기와 굵기로 표현.

### Core Principles
1. **타이포그래피 우선**: 글자 자체가 디자인의 핵심 요소
2. **흑백 대비**: 모노크롬 베이스에 포인트 컬러 최소 사용
3. **칼럼 레이아웃**: 신문의 다단 편집을 웹에 적용
4. **여백의 미**: 넓은 여백으로 콘텐츠에 집중

### Color Philosophy
- Base: Pure Black (#0A0A0A) + Off-White (#FAFAF8)
- Accent: Vermillion Red (#E63946) — 핫 콘텐츠, 알림
- Credit: Antique Gold (#C9A84C) — 크레딧 시스템
- AI: Deep Indigo (#4338CA) — AI 기능

### Layout Paradigm
신문 편집 스타일의 비대칭 다단 레이아웃. 메인 피드는 넓은 1단, 사이드는 좁은 2단. 섹션 구분은 가는 수평선.

### Signature Elements
1. 드롭캡(첫 글자 크게) 스타일의 게시글 미리보기
2. 활자 인쇄 느낌의 구분선과 장식

### Interaction Philosophy
호버 시 텍스트 밑줄 애니메이션, 클릭 시 잉크 스탬프 효과

### Animation
텍스트 타이핑 효과, 페이지 전환 시 페이드 인/아웃

### Typography System
- 제목: Nanum Myeongjo (전통적 권위)
- 본문: Pretendard (현대적 가독성)
- 강조: Playfair Display (에디토리얼 감성)
</text>
<probability>0.04</probability>
</response>

---

## 선택: Idea 3 — "인크웰" (Editorial Ink & Paper)

오르비와의 차별화를 극대화하기 위해 에디토리얼 디자인을 선택. 오르비가 전형적인 커뮤니티 UI라면, Konnect는 잡지/신문 편집 스타일로 콘텐츠의 품격을 높인다. 흑백 모노크롬 베이스에 포인트 컬러를 최소한으로 사용하여 정보 과부하를 방지하고, 타이포그래피 위계로 콘텐츠 중요도를 직관적으로 전달한다.
