/*
 * Konnect v3 — "꿈을 잇다"
 * Design: Inkwell Editorial + Dream Upgrade + 3안 꿈 보드
 * Nav: 꿈 / 꿈 보드 / 여정 / 이야기 / 도구 / 성장
 * PC: Fixed left sidebar + top bar
 * Mobile: Top header + bottom tab bar
 */
import { useLocation, Link } from "wouter";
import {
  Home,
  Sparkles,
  Compass,
  MessageCircleHeart,
  Wrench,
  TrendingUp,
  PenLine,
  Menu,
  X,
  Bell,
  Search,
  ChevronRight,
  Coins,
  Star,
  GraduationCap,
  BookOpen,
  Monitor,
  MapPin,
  ShoppingBag,
  Heart,
  Sunrise,
  LayoutGrid,
  Brain,
  FileEdit,
  Mic,
  ClipboardCheck,
} from "lucide-react";
import { ReactNode, useState, useMemo } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { toast } from "sonner";

/* v3 + 3안 Sidebar nav — 꿈 보드 추가 */
const sidebarGroups = [
  {
    label: "꿈 Dream",
    items: [
      { path: "/dream", icon: Star, label: "꿈 선언" },
      { path: "/boards", icon: LayoutGrid, label: "꿈 보드" },
      { path: "/explore", icon: Compass, label: "대학·학과 탐색" },
      { path: "/career", icon: GraduationCap, label: "직업 인사이트" },
      { path: "/aptitude", icon: Brain, label: "AI 적성 분석" },
      { path: "/diagnosis", icon: ClipboardCheck, label: "자기진단 & 평가" },
    ],
  },
  {
    label: "다시, 잇다",
    accent: true,
    items: [
      { path: "/reconnect", icon: Sunrise, label: "다시, 잇다" },
    ],
  },
  {
    label: "여정 Journey",
    items: [
      { path: "/journey", icon: TrendingUp, label: "나의 로드맵" },
      { path: "/growth", icon: Sparkles, label: "성장 대시보드" },
    ],
  },
  {
    label: "이야기 Stories",
    items: [
      { path: "/stories", icon: MessageCircleHeart, label: "스토리 스트림" },
      { path: "/write", icon: PenLine, label: "이야기 쓰기" },
    ],
  },
  {
    label: "AI 도구 (Premium)",
    premium: true,
    items: [
      { path: "/tools/document", icon: FileEdit, label: "AI 서류 도구" },
      { path: "/tools/interview", icon: Mic, label: "AI 면접 시뮬레이터" },
      { path: "/tools/ai-explore", icon: Compass, label: "AI 탐색 엔진" },
      { path: "/pricing", icon: Star, label: "요금제 안내" },
    ],
  },
  {
    label: "도구 Tools",
    items: [
      { path: "/lectures", icon: Monitor, label: "인강 비교" },
      { path: "/workbooks", icon: BookOpen, label: "문제집 리뷰" },
      { path: "/academies", icon: MapPin, label: "학원 찾기" },
      { path: "/market", icon: ShoppingBag, label: "마켓" },
    ],
  },
];

/* Mobile bottom nav — 5 core items (꿈 보드 추가) */
const mobileNavItems = [
  { path: "/", icon: Home, label: "홈" },
  { path: "/dream", icon: Star, label: "꿈" },
  { path: "/boards", icon: LayoutGrid, label: "보드" },
  { path: "/reconnect", icon: Sunrise, label: "다시, 잇다", accent: true },
  { path: "/growth", icon: TrendingUp, label: "성장" },
];

function useDDay() {
  return useMemo(() => {
    const suneung = new Date("2026-11-12");
    const today = new Date();
    const diff = Math.ceil(
      (suneung.getTime() - today.getTime()) / (1000 * 60 * 60 * 24)
    );
    return diff > 0 ? diff : 0;
  }, []);
}

function getBreadcrumb(location: string): string {
  const map: Record<string, string> = {
    "/dream": "꿈 선언",
    "/boards": "꿈 보드",
    "/explore": "대학·학과 탐색",
    "/career": "직업 인사이트",
    "/aptitude": "AI 적성 분석",
    "/journey": "나의 로드맵",
    "/growth": "성장 대시보드",
    "/stories": "스토리 스트림",
    "/write": "이야기 쓰기",
    "/lectures": "인강 비교",
    "/workbooks": "문제집 리뷰",
    "/academies": "학원 찾기",
    "/market": "마켓",
    "/credits": "크레딧",
    "/community": "커뮤니티",
    "/ai": "AI 콘텐츠",
    "/reconnect": "다시, 잇다",
    "/tools/document": "AI 서류 도구",
    "/tools/interview": "AI 면접 시뮬레이터",
    "/tools/ai-explore": "AI 탐색 엔진",
    "/diagnosis": "자기진단 & 평가",
    "/pricing": "요금제 안내",
  };
  // Check for board detail routes
  if (location.startsWith("/boards/")) return "꿈 보드";
  if (location.startsWith("/tools/")) return map[location] || "AI 도구";
  return map[location] || "";
}

export default function Layout({ children }: { children: ReactNode }) {
  const [location] = useLocation();
  const dDay = useDDay();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const isActive = (path: string) =>
    path === "/" ? location === "/" : location.startsWith(path);

  const breadcrumb = getBreadcrumb(location);

  return (
    <div className="min-h-screen bg-background">
      {/* ===== DESKTOP SIDEBAR (lg+) ===== */}
      <aside className="hidden lg:flex fixed left-0 top-0 bottom-0 w-60 bg-card border-r border-border flex-col z-50">
        {/* Logo */}
        <div className="h-14 flex items-center px-5 border-b border-border">
          <Link href="/">
            <span className="editorial-heading text-xl tracking-tight">
              <span className="text-dream">K</span>onnect
            </span>
          </Link>
          <span className="ml-2 text-[9px] font-semibold tracking-wider text-dream bg-dream/10 px-1.5 py-0.5 rounded-sm">
            3안
          </span>
        </div>

        {/* Dream Declaration Mini Card */}
        <div className="mx-4 mt-4 mb-1 p-3 dream-card">
          <p className="text-[10px] uppercase tracking-wider text-dream font-semibold mb-1">
            나의 꿈
          </p>
          <p className="text-sm font-semibold leading-snug">
            "서울대 의대에서 희귀질환을 연구하겠다"
          </p>
          <div className="flex items-center justify-between mt-2">
            <span className="text-[10px] text-muted-foreground">
              꿈 동료 312명
            </span>
            <span className="text-xs font-mono font-bold text-coral">
              D-{dDay}
            </span>
          </div>
        </div>

        {/* Home Link */}
        <div className="px-3 mt-2">
          <Link href="/">
            <span
              className={`flex items-center gap-2.5 px-3 py-2 text-sm rounded-md transition-all ${
                isActive("/")
                  ? "bg-dream text-white font-semibold"
                  : "text-muted-foreground hover:text-foreground hover:bg-secondary"
              }`}
            >
              <Home size={16} />
              홈
            </span>
          </Link>
        </div>

        {/* Nav Groups */}
        <nav className="flex-1 overflow-y-auto px-3 mt-2 space-y-4">
          {sidebarGroups.map((group) => (
            <div key={group.label}>
              <h4 className={`text-[10px] uppercase tracking-widest font-semibold px-3 mb-1.5 flex items-center gap-1.5 ${
                (group as any).accent ? "text-coral" : (group as any).premium ? "text-dream" : "text-muted-foreground"
              }`}>
                {group.label}
                {(group as any).premium && (
                  <span className="inline-flex items-center gap-0.5 px-1.5 py-0.5 bg-dream/10 text-dream text-[8px] font-bold rounded-full normal-case tracking-normal">
                    ★
                  </span>
                )}
              </h4>
              <div className="space-y-0.5">
                {group.items.map((item) => (
                  <Link key={item.path} href={item.path}>
                    <span
                      className={`flex items-center gap-2.5 px-3 py-2 text-sm rounded-md transition-all ${
                        isActive(item.path)
                          ? (group as any).accent
                            ? "bg-coral text-white font-semibold"
                            : "bg-dream text-white font-semibold"
                          : (group as any).accent
                            ? "text-coral hover:text-coral hover:bg-coral/10 font-medium"
                            : "text-muted-foreground hover:text-foreground hover:bg-secondary"
                      }`}
                    >
                      <item.icon size={16} />
                      {item.label}
                    </span>
                  </Link>
                ))}
              </div>
            </div>
          ))}
        </nav>

        {/* Sidebar Footer */}
        <div className="px-4 py-4 border-t border-border space-y-3">
          <div className="flex items-center justify-between">
            <div className="credit-badge text-xs">
              <Coins size={12} />
              <span>1,250 KNC</span>
            </div>
            <Link href="/credits">
              <span className="text-[10px] text-muted-foreground hover:text-foreground ink-link">
                관리 →
              </span>
            </Link>
          </div>
          <div
            className="flex items-center gap-2 p-2 bg-secondary/50 border border-border rounded-md cursor-pointer hover:bg-secondary transition-colors"
            onClick={() => toast.info("프로필 기능은 준비 중입니다")}
          >
            <div className="w-8 h-8 bg-dream/10 text-dream flex items-center justify-center text-xs font-bold rounded-full">
              K
            </div>
            <div className="flex-1">
              <p className="text-xs font-semibold">고3 사용자</p>
              <p className="text-[10px] text-muted-foreground">
                Lv.3 꿈의 탐험가
              </p>
            </div>
          </div>
        </div>
      </aside>

      {/* Desktop Top Bar */}
      <header className="hidden lg:flex fixed top-0 left-60 right-0 h-14 bg-background/95 backdrop-blur-sm border-b border-border z-40 items-center px-6">
        <div className="flex items-center gap-2 text-sm">
          <Link href="/">
            <span className="text-muted-foreground hover:text-foreground transition-colors">
              Konnect
            </span>
          </Link>
          {breadcrumb && (
            <>
              <ChevronRight size={12} className="text-muted-foreground" />
              <span className="font-semibold">{breadcrumb}</span>
            </>
          )}
        </div>
        <div className="ml-auto flex items-center gap-3">
          <div className="relative">
            <Search
              size={14}
              className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground"
            />
            <input
              type="text"
              placeholder="꿈, 대학, 인강, 문제집 검색..."
              className="pl-9 pr-4 py-1.5 text-sm border border-border bg-transparent rounded-md focus:border-dream outline-none transition-colors w-64"
              onFocus={() => toast.info("검색 기능은 준비 중입니다")}
            />
          </div>
          <button
            className="p-2 text-muted-foreground hover:text-foreground transition-colors relative"
            onClick={() => toast.info("알림 기능은 준비 중입니다")}
          >
            <Bell size={18} />
            <span className="absolute top-1 right-1 w-2 h-2 bg-coral rounded-full" />
          </button>
          <Link href="/write">
            <span className="flex items-center gap-1.5 px-4 py-1.5 text-sm bg-dream text-white hover:bg-dream/90 transition-colors font-medium rounded-md">
              <PenLine size={14} />
              글쓰기
            </span>
          </Link>
        </div>
      </header>

      {/* Desktop Main Content */}
      <div className="hidden lg:block pl-60 pt-14">
        <main className="min-h-[calc(100vh-3.5rem)]">{children}</main>
        <footer className="border-t border-border py-8">
          <div className="max-w-6xl mx-auto px-6">
            <div className="grid grid-cols-4 gap-8">
              <div>
                <span className="editorial-heading text-lg">
                  <span className="text-dream">K</span>onnect
                </span>
                <p className="text-xs text-muted-foreground mt-2 leading-relaxed">
                  꿈을 잇다.
                  <br />
                  너와 나의 꿈이 만나는 곳.
                </p>
              </div>
              <div>
                <h4 className="text-[10px] font-semibold tracking-widest uppercase mb-3 text-dream">
                  꿈 & 여정
                </h4>
                <div className="space-y-1.5">
                  {[
                    ["/dream", "꿈 선언"],
                    ["/boards", "꿈 보드"],
                    ["/explore", "대학·학과 탐색"],
                    ["/career", "직업 인사이트"],
                    ["/journey", "나의 로드맵"],
                    ["/reconnect", "다시, 잇다"],
                  ].map(([href, label]) => (
                    <Link key={href} href={href}>
                      <span className="text-xs text-muted-foreground hover:text-foreground ink-link block">
                        {label}
                      </span>
                    </Link>
                  ))}
                </div>
              </div>
              <div>
                <h4 className="text-[10px] font-semibold tracking-widest uppercase mb-3 text-coral">
                  이야기 & 응원
                </h4>
                <div className="space-y-1.5">
                  {[
                    ["/stories", "스토리 스트림"],
                    ["/write", "이야기 쓰기"],
                    ["/growth", "성장 대시보드"],
                  ].map(([href, label]) => (
                    <Link key={href} href={href}>
                      <span className="text-xs text-muted-foreground hover:text-foreground ink-link block">
                        {label}
                      </span>
                    </Link>
                  ))}
                </div>
              </div>
              <div>
                <h4 className="text-[10px] font-semibold tracking-widest uppercase mb-3 text-gold">
                  도구 & 성장
                </h4>
                <div className="space-y-1.5">
                  {[
                    ["/lectures", "인강 비교"],
                    ["/workbooks", "문제집 리뷰"],
                    ["/academies", "학원 찾기"],
                    ["/market", "마켓"],
                    ["/credits", "크레딧 (KNC)"],
                  ].map(([href, label]) => (
                    <Link key={href} href={href}>
                      <span className="text-xs text-muted-foreground hover:text-foreground ink-link block">
                        {label}
                      </span>
                    </Link>
                  ))}
                </div>
              </div>
            </div>
            <hr className="editorial-divider mt-6" />
            <p className="text-[10px] text-muted-foreground text-center">
              © 2026 Konnect — 꿈을 잇다. All rights reserved.
            </p>
          </div>
        </footer>
      </div>

      {/* ===== MOBILE LAYOUT ===== */}
      <header className="lg:hidden sticky top-0 z-50 bg-background/95 backdrop-blur-sm border-b border-border">
        <div className="flex items-center justify-between h-14 px-4">
          <div className="flex items-center gap-3">
            <button
              className="p-1"
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            >
              {mobileMenuOpen ? <X size={20} /> : <Menu size={20} />}
            </button>
            <Link href="/">
              <span className="editorial-heading text-xl tracking-tight">
                <span className="text-dream">K</span>onnect
              </span>
            </Link>
          </div>
          <div className="flex items-center gap-2">
            <span className="text-xs text-coral font-mono font-bold">
              D-{dDay}
            </span>
            <div className="credit-badge text-xs">
              <Coins size={12} />
              <span>1,250</span>
            </div>
          </div>
        </div>
      </header>

      {/* Mobile Slide-out Menu */}
      <AnimatePresence>
        {mobileMenuOpen && (
          <>
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 0.3 }}
              exit={{ opacity: 0 }}
              className="lg:hidden fixed inset-0 bg-black z-40"
              onClick={() => setMobileMenuOpen(false)}
            />
            <motion.div
              initial={{ x: "-100%" }}
              animate={{ x: 0 }}
              exit={{ x: "-100%" }}
              transition={{ type: "tween", duration: 0.25 }}
              className="lg:hidden fixed left-0 top-0 bottom-0 w-72 bg-background z-50 border-r border-border overflow-y-auto"
            >
              <div className="h-14 flex items-center justify-between px-5 border-b border-border">
                <span className="editorial-heading text-xl">
                  <span className="text-dream">K</span>onnect
                </span>
                <button onClick={() => setMobileMenuOpen(false)}>
                  <X size={20} />
                </button>
              </div>
              {/* Dream card in mobile menu */}
              <div className="mx-4 mt-4 mb-2 p-3 dream-card">
                <p className="text-[10px] uppercase tracking-wider text-dream font-semibold mb-1">
                  나의 꿈
                </p>
                <p className="text-sm font-semibold leading-snug">
                  "서울대 의대에서 희귀질환을 연구하겠다"
                </p>
              </div>
              <nav className="p-4 space-y-4">
                <Link href="/">
                  <span
                    onClick={() => setMobileMenuOpen(false)}
                    className={`flex items-center gap-2.5 px-3 py-2.5 text-sm rounded-md ${
                      isActive("/")
                        ? "bg-dream text-white font-semibold"
                        : "text-muted-foreground hover:text-foreground"
                    }`}
                  >
                    <Home size={16} />홈
                  </span>
                </Link>
                {sidebarGroups.map((group) => (
                  <div key={group.label}>
                    <h4 className={`text-[10px] uppercase tracking-widest font-semibold px-3 mb-1.5 flex items-center gap-1.5 ${
                      (group as any).accent ? "text-coral" : (group as any).premium ? "text-dream" : "text-muted-foreground"
                    }`}>
                      {group.label}
                      {(group as any).premium && (
                        <span className="inline-flex items-center gap-0.5 px-1.5 py-0.5 bg-dream/10 text-dream text-[8px] font-bold rounded-full normal-case tracking-normal">
                          ★
                        </span>
                      )}
                    </h4>
                    {group.items.map((item) => (
                      <Link key={item.path} href={item.path}>
                        <span
                          onClick={() => setMobileMenuOpen(false)}
                          className={`flex items-center gap-2.5 px-3 py-2.5 text-sm rounded-md ${
                            isActive(item.path)
                              ? (group as any).accent
                                ? "bg-coral text-white font-semibold"
                                : "bg-dream text-white font-semibold"
                              : (group as any).accent
                                ? "text-coral hover:text-coral hover:bg-coral/10 font-medium"
                                : "text-muted-foreground hover:text-foreground"
                          }`}
                        >
                          <item.icon size={16} />
                          {item.label}
                        </span>
                      </Link>
                    ))}
                  </div>
                ))}
              </nav>
            </motion.div>
          </>
        )}
      </AnimatePresence>

      {/* Mobile Main Content */}
      <div className="lg:hidden pb-16">
        <main>{children}</main>
      </div>

      {/* Mobile Bottom Tab Bar */}
      <nav className="lg:hidden fixed bottom-0 left-0 right-0 z-50 bg-background border-t border-border safe-area-pb">
        <div className="flex items-center justify-around h-14">
          {mobileNavItems.map((item) => (
            <Link key={item.path} href={item.path}>
              <span
                className={`flex flex-col items-center gap-0.5 px-2 py-1 transition-all ${
                  isActive(item.path)
                    ? (item as any).accent ? "text-coral" : "text-dream"
                    : "text-muted-foreground"
                }`}
              >
                <item.icon
                  size={20}
                  strokeWidth={isActive(item.path) ? 2.5 : 1.5}
                />
                <span className={`text-[10px] font-medium ${
                  (item as any).accent && !isActive(item.path) ? "text-coral/70" : ""
                }`}>{item.label}</span>
              </span>
            </Link>
          ))}
        </div>
      </nav>
    </div>
  );
}
