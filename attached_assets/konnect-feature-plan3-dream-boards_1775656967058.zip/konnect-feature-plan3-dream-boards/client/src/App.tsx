import { Toaster } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/NotFound";
import { Route, Switch } from "wouter";
import ErrorBoundary from "./components/ErrorBoundary";
import { ThemeProvider } from "./contexts/ThemeContext";
import Layout from "./components/Layout";
import Home from "./pages/Home";
import Community from "./pages/Community";
import PostDetail from "./pages/PostDetail";
import AIHub from "./pages/AIHub";
import Market from "./pages/Market";
import ProductDetail from "./pages/ProductDetail";
import Credits from "./pages/Credits";
import Write from "./pages/Write";
import Lectures from "./pages/Lectures";
import Workbooks from "./pages/Workbooks";
import Academies from "./pages/Academies";
import Dream from "./pages/Dream";
import Explore from "./pages/Explore";
import Career from "./pages/Career";
import Journey from "./pages/Journey";
import Growth from "./pages/Growth";
import Stories from "./pages/Stories";
import ReConnect from "./pages/ReConnect";
import DreamBoards from "./pages/DreamBoards";
import BoardDetail from "./pages/BoardDetail";
import Aptitude from "./pages/Aptitude";
import DocumentTool from "./pages/DocumentTool";
import InterviewSim from "./pages/InterviewSim";
import AIExplore from "./pages/AIExplore";
import SelfDiagnosis from "./pages/SelfDiagnosis";
import PricingPage from "./pages/PricingPage";

function Router() {
  return (
    <Layout>
      <Switch>
        <Route path="/" component={Home} />
        {/* 꿈 Dream */}
        <Route path="/dream" component={Dream} />
        <Route path="/explore" component={Explore} />
        <Route path="/career" component={Career} />
        <Route path="/aptitude" component={Aptitude} />
        {/* 3안 자기진단 (무료) + 요금제 */}
        <Route path="/diagnosis" component={SelfDiagnosis} />
        <Route path="/pricing" component={PricingPage} />
        {/* 3안 AI 도구 (보드 맥락화, Premium) */}
        <Route path="/tools/document" component={DocumentTool} />
        <Route path="/tools/interview" component={InterviewSim} />
        <Route path="/tools/ai-explore" component={AIExplore} />
        {/* 여정 Journey */}
        <Route path="/journey" component={Journey} />
        <Route path="/growth" component={Growth} />
        {/* 다시, 잇다 Re:Connect */}
        <Route path="/reconnect" component={ReConnect} />
        {/* 꿈 보드 (3안) */}
        <Route path="/boards" component={DreamBoards} />
        <Route path="/boards/:slug" component={BoardDetail} />
        <Route path="/boards/:slug/:id" component={PostDetail} />
        {/* 이야기 Stories */}
        <Route path="/stories" component={Stories} />
        <Route path="/write" component={Write} />
        {/* 도구 Tools */}
        <Route path="/lectures" component={Lectures} />
        <Route path="/workbooks" component={Workbooks} />
        <Route path="/academies" component={Academies} />
        <Route path="/market" component={Market} />
        <Route path="/market/:id" component={ProductDetail} />
        {/* 기타 — community → boards 리다이렉트 */}
        <Route path="/community" component={Community} />
        <Route path="/community/:id" component={PostDetail} />
        <Route path="/ai" component={AIHub} />
        <Route path="/credits" component={Credits} />
        <Route path="/404" component={NotFound} />
        <Route component={NotFound} />
      </Switch>
    </Layout>
  );
}

function App() {
  return (
    <ErrorBoundary>
      <ThemeProvider defaultTheme="light">
        <TooltipProvider>
          <Toaster />
          <Router />
        </TooltipProvider>
      </ThemeProvider>
    </ErrorBoundary>
  );
}

export default App;
