/*
 * 3안 PostDetail — 대댓글 2단 + 보드 연동
 * Design: Inkwell — Editorial Ink & Paper
 */
import { useState } from "react";
import { Link, useParams } from "wouter";
import { motion } from "framer-motion";
import {
  Heart,
  MessageSquare,
  Eye,
  ArrowLeft,
  Send,
  Share2,
  Bookmark,
  Coins,
  CornerDownRight,
  ChevronDown,
  ChevronUp,
} from "lucide-react";
import { toast } from "sonner";

type Reply = { author: string; text: string; time: string; likes: number };
type Comment = { author: string; text: string; time: string; likes: number; replies?: Reply[] };

const postData: Record<string, {
  title: string; author: string; category: string; content: string;
  likes: number; comments: Comment[]; views: number; time: string;
  creditReward: number; boardSlug?: string; boardName?: string;
  postType?: string;
}> = {
  "1": {
    title: "서울대 학종 세특 주제 추천 모음 — 2027학년도 대비",
    author: "서울대꿈나무",
    category: "학종",
    content: "올해 서울대 학종을 준비하면서 정리한 세특 주제들을 공유합니다.\n\n## 인문계열\n\n1. **국어**: 현대소설에 나타난 도시화와 소외의 양상 분석\n2. **사회**: 한국 사회의 세대 갈등과 디지털 미디어의 역할\n3. **역사**: 조선시대 과거제도와 현대 입시제도의 비교 연구\n\n## 자연계열\n\n1. **수학**: 미적분을 활용한 전염병 확산 모델링\n2. **과학**: 미세플라스틱이 해양 생태계에 미치는 영향 실험\n3. **생물**: CRISPR 유전자 가위 기술의 윤리적 쟁점\n\n각 주제별로 탐구 방향과 참고 자료도 함께 정리해두었으니, 댓글로 질문 남겨주시면 답변드리겠습니다!",
    likes: 234,
    views: 1820,
    time: "2시간 전",
    creditReward: 50,
    boardSlug: "snu",
    boardName: "서울대",
    postType: "정보",
    comments: [
      {
        author: "의대지망생",
        text: "자연계열 주제 정말 유용해요! 생물 쪽으로 세특 준비 중인데 참고하겠습니다.",
        time: "1시간 전",
        likes: 12,
        replies: [
          { author: "서울대꿈나무", text: "감사합니다! 생물 쪽은 CRISPR 주제가 요즘 트렌드예요.", time: "50분 전", likes: 5 },
          { author: "생물덕후", text: "저도 CRISPR로 세특 준비 중이에요. 같이 정보 공유해요!", time: "45분 전", likes: 3 },
        ],
      },
      {
        author: "문과탑",
        text: "인문계열 국어 주제 좋네요. 혹시 참고 도서 추천해주실 수 있나요?",
        time: "30분 전",
        likes: 8,
        replies: [
          { author: "서울대꿈나무", text: "'소설의 숲에서 길을 찾다' 추천합니다!", time: "25분 전", likes: 4 },
        ],
      },
      {
        author: "고3파이팅",
        text: "감사합니다! 세특 주제 고민 많았는데 도움이 됩니다.",
        time: "15분 전",
        likes: 5,
      },
    ],
  },
};

const defaultPost = {
  title: "게시글을 찾을 수 없습니다",
  author: "알 수 없음",
  category: "기타",
  content: "요청하신 게시글이 존재하지 않습니다.",
  likes: 0,
  views: 0,
  time: "",
  creditReward: 0,
  comments: [] as Comment[],
};

export default function PostDetail() {
  const params = useParams<{ id: string; slug?: string }>();
  const post = postData[params.id || ""] || defaultPost;
  const boardSlug = params.slug || post.boardSlug;
  const [liked, setLiked] = useState(false);
  const [saved, setSaved] = useState(false);
  const [commentText, setCommentText] = useState("");
  const [comments, setComments] = useState<Comment[]>(post.comments);
  const [replyingTo, setReplyingTo] = useState<number | null>(null);
  const [replyText, setReplyText] = useState("");
  const [expandedReplies, setExpandedReplies] = useState<Set<number>>(new Set());

  const backHref = boardSlug ? `/boards/${boardSlug}` : "/boards";
  const backLabel = boardSlug && post.boardName ? `${post.boardName} 보드로 돌아가기` : "꿈 보드로 돌아가기";

  const handleLike = () => {
    setLiked(!liked);
    toast.success(liked ? "좋아요를 취소했습니다" : "좋아요를 눌렀습니다");
  };

  const handleSave = () => {
    setSaved(!saved);
    toast.success(saved ? "저장을 취소했습니다" : "게시글을 저장했습니다");
  };

  const handleComment = () => {
    if (!commentText.trim()) return;
    setComments([...comments, { author: "나", text: commentText, time: "방금 전", likes: 0 }]);
    setCommentText("");
    toast.success("댓글이 등록되었습니다 (+5 KNC)");
  };

  const handleReply = (commentIdx: number) => {
    if (!replyText.trim()) return;
    const updated = [...comments];
    const target = updated[commentIdx];
    if (!target.replies) target.replies = [];
    target.replies.push({ author: "나", text: replyText, time: "방금 전", likes: 0 });
    setComments(updated);
    setReplyText("");
    setReplyingTo(null);
    setExpandedReplies((prev) => new Set(prev).add(commentIdx));
    toast.success("답글이 등록되었습니다 (+3 KNC)");
  };

  const toggleReplies = (idx: number) => {
    setExpandedReplies((prev) => {
      const next = new Set(prev);
      next.has(idx) ? next.delete(idx) : next.add(idx);
      return next;
    });
  };

  return (
    <div className="container py-6 max-w-3xl mx-auto">
      {/* Back */}
      <Link href={backHref}>
        <span className="inline-flex items-center gap-1 text-sm text-muted-foreground hover:text-foreground mb-4">
          <ArrowLeft size={14} /> {backLabel}
        </span>
      </Link>

      <hr className="editorial-divider-double" />

      {/* Article Header */}
      <motion.article initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}>
        <div className="flex items-center gap-2 mb-3">
          <span className="ink-tag text-[10px]">{post.postType || post.category}</span>
          {post.boardName && (
            <Link href={`/boards/${post.boardSlug}`}>
              <span className="text-[10px] text-dream hover:underline">{post.boardName} 보드</span>
            </Link>
          )}
          <span className="text-xs text-muted-foreground">{post.time}</span>
        </div>
        <h1 className="editorial-heading text-2xl md:text-3xl mb-4">{post.title}</h1>
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 bg-foreground text-background flex items-center justify-center text-xs font-bold">
              {post.author[0]}
            </div>
            <div>
              <p className="text-sm font-semibold">{post.author}</p>
              <div className="flex items-center gap-2 text-[10px] text-muted-foreground">
                <span className="flex items-center gap-0.5"><Eye size={10} /> {post.views}</span>
                <span className="flex items-center gap-0.5"><Heart size={10} /> {post.likes + (liked ? 1 : 0)}</span>
              </div>
            </div>
          </div>
          {post.creditReward > 0 && (
            <div className="credit-badge text-xs">
              <Coins size={12} />
              <span>+{post.creditReward} KNC</span>
            </div>
          )}
        </div>

        <hr className="editorial-divider-thick" />

        {/* Article Content */}
        <div className="prose prose-sm max-w-none mt-6 mb-8">
          {post.content.split("\n").map((line, i) => {
            if (line.startsWith("## ")) {
              return <h2 key={i} className="editorial-heading text-lg mt-6 mb-3">{line.replace("## ", "")}</h2>;
            }
            if (line.match(/^\d+\./)) {
              const parts = line.match(/^(\d+\.)\s\*\*(.*?)\*\*:\s(.*)$/);
              if (parts) {
                return (
                  <p key={i} className="ml-4 mb-2 text-sm leading-relaxed">
                    <span className="text-vermillion font-bold">{parts[1]}</span>{" "}
                    <strong>{parts[2]}</strong>: {parts[3]}
                  </p>
                );
              }
            }
            if (line.trim() === "") return <br key={i} />;
            return <p key={i} className="text-sm leading-relaxed mb-2">{line}</p>;
          })}
        </div>

        {/* Actions */}
        <div className="flex items-center gap-3 py-4 border-y border-border">
          <button
            onClick={handleLike}
            className={`flex items-center gap-1.5 px-3 py-1.5 text-sm transition-colors ${
              liked ? "text-vermillion font-semibold" : "text-muted-foreground hover:text-foreground"
            }`}
          >
            <Heart size={16} fill={liked ? "currentColor" : "none"} />
            좋아요 {post.likes + (liked ? 1 : 0)}
          </button>
          <button
            onClick={handleSave}
            className={`flex items-center gap-1.5 px-3 py-1.5 text-sm transition-colors ${
              saved ? "text-gold font-semibold" : "text-muted-foreground hover:text-foreground"
            }`}
          >
            <Bookmark size={16} fill={saved ? "currentColor" : "none"} />
            저장
          </button>
          <button
            onClick={() => toast.success("링크가 복사되었습니다")}
            className="flex items-center gap-1.5 px-3 py-1.5 text-sm text-muted-foreground hover:text-foreground"
          >
            <Share2 size={16} />
            공유
          </button>
        </div>
      </motion.article>

      {/* Comments */}
      <section className="mt-6">
        <h2 className="editorial-heading text-lg mb-4">댓글 {comments.length}</h2>
        <hr className="editorial-divider-thick mt-0" />

        {/* Comment Input */}
        <div className="flex gap-2 mb-6 mt-4">
          <input
            type="text"
            value={commentText}
            onChange={(e) => setCommentText(e.target.value)}
            onKeyDown={(e) => e.key === "Enter" && handleComment()}
            placeholder="댓글을 입력하세요..."
            className="flex-1 px-3 py-2 text-sm border border-border bg-transparent focus:border-foreground outline-none transition-colors"
          />
          <button
            onClick={handleComment}
            className="px-3 py-2 bg-foreground text-background hover:bg-foreground/90 transition-colors"
          >
            <Send size={16} />
          </button>
        </div>

        {/* Comment List with Replies */}
        <div className="space-y-0 divide-y divide-border">
          {comments.map((comment, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.05 * i }}
              className="py-3"
            >
              {/* Main Comment */}
              <div className="flex items-center gap-2 mb-1">
                <div className="w-6 h-6 bg-secondary flex items-center justify-center text-[10px] font-bold rounded-full">
                  {comment.author[0]}
                </div>
                <span className="text-sm font-semibold">{comment.author}</span>
                <span className="text-[10px] text-muted-foreground">{comment.time}</span>
              </div>
              <p className="text-sm text-foreground/80 ml-8">{comment.text}</p>
              <div className="flex items-center gap-3 ml-8 mt-1.5">
                <button className="flex items-center gap-1 text-[10px] text-muted-foreground hover:text-foreground">
                  <Heart size={10} /> {comment.likes}
                </button>
                <button
                  onClick={() => { setReplyingTo(replyingTo === i ? null : i); setReplyText(""); }}
                  className="flex items-center gap-1 text-[10px] text-muted-foreground hover:text-foreground"
                >
                  <CornerDownRight size={10} /> 답글
                </button>
                {comment.replies && comment.replies.length > 0 && (
                  <button
                    onClick={() => toggleReplies(i)}
                    className="flex items-center gap-1 text-[10px] text-dream hover:text-dream/80"
                  >
                    {expandedReplies.has(i) ? <ChevronUp size={10} /> : <ChevronDown size={10} />}
                    답글 {comment.replies.length}개
                  </button>
                )}
              </div>

              {/* Reply Input */}
              {replyingTo === i && (
                <div className="flex gap-2 ml-8 mt-2">
                  <input
                    type="text"
                    value={replyText}
                    onChange={(e) => setReplyText(e.target.value)}
                    onKeyDown={(e) => e.key === "Enter" && handleReply(i)}
                    placeholder={`${comment.author}에게 답글...`}
                    className="flex-1 px-3 py-1.5 text-xs border border-border bg-transparent focus:border-foreground outline-none transition-colors"
                    autoFocus
                  />
                  <button
                    onClick={() => handleReply(i)}
                    className="px-2 py-1.5 bg-foreground text-background hover:bg-foreground/90 transition-colors"
                  >
                    <Send size={12} />
                  </button>
                </div>
              )}

              {/* Replies (2nd level) */}
              {comment.replies && comment.replies.length > 0 && expandedReplies.has(i) && (
                <div className="ml-8 mt-2 pl-4 border-l-2 border-border/50 space-y-2">
                  {comment.replies.map((reply, j) => (
                    <div key={j} className="py-1.5">
                      <div className="flex items-center gap-2 mb-0.5">
                        <div className="w-5 h-5 bg-secondary/70 flex items-center justify-center text-[9px] font-bold rounded-full">
                          {reply.author[0]}
                        </div>
                        <span className="text-xs font-semibold">{reply.author}</span>
                        <span className="text-[9px] text-muted-foreground">{reply.time}</span>
                      </div>
                      <p className="text-xs text-foreground/70 ml-7">{reply.text}</p>
                      <button className="flex items-center gap-1 text-[9px] text-muted-foreground ml-7 mt-1 hover:text-foreground">
                        <Heart size={8} /> {reply.likes}
                      </button>
                    </div>
                  ))}
                </div>
              )}
            </motion.div>
          ))}
        </div>
      </section>
    </div>
  );
}
