/*
 * Konnect v3 — AI 적성 분석 페이지 ("꿈 발견")
 * 보완 보고서: 설문 → 레이더 차트 → 추천 전공 → 꿈 선언 연결
 * 3안 고유: 분석 결과가 보드 추천으로 이어짐
 */
import { useState } from "react";
import { Link } from "wouter";
import { motion, AnimatePresence } from "framer-motion";
import {
  Brain,
  ChevronRight,
  Sparkles,
  Target,
  LayoutGrid,
  CheckCircle2,
  ArrowRight,
  BarChart3,
  BookOpen,
  Lightbulb,
  Star,
  Compass,
  GraduationCap,
  Heart,
  Zap,
} from "lucide-react";
import { toast } from "sonner";

/* ─── Survey Questions ─── */
const surveyQuestions = [
  {
    id: 1,
    question: "다음 중 가장 흥미로운 활동은?",
    options: [
      { label: "실험하고 관찰하기", traits: ["과학탐구", "분석력"] },
      { label: "사람들과 토론하기", traits: ["소통", "논리력"] },
      { label: "코드를 작성하거나 시스템 만들기", traits: ["논리력", "창의력"] },
      { label: "글을 쓰거나 이야기 만들기", traits: ["표현력", "창의력"] },
      { label: "사람을 돕고 가르치기", traits: ["소통", "봉사정신"] },
    ],
  },
  {
    id: 2,
    question: "문제를 해결할 때 나의 스타일은?",
    options: [
      { label: "데이터와 근거를 분석한다", traits: ["분석력", "과학탐구"] },
      { label: "직관과 감각으로 판단한다", traits: ["창의력", "표현력"] },
      { label: "체계적으로 단계를 나눈다", traits: ["논리력", "분석력"] },
      { label: "다른 사람의 의견을 듣고 종합한다", traits: ["소통", "리더십"] },
    ],
  },
  {
    id: 3,
    question: "10년 후 나의 모습으로 가장 끌리는 것은?",
    options: [
      { label: "연구실에서 새로운 발견을 하는 연구자", traits: ["과학탐구", "분석력"] },
      { label: "환자를 치료하는 의료인", traits: ["봉사정신", "과학탐구"] },
      { label: "혁신적인 서비스를 만드는 창업가", traits: ["창의력", "리더십"] },
      { label: "사회 정의를 실현하는 법조인", traits: ["논리력", "소통"] },
      { label: "학생들에게 영감을 주는 교육자", traits: ["소통", "봉사정신"] },
      { label: "세계를 무대로 활동하는 전문가", traits: ["리더십", "표현력"] },
    ],
  },
  {
    id: 4,
    question: "가장 자신 있는 과목 영역은?",
    options: [
      { label: "수학·과학 (이과 계열)", traits: ["분석력", "논리력"] },
      { label: "국어·사회 (문과 계열)", traits: ["표현력", "소통"] },
      { label: "영어·외국어", traits: ["소통", "표현력"] },
      { label: "예체능·실기", traits: ["창의력", "표현력"] },
      { label: "골고루 잘하는 편", traits: ["분석력", "소통"] },
    ],
  },
  {
    id: 5,
    question: "팀 프로젝트에서 나의 역할은?",
    options: [
      { label: "아이디어를 내는 기획자", traits: ["창의력", "리더십"] },
      { label: "자료를 조사하고 분석하는 연구자", traits: ["분석력", "과학탐구"] },
      { label: "팀원들을 이끄는 리더", traits: ["리더십", "소통"] },
      { label: "결과물을 완성하는 실행자", traits: ["논리력", "분석력"] },
      { label: "갈등을 조율하는 중재자", traits: ["소통", "봉사정신"] },
    ],
  },
];

/* ─── Trait → Department Mapping ─── */
const traitLabels = ["과학탐구", "분석력", "논리력", "창의력", "소통", "표현력", "리더십", "봉사정신"];

type RecommendedDept = {
  name: string;
  matchRate: number;
  description: string;
  boardSlug: string;
  boardIcon: string;
  traits: string[];
};

function calculateResults(answers: number[][]): { traits: Record<string, number>; departments: RecommendedDept[] } {
  const traitScores: Record<string, number> = {};
  traitLabels.forEach((t) => (traitScores[t] = 0));

  answers.forEach((selectedTraits) => {
    selectedTraits.forEach((idx) => {
      const trait = traitLabels[idx];
      if (trait) traitScores[trait] = (traitScores[trait] || 0) + 1;
    });
  });

  // Normalize to 0-100
  const maxScore = Math.max(...Object.values(traitScores), 1);
  Object.keys(traitScores).forEach((k) => {
    traitScores[k] = Math.round((traitScores[k] / maxScore) * 100);
  });

  // Mock department recommendations
  const departments: RecommendedDept[] = [
    { name: "의예과", matchRate: 92, description: "과학탐구와 봉사정신이 높아 의학 분야에 적합합니다", boardSlug: "medicine", boardIcon: "🩺", traits: ["과학탐구", "봉사정신"] },
    { name: "생명과학", matchRate: 85, description: "분석력과 과학탐구 역량이 연구 분야에 적합합니다", boardSlug: "engineering", boardIcon: "⚙️", traits: ["과학탐구", "분석력"] },
    { name: "컴퓨터공학", matchRate: 78, description: "논리력과 창의력이 SW 개발에 적합합니다", boardSlug: "cs", boardIcon: "💻", traits: ["논리력", "창의력"] },
  ];

  return { traits: traitScores, departments };
}

/* ─── Radar Chart (SVG) ─── */
function RadarChart({ data }: { data: Record<string, number> }) {
  const labels = Object.keys(data);
  const values = Object.values(data);
  const n = labels.length;
  const cx = 120, cy = 120, r = 90;

  const getPoint = (index: number, value: number) => {
    const angle = (Math.PI * 2 * index) / n - Math.PI / 2;
    const dist = (value / 100) * r;
    return { x: cx + dist * Math.cos(angle), y: cy + dist * Math.sin(angle) };
  };

  const gridLevels = [25, 50, 75, 100];

  return (
    <svg viewBox="0 0 240 240" className="w-full max-w-[280px] mx-auto">
      {/* Grid */}
      {gridLevels.map((level) => (
        <polygon
          key={level}
          points={Array.from({ length: n }, (_, i) => {
            const p = getPoint(i, level);
            return `${p.x},${p.y}`;
          }).join(" ")}
          fill="none"
          stroke="currentColor"
          strokeOpacity={0.1}
          strokeWidth={0.5}
        />
      ))}
      {/* Axes */}
      {labels.map((_, i) => {
        const p = getPoint(i, 100);
        return <line key={i} x1={cx} y1={cy} x2={p.x} y2={p.y} stroke="currentColor" strokeOpacity={0.1} strokeWidth={0.5} />;
      })}
      {/* Data polygon */}
      <motion.polygon
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 0.8 }}
        points={values.map((v, i) => {
          const p = getPoint(i, v);
          return `${p.x},${p.y}`;
        }).join(" ")}
        fill="oklch(0.65 0.15 250 / 0.2)"
        stroke="oklch(0.65 0.15 250)"
        strokeWidth={2}
      />
      {/* Data points */}
      {values.map((v, i) => {
        const p = getPoint(i, v);
        return <circle key={i} cx={p.x} cy={p.y} r={3} fill="oklch(0.65 0.15 250)" />;
      })}
      {/* Labels */}
      {labels.map((label, i) => {
        const p = getPoint(i, 115);
        return (
          <text key={i} x={p.x} y={p.y} textAnchor="middle" dominantBaseline="middle" className="text-[8px] fill-muted-foreground">
            {label}
          </text>
        );
      })}
    </svg>
  );
}

export default function Aptitude() {
  const [step, setStep] = useState<"intro" | "survey" | "result">("intro");
  const [currentQ, setCurrentQ] = useState(0);
  const [answers, setAnswers] = useState<number[][]>([]);
  const [selectedOption, setSelectedOption] = useState<number | null>(null);
  const [results, setResults] = useState<ReturnType<typeof calculateResults> | null>(null);

  const handleAnswer = () => {
    if (selectedOption === null) return;
    const question = surveyQuestions[currentQ];
    const option = question.options[selectedOption];
    const traitIndices = option.traits.map((t) => traitLabels.indexOf(t));
    const newAnswers = [...answers, traitIndices];
    setAnswers(newAnswers);
    setSelectedOption(null);

    if (currentQ < surveyQuestions.length - 1) {
      setCurrentQ(currentQ + 1);
    } else {
      const r = calculateResults(newAnswers);
      setResults(r);
      setStep("result");
    }
  };

  return (
    <div className="max-w-4xl mx-auto px-4 lg:px-6 py-6">
      {/* Header */}
      <div className="flex items-center gap-2 mb-6">
        <Link href="/dream">
          <span className="text-sm text-muted-foreground hover:text-foreground">꿈 선언</span>
        </Link>
        <ChevronRight size={12} className="text-muted-foreground" />
        <span className="text-sm font-semibold">AI 적성 분석</span>
        <span className="text-[9px] bg-dream/10 text-dream px-1.5 py-0.5 rounded-full font-semibold ml-1">3안 신규</span>
      </div>

      <AnimatePresence mode="wait">
        {/* ═══ Intro ═══ */}
        {step === "intro" && (
          <motion.div
            key="intro"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
          >
            <div className="text-center mb-8">
              <div className="w-16 h-16 bg-gradient-to-br from-dream/20 to-indigo-200/30 rounded-2xl flex items-center justify-center mx-auto mb-4">
                <Brain size={32} className="text-dream" />
              </div>
              <h1 className="editorial-heading text-2xl lg:text-3xl mb-2">꿈 발견 — AI 적성 분석</h1>
              <p className="text-muted-foreground text-sm max-w-md mx-auto leading-relaxed">
                5개의 질문에 답하면 AI가 당신의 적성을 분석하고, 맞춤 전공과 꿈 보드를 추천합니다.
              </p>
            </div>

            {/* 3안 차별점 안내 */}
            <div className="border-2 border-dream/20 bg-dream/5 rounded-xl p-5 mb-6">
              <h3 className="text-sm font-semibold flex items-center gap-2 mb-3">
                <Zap size={14} className="text-dream" />
                3안에서만 가능한 것
              </h3>
              <div className="grid sm:grid-cols-3 gap-3">
                {[
                  { icon: BarChart3, title: "레이더 차트", desc: "8가지 역량을 시각화" },
                  { icon: GraduationCap, title: "전공 매칭", desc: "적합도 기반 추천" },
                  { icon: LayoutGrid, title: "보드 자동 배정", desc: "분석 결과 → 꿈 보드 연결" },
                ].map((item) => (
                  <div key={item.title} className="flex items-start gap-2 p-3 bg-white/60 dark:bg-ink/30 rounded-lg">
                    <item.icon size={16} className="text-dream shrink-0 mt-0.5" />
                    <div>
                      <p className="text-xs font-semibold">{item.title}</p>
                      <p className="text-[10px] text-muted-foreground">{item.desc}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            <div className="text-center">
              <button
                className="inline-flex items-center gap-2 px-8 py-3 bg-dream text-white font-semibold rounded-lg hover:bg-dream/90 transition-colors"
                onClick={() => setStep("survey")}
              >
                <Sparkles size={16} />
                분석 시작하기
              </button>
              <p className="text-[10px] text-muted-foreground mt-2">약 2분 소요 · 5개 질문</p>
            </div>
          </motion.div>
        )}

        {/* ═══ Survey ═══ */}
        {step === "survey" && (
          <motion.div
            key={`survey-${currentQ}`}
            initial={{ opacity: 0, x: 30 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -30 }}
          >
            {/* Progress */}
            <div className="mb-6">
              <div className="flex items-center justify-between mb-2">
                <span className="text-xs text-muted-foreground">질문 {currentQ + 1} / {surveyQuestions.length}</span>
                <span className="text-xs font-semibold text-dream">{Math.round(((currentQ + 1) / surveyQuestions.length) * 100)}%</span>
              </div>
              <div className="h-1.5 bg-secondary rounded-full overflow-hidden">
                <motion.div
                  className="h-full bg-dream rounded-full"
                  initial={{ width: `${(currentQ / surveyQuestions.length) * 100}%` }}
                  animate={{ width: `${((currentQ + 1) / surveyQuestions.length) * 100}%` }}
                  transition={{ duration: 0.3 }}
                />
              </div>
            </div>

            <div className="max-w-lg mx-auto">
              <h2 className="editorial-heading text-xl mb-6 text-center">
                {surveyQuestions[currentQ].question}
              </h2>

              <div className="space-y-2">
                {surveyQuestions[currentQ].options.map((opt, i) => (
                  <button
                    key={i}
                    onClick={() => setSelectedOption(i)}
                    className={`w-full text-left p-4 rounded-lg border-2 transition-all ${
                      selectedOption === i
                        ? "border-dream bg-dream/5 shadow-sm"
                        : "border-border hover:border-dream/30"
                    }`}
                  >
                    <div className="flex items-center gap-3">
                      <div className={`w-5 h-5 rounded-full border-2 flex items-center justify-center transition-colors ${
                        selectedOption === i ? "border-dream bg-dream" : "border-border"
                      }`}>
                        {selectedOption === i && <CheckCircle2 size={12} className="text-white" />}
                      </div>
                      <span className="text-sm font-medium">{opt.label}</span>
                    </div>
                    <div className="flex gap-1 mt-2 ml-8">
                      {opt.traits.map((t) => (
                        <span key={t} className="text-[9px] px-1.5 py-0.5 bg-secondary text-muted-foreground rounded">{t}</span>
                      ))}
                    </div>
                  </button>
                ))}
              </div>

              <div className="flex justify-center mt-6">
                <button
                  onClick={handleAnswer}
                  disabled={selectedOption === null}
                  className="inline-flex items-center gap-2 px-6 py-2.5 bg-dream text-white font-semibold rounded-lg hover:bg-dream/90 transition-colors disabled:opacity-40 disabled:cursor-not-allowed"
                >
                  {currentQ < surveyQuestions.length - 1 ? "다음" : "결과 보기"}
                  <ArrowRight size={14} />
                </button>
              </div>
            </div>
          </motion.div>
        )}

        {/* ═══ Result ═══ */}
        {step === "result" && results && (
          <motion.div
            key="result"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
          >
            <div className="text-center mb-6">
              <div className="w-12 h-12 bg-dream/10 rounded-xl flex items-center justify-center mx-auto mb-3">
                <Sparkles size={24} className="text-dream" />
              </div>
              <h1 className="editorial-heading text-2xl mb-1">적성 분석 결과</h1>
              <p className="text-sm text-muted-foreground">당신의 8가지 역량을 분석했습니다</p>
            </div>

            <div className="lg:grid lg:grid-cols-2 lg:gap-8">
              {/* Radar Chart */}
              <div className="border border-border rounded-xl p-5 mb-6 lg:mb-0">
                <h3 className="text-sm font-semibold flex items-center gap-2 mb-4">
                  <BarChart3 size={14} className="text-dream" />
                  역량 레이더 차트
                </h3>
                <RadarChart data={results.traits} />
                <div className="grid grid-cols-4 gap-2 mt-4">
                  {Object.entries(results.traits).map(([key, value]) => (
                    <div key={key} className="text-center">
                      <p className="text-lg font-bold text-dream">{value}</p>
                      <p className="text-[9px] text-muted-foreground">{key}</p>
                    </div>
                  ))}
                </div>
              </div>

              {/* Recommended Departments */}
              <div>
                <h3 className="text-sm font-semibold flex items-center gap-2 mb-4">
                  <GraduationCap size={14} className="text-dream" />
                  추천 전공
                </h3>
                <div className="space-y-3 mb-6">
                  {results.departments.map((dept, i) => (
                    <div key={dept.name} className={`border rounded-xl p-4 ${i === 0 ? "border-dream/30 bg-dream/5" : "border-border"}`}>
                      <div className="flex items-center justify-between mb-2">
                        <div className="flex items-center gap-2">
                          {i === 0 && <Star size={14} className="text-dream" />}
                          <span className="text-sm font-semibold">{dept.name}</span>
                        </div>
                        <span className={`text-sm font-bold ${i === 0 ? "text-dream" : "text-muted-foreground"}`}>
                          {dept.matchRate}%
                        </span>
                      </div>
                      <div className="h-1.5 bg-secondary rounded-full overflow-hidden mb-2">
                        <motion.div
                          className="h-full bg-dream rounded-full"
                          initial={{ width: 0 }}
                          animate={{ width: `${dept.matchRate}%` }}
                          transition={{ duration: 0.8, delay: 0.2 * i }}
                        />
                      </div>
                      <p className="text-xs text-muted-foreground mb-2">{dept.description}</p>
                      <div className="flex items-center gap-1.5">
                        {dept.traits.map((t) => (
                          <span key={t} className="text-[9px] px-1.5 py-0.5 bg-dream/10 text-dream rounded">{t}</span>
                        ))}
                      </div>
                    </div>
                  ))}
                </div>

                {/* 3안 고유: 보드 추천 */}
                <div className="border-2 border-dream/20 bg-dream/5 rounded-xl p-4">
                  <div className="flex items-center gap-2 mb-3">
                    <LayoutGrid size={14} className="text-dream" />
                    <span className="text-xs font-semibold text-dream">추천 꿈 보드</span>
                    <span className="text-[8px] bg-dream/10 text-dream px-1.5 py-0.5 rounded-full">3안 고유</span>
                  </div>
                  <p className="text-[10px] text-muted-foreground mb-3">
                    적성 분석 결과에 기반한 맞춤 보드입니다. 보드에 참여하면 AI 도구가 자동으로 맥락화됩니다.
                  </p>
                  <div className="space-y-2">
                    {results.departments.map((dept) => (
                      <Link key={dept.boardSlug} href={`/boards/${dept.boardSlug}`}>
                        <div className="flex items-center gap-2 p-2.5 bg-white/80 dark:bg-ink/30 rounded-lg border border-dream/10 hover:border-dream/30 transition-colors cursor-pointer group">
                          <span className="text-lg">{dept.boardIcon}</span>
                          <div className="flex-1 min-w-0">
                            <p className="text-xs font-semibold group-hover:text-dream transition-colors">{dept.name} 보드</p>
                            <p className="text-[9px] text-muted-foreground">적합도 {dept.matchRate}%</p>
                          </div>
                          <ChevronRight size={14} className="text-muted-foreground" />
                        </div>
                      </Link>
                    ))}
                  </div>
                </div>
              </div>
            </div>

            {/* Actions */}
            <div className="flex flex-wrap justify-center gap-3 mt-8">
              <Link href="/dream">
                <span className="inline-flex items-center gap-2 px-6 py-2.5 bg-dream text-white font-semibold rounded-lg hover:bg-dream/90 transition-colors">
                  <Heart size={14} />
                  꿈 선언에 반영하기
                </span>
              </Link>
              <button
                className="inline-flex items-center gap-2 px-6 py-2.5 border border-border text-sm font-medium rounded-lg hover:bg-secondary transition-colors"
                onClick={() => {
                  setStep("intro");
                  setCurrentQ(0);
                  setAnswers([]);
                  setSelectedOption(null);
                  setResults(null);
                }}
              >
                다시 분석하기
              </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
