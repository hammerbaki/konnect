/*
 * 3안: Community → 꿈 보드로 리다이렉트
 */
import { useEffect } from "react";
import { useLocation } from "wouter";

export default function Community() {
  const [, navigate] = useLocation();
  useEffect(() => {
    navigate("/boards", { replace: true });
  }, [navigate]);
  return null;
}
