/*
 * Design: Inkwell — Editorial Ink & Paper
 * Market page — PC: 2-column (products + sidebar) / Mobile: single column
 */
import { useState } from "react";
import { Link } from "wouter";
import { motion } from "framer-motion";
import {
  BookOpen,
  Video,
  Filter,
  Star,
  Coins,
  ShoppingBag,
  TrendingUp,
  ArrowRight,
  Upload,
  Award,
} from "lucide-react";
import { toast } from "sonner";

const categories = ["전체", "국어", "수학", "영어", "탐구", "논술", "면접"];
const types = ["전체", "교재", "강의", "자료"];

const products = [
  { id: 1, title: "국어 1등급을 정말 원한다면", author: "김국어", category: "국어", type: "교재", price: 31000, discount: 10, rating: 4.8, reviews: 128, sales: 2340, desc: "수능 국어 1등급을 위한 체계적 학습 가이드.", creditPrice: 280 },
  { id: 2, title: "수학 킬러문항 완전정복", author: "박수학", category: "수학", type: "교재", price: 28000, discount: 15, rating: 4.9, reviews: 95, sales: 1890, desc: "최근 5개년 수능 킬러문항 패턴 분석 및 풀이 전략.", creditPrice: 240 },
  { id: 3, title: "영어 독해 비법노트", author: "이영어", category: "영어", type: "교재", price: 22000, discount: 5, rating: 4.6, reviews: 67, sales: 1230, desc: "수능 영어 독해 유형별 접근법과 핵심 어휘 정리.", creditPrice: 200 },
  { id: 4, title: "물리학1 개념 완성 강의", author: "최물리", category: "탐구", type: "강의", price: 45000, discount: 20, rating: 4.7, reviews: 203, sales: 3100, desc: "물리학1 전 범위 개념 강의. 총 40강.", creditPrice: 360 },
  { id: 5, title: "생명과학1 실전 모의고사 10회분", author: "정생명", category: "탐구", type: "자료", price: 15000, discount: 0, rating: 4.5, reviews: 42, sales: 780, desc: "실전 난이도 모의고사 10회분 + 해설.", creditPrice: 135 },
  { id: 6, title: "논술 기출 분석 & 모범답안", author: "한논술", category: "논술", type: "자료", price: 18000, discount: 10, rating: 4.4, reviews: 56, sales: 920, desc: "주요 대학 논술 기출문제 분석과 모범답안 수록.", creditPrice: 160 },
  { id: 7, title: "면접 실전 가이드북", author: "면접왕", category: "면접", type: "교재", price: 25000, discount: 12, rating: 4.8, reviews: 89, sales: 1560, desc: "의대·약대·교대 면접 기출 + 모범 답변 + 실전 팁.", creditPrice: 220 },
  { id: 8, title: "수학 기하 집중 강의", author: "박수학", category: "수학", type: "강의", price: 35000, discount: 10, rating: 4.9, reviews: 156, sales: 2780, desc: "기하 영역 완벽 마스터. 벡터·이차곡선·공간도형.", creditPrice: 315 },
];

const bestSellers = [
  { rank: 1, title: "물리학1 개념 완성 강의", author: "최물리", sales: 3100, type: "강의" },
  { rank: 2, title: "수학 기하 집중 강의", author: "박수학", sales: 2780, type: "강의" },
  { rank: 3, title: "국어 1등급을 원한다면", author: "김국어", sales: 2340, type: "교재" },
  { rank: 4, title: "수학 킬러문항 완전정복", author: "박수학", sales: 1890, type: "교재" },
  { rank: 5, title: "면접 실전 가이드북", author: "면접왕", sales: 1560, type: "교재" },
];

export default function Market() {
  const [activeCategory, setActiveCategory] = useState("전체");
  const [activeType, setActiveType] = useState("전체");
  const [sortBy, setSortBy] = useState<"popular" | "latest" | "price">("popular");

  const filtered = products
    .filter((p) => activeCategory === "전체" || p.category === activeCategory)
    .filter((p) => activeType === "전체" || p.type === activeType)
    .sort((a, b) => {
      if (sortBy === "popular") return b.sales - a.sales;
      if (sortBy === "price") return a.price * (1 - a.discount / 100) - b.price * (1 - b.discount / 100);
      return 0;
    });

  return (
    <div className="max-w-7xl mx-auto px-4 lg:px-6 py-6">
      {/* Header */}
      <div className="flex items-center gap-3 mb-2">
        <ShoppingBag size={20} />
        <h1 className="editorial-heading text-2xl">마켓</h1>
      </div>
      <p className="text-sm text-muted-foreground mb-4">
        검증된 교재와 강의를 크레딧으로 구매하세요. 직접 콘텐츠를 등록하고 판매할 수도 있습니다.
      </p>
      <hr className="editorial-divider-thick mt-0" />

      {/* Hero Banner */}
      <div className="relative overflow-hidden mb-6">
        <img
          src="https://d2xsxph8kpxj0f.cloudfront.net/310519663433131621/A3XszkVKVy7WNitpyWDbEe/v2-marketplace-JWeUSaTZp2jkxno4gogwsG.webp"
          alt="Marketplace"
          className="w-full h-36 md:h-48 object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-r from-background/90 to-transparent" />
        <div className="absolute top-1/2 -translate-y-1/2 left-6">
          <span className="ink-tag-filled bg-gold text-white text-[10px]">MARKETPLACE</span>
          <p className="font-serif font-bold text-lg mt-1">지식을 사고팔다</p>
          <p className="text-xs text-muted-foreground mt-1">크레딧으로 결제 시 추가 5% 할인</p>
        </div>
      </div>

      {/* Filters */}
      <div className="space-y-3 mb-6">
        <div className="flex items-center gap-2 overflow-x-auto pb-1">
          <Filter size={14} className="text-muted-foreground shrink-0" />
          {categories.map((cat) => (
            <button key={cat} onClick={() => setActiveCategory(cat)}
              className={`shrink-0 px-3 py-1 text-xs transition-all ${activeCategory === cat ? "bg-foreground text-background font-semibold" : "text-muted-foreground hover:text-foreground border border-border"}`}
            >{cat}</button>
          ))}
        </div>
        <div className="flex items-center gap-4">
          <div className="flex items-center gap-2">
            {types.map((t) => (
              <button key={t} onClick={() => setActiveType(t)}
                className={`text-xs transition-all ${activeType === t ? "text-foreground font-semibold" : "text-muted-foreground"}`}
              >{t}</button>
            ))}
          </div>
          <span className="text-border">|</span>
          <div className="flex items-center gap-2">
            <button onClick={() => setSortBy("popular")}
              className={`flex items-center gap-1 text-xs ${sortBy === "popular" ? "text-foreground font-semibold" : "text-muted-foreground"}`}
            ><TrendingUp size={12} /> 인기순</button>
            <button onClick={() => setSortBy("price")}
              className={`flex items-center gap-1 text-xs ${sortBy === "price" ? "text-foreground font-semibold" : "text-muted-foreground"}`}
            ><Coins size={12} /> 가격순</button>
          </div>
        </div>
      </div>

      {/* ═══ PC: 2-column / Mobile: single column ═══ */}
      <div className="lg:grid lg:grid-cols-[1fr_280px] lg:gap-8">
        {/* Main Content */}
        <div>
          <div className="grid sm:grid-cols-2 xl:grid-cols-3 gap-4">
            {filtered.map((product, i) => (
              <motion.div key={product.id} initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.05 * i }}>
                <Link href={`/market/${product.id}`}>
                  <article className="ink-card p-4 h-full flex flex-col">
                    <div className="flex items-center justify-between mb-2">
                      <div className="flex items-center gap-2">
                        <span className="ink-tag text-[10px]">{product.category}</span>
                        <span className="ink-tag-filled bg-secondary text-[10px] flex items-center gap-0.5">
                          {product.type === "강의" ? <Video size={10} /> : <BookOpen size={10} />}
                          {product.type}
                        </span>
                      </div>
                      {product.discount > 0 && (
                        <span className="text-[10px] text-vermillion font-bold">-{product.discount}%</span>
                      )}
                    </div>
                    <h3 className="font-serif font-bold text-sm leading-snug mb-1 line-clamp-2">{product.title}</h3>
                    <p className="text-[10px] text-muted-foreground mb-2">{product.author}</p>
                    <p className="text-xs text-muted-foreground line-clamp-2 mb-3 flex-1">{product.desc}</p>
                    <div className="flex items-center gap-1 mb-2">
                      <Star size={12} className="text-gold fill-gold" />
                      <span className="text-xs font-semibold">{product.rating}</span>
                      <span className="text-[10px] text-muted-foreground">({product.reviews})</span>
                      <span className="text-[10px] text-muted-foreground ml-auto">{product.sales.toLocaleString()}명 구매</span>
                    </div>
                    <div className="border-t border-border pt-2 mt-auto">
                      <div className="flex items-center justify-between">
                        <div>
                          {product.discount > 0 && (
                            <span className="text-[10px] text-muted-foreground line-through mr-1">{product.price.toLocaleString()}원</span>
                          )}
                          <span className="text-sm font-bold">
                            {Math.round(product.price * (1 - product.discount / 100)).toLocaleString()}원
                          </span>
                        </div>
                        <div className="credit-badge text-xs">
                          <Coins size={10} />
                          <span>{product.creditPrice} KNC</span>
                        </div>
                      </div>
                    </div>
                  </article>
                </Link>
              </motion.div>
            ))}
          </div>
        </div>

        {/* ── Right Sidebar (Desktop Only) ── */}
        <aside className="hidden lg:block space-y-6">
          {/* Sell CTA */}
          <div className="ink-card p-4 bg-gold/5 border-gold/20">
            <div className="flex items-center gap-2 mb-3">
              <Upload size={14} className="text-gold" />
              <span className="text-xs font-semibold tracking-wider uppercase">콘텐츠 판매하기</span>
            </div>
            <p className="text-xs text-muted-foreground mb-3">
              직접 만든 교재, 강의, 학습 자료를 등록하고 크레딧으로 수익을 올리세요.
            </p>
            <button
              onClick={() => toast.info("콘텐츠 등록 기능은 준비 중입니다")}
              className="text-xs font-semibold text-gold flex items-center gap-0.5 hover:gap-1.5 transition-all"
            >
              등록하기 <ArrowRight size={12} />
            </button>
          </div>

          {/* Best Sellers */}
          <div className="ink-card p-4">
            <div className="flex items-center gap-2 mb-3">
              <Award size={14} className="text-gold" />
              <span className="text-xs font-semibold tracking-wider uppercase">베스트셀러</span>
            </div>
            <div className="space-y-2.5">
              {bestSellers.map((item) => (
                <div key={item.rank} className="flex items-start gap-2.5 py-1 group cursor-pointer"
                  onClick={() => toast.info("상품 상세 페이지는 준비 중입니다")}
                >
                  <span className="text-lg font-mono font-bold text-muted-foreground/40 w-5 text-right shrink-0">{item.rank}</span>
                  <div className="flex-1">
                    <p className="text-sm font-medium group-hover:text-gold transition-colors leading-snug">{item.title}</p>
                    <div className="flex items-center gap-1.5 mt-0.5">
                      <span className="text-[10px] text-muted-foreground">{item.author}</span>
                      <span className="text-[10px] text-muted-foreground">·</span>
                      <span className="text-[10px] text-muted-foreground">{item.sales.toLocaleString()}명</span>
                    </div>
                  </div>
                  <span className="ink-tag-filled bg-secondary text-[10px]">{item.type}</span>
                </div>
              ))}
            </div>
          </div>

          {/* Credit Info */}
          <div className="ink-card p-4">
            <div className="flex items-center gap-2 mb-3">
              <Coins size={14} className="text-gold" />
              <span className="text-xs font-semibold tracking-wider uppercase">크레딧 결제 안내</span>
            </div>
            <div className="space-y-2 text-xs text-muted-foreground">
              <p>KNC 크레딧으로 결제하면 <span className="text-gold font-semibold">추가 5% 할인</span>이 적용됩니다.</p>
              <p>크레딧은 활동 보상, 충전, 또는 마켓 판매 수익으로 획득할 수 있습니다.</p>
              <Link href="/credits">
                <span className="text-gold font-semibold flex items-center gap-0.5 mt-2 hover:gap-1.5 transition-all">
                  크레딧 자세히 보기 <ArrowRight size={12} />
                </span>
              </Link>
            </div>
          </div>
        </aside>
      </div>
    </div>
  );
}
