/*
 * Design: Neo-Brutalism + Gen-Z Energy
 * - VS card layout with bold colors
 * - Animated vote results
 * - Sticker-like percentage labels
 */
import { useState, useCallback } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { ArrowRight, RotateCcw, Zap, Users, BarChart3 } from "lucide-react";

interface BalanceQuestion {
  id: number;
  optionA: string;
  optionB: string;
  voteA: number;
  voteB: number;
  category: string;
}

const balanceData: BalanceQuestion[] = [
  {
    id: 1,
    optionA: "수능 올 1등급",
    optionB: "수시 6장 모두 합격",
    voteA: 4823,
    voteB: 5177,
    category: "전형 선택",
  },
  {
    id: 2,
    optionA: "통학 2시간\n인서울 대학",
    optionB: "기숙사 제공\n지방 거점 국립대",
    voteA: 5534,
    voteB: 4466,
    category: "대학 선택",
  },
  {
    id: 3,
    optionA: "좋아하는 학과\n취업률 낮음",
    optionB: "관심 없는 학과\n취업률 높음",
    voteA: 6210,
    voteB: 3790,
    category: "진로 고민",
  },
  {
    id: 4,
    optionA: "내신 1등급\n수능 3등급",
    optionB: "내신 3등급\n수능 1등급",
    voteA: 3856,
    voteB: 6144,
    category: "성적 밸런스",
  },
  {
    id: 5,
    optionA: "혼자 독학으로\n공부하기",
    optionB: "학원 다니며\n함께 공부하기",
    voteA: 4102,
    voteB: 5898,
    category: "학습 스타일",
  },
  {
    id: 6,
    optionA: "재수해서\n목표 대학 가기",
    optionB: "현역으로\n차선 대학 가기",
    voteA: 3421,
    voteB: 6579,
    category: "인생 선택",
  },
  {
    id: 7,
    optionA: "면접 없는\n교과전형",
    optionB: "면접 있는\n학종전형",
    voteA: 5789,
    voteB: 4211,
    category: "전형 선택",
  },
  {
    id: 8,
    optionA: "수능 전날\n벼락치기",
    optionB: "수능 전날\n완전 휴식",
    voteA: 2134,
    voteB: 7866,
    category: "수능 전략",
  },
];

export default function BalanceGame() {
  const [currentQ, setCurrentQ] = useState(0);
  const [selected, setSelected] = useState<"A" | "B" | null>(null);
  const [showResult, setShowResult] = useState(false);
  const [myChoices, setMyChoices] = useState<("A" | "B")[]>([]);
  const [gameComplete, setGameComplete] = useState(false);

  const question = balanceData[currentQ];
  const totalVotes = question.voteA + question.voteB;
  const percentA = Math.round((question.voteA / totalVotes) * 100);
  const percentB = 100 - percentA;

  const handleSelect = useCallback(
    (choice: "A" | "B") => {
      if (showResult) return;
      setSelected(choice);
      setShowResult(true);
      setMyChoices((prev) => [...prev, choice]);
    },
    [showResult]
  );

  const handleNext = useCallback(() => {
    if (currentQ < balanceData.length - 1) {
      setCurrentQ((q) => q + 1);
      setSelected(null);
      setShowResult(false);
    } else {
      setGameComplete(true);
    }
  }, [currentQ]);

  const handleRestart = useCallback(() => {
    setCurrentQ(0);
    setSelected(null);
    setShowResult(false);
    setMyChoices([]);
    setGameComplete(false);
  }, []);

  if (gameComplete) {
    const majorityCount = myChoices.filter((c, i) => {
      const q = balanceData[i];
      const majority = q.voteA > q.voteB ? "A" : "B";
      return c === majority;
    }).length;

    return (
      <div className="container py-12">
        <motion.div
          initial={{ scale: 0.8, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          className="max-w-lg mx-auto text-center"
        >
          <div className="brutal-card bg-white p-8 rounded-lg">
            <BarChart3 size={64} className="mx-auto text-primary mb-4" />
            <h2 className="font-display text-4xl mb-4">결과 분석!</h2>
            <div className="brutal-tag bg-konnect-yellow text-foreground text-lg my-4 inline-block">
              다수 의견 일치율: {Math.round((majorityCount / balanceData.length) * 100)}%
            </div>
            <p className="text-muted-foreground mb-4">
              {majorityCount >= 6
                ? "다수의 수험생들과 비슷한 생각을 가지고 있어요! 🤝"
                : majorityCount >= 4
                ? "나만의 독특한 시각이 돋보여요! ✨"
                : "소신 있는 선택을 하는 타입이시군요! 🔥"}
            </p>
            <div className="space-y-2 text-left mb-6">
              {myChoices.map((choice, i) => {
                const q = balanceData[i];
                return (
                  <div key={i} className="flex items-center gap-2 text-sm">
                    <span className="brutal-tag bg-secondary text-foreground text-xs">
                      Q{i + 1}
                    </span>
                    <span className="font-medium">
                      {choice === "A" ? q.optionA.replace("\n", " ") : q.optionB.replace("\n", " ")}
                    </span>
                  </div>
                );
              })}
            </div>
            <button
              onClick={handleRestart}
              className="brutal-btn bg-primary text-white px-8 py-3 text-lg inline-flex items-center gap-2"
            >
              <RotateCcw size={20} /> 다시 하기
            </button>
          </div>
        </motion.div>
      </div>
    );
  }

  return (
    <div className="container py-8">
      <div className="max-w-2xl mx-auto">
        {/* Header */}
        <div className="flex items-center justify-between mb-6">
          <span className="brutal-tag bg-konnect-red text-white">
            {question.category}
          </span>
          <span className="text-sm font-bold text-muted-foreground">
            {currentQ + 1} / {balanceData.length}
          </span>
        </div>

        {/* Progress */}
        <div className="brutal-card bg-white p-1 rounded-full mb-8">
          <div
            className="h-3 bg-konnect-red rounded-full transition-all duration-500"
            style={{ width: `${((currentQ + (showResult ? 1 : 0)) / balanceData.length) * 100}%` }}
          />
        </div>

        {/* VS Cards */}
        <AnimatePresence mode="wait">
          <motion.div
            key={currentQ}
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.9 }}
          >
            <div className="grid grid-cols-2 gap-4 relative">
              {/* Option A */}
              <motion.button
                onClick={() => handleSelect("A")}
                disabled={showResult}
                whileTap={!showResult ? { scale: 0.95 } : undefined}
                className={`brutal-card p-6 rounded-lg text-center relative overflow-hidden ${
                  showResult && selected === "A"
                    ? "bg-konnect-blue text-white ring-4 ring-konnect-blue/50"
                    : showResult
                    ? "bg-gray-100"
                    : "bg-konnect-blue text-white hover:translate-y-[-4px]"
                }`}
                style={{ minHeight: "180px" }}
              >
                {showResult && (
                  <motion.div
                    initial={{ height: 0 }}
                    animate={{ height: `${percentA}%` }}
                    transition={{ duration: 0.8, ease: "easeOut" }}
                    className="absolute bottom-0 left-0 right-0 bg-konnect-blue/20"
                  />
                )}
                <div className="relative z-10">
                  <p className="font-display text-lg md:text-xl whitespace-pre-line leading-snug">
                    {question.optionA}
                  </p>
                  {showResult && (
                    <motion.div
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      className="mt-4"
                    >
                      <span className="brutal-tag bg-white text-foreground text-lg">
                        {percentA}%
                      </span>
                      <p className="text-xs mt-2 opacity-80 flex items-center justify-center gap-1">
                        <Users size={12} /> {question.voteA.toLocaleString()}명
                      </p>
                    </motion.div>
                  )}
                </div>
              </motion.button>

              {/* VS Badge */}
              <div className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 z-20">
                <div className="w-14 h-14 bg-foreground text-white rounded-full border-3 border-white flex items-center justify-center font-display text-lg shadow-lg">
                  VS
                </div>
              </div>

              {/* Option B */}
              <motion.button
                onClick={() => handleSelect("B")}
                disabled={showResult}
                whileTap={!showResult ? { scale: 0.95 } : undefined}
                className={`brutal-card p-6 rounded-lg text-center relative overflow-hidden ${
                  showResult && selected === "B"
                    ? "bg-konnect-yellow text-foreground ring-4 ring-konnect-yellow/50"
                    : showResult
                    ? "bg-gray-100"
                    : "bg-konnect-yellow text-foreground hover:translate-y-[-4px]"
                }`}
                style={{ minHeight: "180px" }}
              >
                {showResult && (
                  <motion.div
                    initial={{ height: 0 }}
                    animate={{ height: `${percentB}%` }}
                    transition={{ duration: 0.8, ease: "easeOut" }}
                    className="absolute bottom-0 left-0 right-0 bg-konnect-yellow/20"
                  />
                )}
                <div className="relative z-10">
                  <p className="font-display text-lg md:text-xl whitespace-pre-line leading-snug">
                    {question.optionB}
                  </p>
                  {showResult && (
                    <motion.div
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      className="mt-4"
                    >
                      <span className="brutal-tag bg-white text-foreground text-lg">
                        {percentB}%
                      </span>
                      <p className="text-xs mt-2 opacity-80 flex items-center justify-center gap-1">
                        <Users size={12} /> {question.voteB.toLocaleString()}명
                      </p>
                    </motion.div>
                  )}
                </div>
              </motion.button>
            </div>

            {/* Next Button */}
            {showResult && (
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                className="mt-6 text-center"
              >
                <button
                  onClick={handleNext}
                  className="brutal-btn bg-foreground text-white px-8 py-3 text-lg inline-flex items-center gap-2"
                >
                  {currentQ < balanceData.length - 1 ? (
                    <>
                      다음 질문 <ArrowRight size={20} />
                    </>
                  ) : (
                    <>
                      결과 보기 <Zap size={20} />
                    </>
                  )}
                </button>
              </motion.div>
            )}
          </motion.div>
        </AnimatePresence>

        {/* Image */}
        <div className="mt-8">
          <img
            src="https://d2xsxph8kpxj0f.cloudfront.net/310519663433131621/A3XszkVKVy7WNitpyWDbEe/balance-game-QZu9DmdUXQNo6R5xBykB6i.webp"
            alt="밸런스 게임"
            className="brutal-card rounded-lg w-full max-w-md mx-auto"
          />
        </div>
      </div>
    </div>
  );
}
