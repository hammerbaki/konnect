import { Link } from "wouter";
import { ArrowLeft } from "lucide-react";

export default function NotFound() {
  return (
    <div className="max-w-7xl mx-auto px-4 lg:px-6 py-20 text-center">
      <span className="display-heading text-8xl text-muted-foreground/20">404</span>
      <h1 className="editorial-heading text-2xl mt-4 mb-2">
        페이지를 찾을 수 없습니다
      </h1>
      <p className="text-sm text-muted-foreground mb-6">
        요청하신 페이지가 존재하지 않거나 이동되었습니다.
      </p>
      <Link href="/">
        <span className="inline-flex items-center gap-1.5 px-4 py-2 text-sm bg-foreground text-background hover:bg-foreground/90 transition-colors">
          <ArrowLeft size={14} /> 홈으로 돌아가기
        </span>
      </Link>
    </div>
  );
}
