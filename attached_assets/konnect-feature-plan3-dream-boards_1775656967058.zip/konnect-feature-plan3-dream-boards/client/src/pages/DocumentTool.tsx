/*
 * 3안 보완 — AI 서류 작성 도구 (Document Tool)
 * 자소서 · 생기부 분석 · 학업계획서 작성 워크스페이스 + AI 첨삭
 * 보드 맥락화: URL 쿼리로 보드 slug 전달 시 해당 꿈 맥락 자동 주입
 */
import { useState } from "react";
import { Link, useSearch } from "wouter";
import { motion, AnimatePresence } from "framer-motion";
import {
  FileEdit,
  FileText,
  GraduationCap,
  Sparkles,
  ChevronRight,
  ArrowLeft,
  Plus,
  Clock,
  Star,
  CheckCircle2,
  AlertCircle,
  Lightbulb,
  Target,
  BookOpen,
  Wand2,
  Save,
  RotateCcw,
  Copy,
  LayoutGrid,
  Crown,
} from "lucide-react";
import { toast } from "sonner";

/* ─── Document Types ─── */
const docTypes = [
  {
    id: "personal-statement",
    label: "자기소개서",
    icon: FileEdit,
    color: "text-blue-600 bg-blue-50",
    description: "대학별 자기소개서 문항 작성 및 AI 첨삭",
    prompts: [
      "고등학교 재학 기간 중 자신의 진로와 관련하여 어떤 노력을 해왔는지 구체적으로 기술해 주세요.",
      "고등학교 재학 기간 중 타인과 공동체를 위해 노력한 경험과 이를 통해 배운 점을 기술해 주세요.",
      "해당 모집단위에 지원하게 된 동기와 지원하기 위해 노력한 과정을 구체적으로 기술해 주세요.",
    ],
  },
  {
    id: "school-record",
    label: "생기부 분석",
    icon: BookOpen,
    color: "text-emerald-600 bg-emerald-50",
    description: "생활기록부 세특 분석 및 보완 포인트 도출",
    prompts: [
      "세특 내용을 붙여넣으면 강점과 보완점을 분석해드립니다.",
      "교과별 세특의 일관성과 전공 적합성을 평가해드립니다.",
      "세특에서 드러나는 학업 역량과 발전 가능성을 분석해드립니다.",
    ],
  },
  {
    id: "study-plan",
    label: "학업계획서",
    icon: GraduationCap,
    color: "text-purple-600 bg-purple-50",
    description: "대학 입학 후 학업계획서 작성 및 AI 피드백",
    prompts: [
      "지원 학과에서 어떤 학문적 목표를 이루고 싶은지 기술해 주세요.",
      "입학 후 수강하고 싶은 교과목과 그 이유를 기술해 주세요.",
      "졸업 후 진로 계획과 이를 위한 대학 생활 계획을 기술해 주세요.",
    ],
  },
];

/* ─── Sample saved documents ─── */
const savedDocs = [
  {
    id: 1,
    type: "personal-statement",
    title: "서울대 의예과 자소서 1번",
    updatedAt: "2시간 전",
    wordCount: 1247,
    status: "첨삭 완료",
    score: 82,
  },
  {
    id: 2,
    type: "school-record",
    title: "생기부 세특 분석 — 생명과학Ⅱ",
    updatedAt: "1일 전",
    wordCount: 890,
    status: "분석 완료",
    score: 75,
  },
  {
    id: 3,
    type: "study-plan",
    title: "연세대 의예과 학업계획서",
    updatedAt: "3일 전",
    wordCount: 980,
    status: "작성 중",
    score: null,
  },
];

/* ─── AI Feedback Mock ─── */
const aiFeedback = {
  overall: {
    score: 82,
    summary:
      "전반적으로 진로 동기와 학업 역량이 잘 드러나는 자소서입니다. 다만 구체적인 활동 사례와 성찰의 깊이를 더 보강하면 더욱 설득력 있는 글이 될 것입니다.",
  },
  strengths: [
    "진로 동기가 구체적인 경험에서 출발하여 설득력이 높음",
    "의학 분야에 대한 학문적 관심이 세특 활동과 일관되게 연결됨",
    "희귀질환 연구라는 구체적 목표가 차별화 요소로 작용",
  ],
  improvements: [
    {
      point: "2문단의 봉사활동 서술이 다소 추상적입니다",
      suggestion:
        '"어려운 환경의 이웃을 도왔다" → 구체적 장소, 대상, 본인의 역할을 명시하세요',
      example:
        '"OO복지관에서 6개월간 매주 토요일 장애 아동 학습 멘토링을 진행하며, 개별 학습 계획을 수립하고..."',
    },
    {
      point: "연구 경험 서술에서 본인의 기여도가 불명확합니다",
      suggestion:
        "팀 프로젝트에서 본인이 맡은 구체적 역할과 독자적 기여를 강조하세요",
      example:
        '"팀원 4명 중 데이터 분석을 전담하여, R을 활용한 통계 분석으로 유의미한 상관관계를 도출했습니다"',
    },
    {
      point: "마무리 문단이 다소 일반적인 포부로 끝납니다",
      suggestion:
        "입학 후 구체적 계획(수강 과목, 연구실, 프로그램)을 언급하여 실현 가능성을 보여주세요",
      example:
        '"입학 후 OO 교수님의 분자생물학 연구실에서 학부 연구생으로 참여하며..."',
    },
  ],
};

export default function DocumentTool() {
  const searchString = useSearch();
  const params = new URLSearchParams(searchString);
  const boardSlug = params.get("board");

  const [activeTab, setActiveTab] = useState<
    "workspace" | "saved" | "writing"
  >("workspace");
  const [selectedDocType, setSelectedDocType] = useState<string | null>(null);
  const [writingContent, setWritingContent] = useState("");
  const [showFeedback, setShowFeedback] = useState(false);
  const [isAnalyzing, setIsAnalyzing] = useState(false);

  const boardContext = boardSlug
    ? {
        name:
          boardSlug === "snu"
            ? "서울대"
            : boardSlug === "medicine"
            ? "의예과"
            : boardSlug,
        label: "보드 맥락 자동 적용",
      }
    : null;

  const handleAIReview = () => {
    if (!writingContent.trim()) {
      toast.error("내용을 먼저 작성해주세요");
      return;
    }
    setIsAnalyzing(true);
    setTimeout(() => {
      setIsAnalyzing(false);
      setShowFeedback(true);
      toast.success("AI 첨삭이 완료되었습니다");
    }, 2500);
  };

  const startWriting = (typeId: string) => {
    setSelectedDocType(typeId);
    setActiveTab("writing");
    setShowFeedback(false);
    setWritingContent("");
  };

  const docTypeInfo = docTypes.find((d) => d.id === selectedDocType);

  return (
    <div className="max-w-7xl mx-auto px-4 lg:px-8 py-6 lg:py-10">
      {/* Breadcrumb */}
      <div className="flex items-center gap-2 text-sm text-muted-foreground mb-6">
        {boardSlug ? (
          <>
            <Link href="/boards">
              <span className="hover:text-foreground ink-link flex items-center gap-1">
                <LayoutGrid size={14} />
                꿈 보드
              </span>
            </Link>
            <ChevronRight size={12} />
            <Link href={`/boards/${boardSlug}`}>
              <span className="hover:text-foreground ink-link">
                {boardContext?.name}
              </span>
            </Link>
            <ChevronRight size={12} />
          </>
        ) : (
          <>
            <Link href="/">
              <span className="hover:text-foreground ink-link">홈</span>
            </Link>
            <ChevronRight size={12} />
          </>
        )}
        <span className="text-foreground font-medium">AI 서류 도구</span>
      </div>

      {/* Header */}
      <div className="mb-8">
        <div className="flex items-center gap-3 mb-3">
          <div className="w-10 h-10 bg-blue-100 text-blue-600 rounded-lg flex items-center justify-center">
            <FileEdit size={20} />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-2xl font-bold tracking-tight">
                AI 서류 작성 도구
              </h1>
              <span className="inline-flex items-center gap-1 px-2 py-0.5 bg-dream/10 text-dream text-[10px] font-bold rounded-full">
                <Crown size={10} /> Premium
              </span>
            </div>
            <p className="text-sm text-muted-foreground">
              자소서 · 생기부 분석 · 학업계획서 — AI가 첨삭하고, 꿈이 방향을
              잡아줍니다
            </p>
          </div>
        </div>
        {/* Premium 무료 체험 안내 */}
        <div className="mt-3 p-3 bg-gradient-to-r from-dream/5 to-violet-50 border border-dream/20 rounded-lg flex items-center gap-3">
          <div className="w-8 h-8 bg-dream/10 rounded-full flex items-center justify-center shrink-0">
            <Sparkles size={14} className="text-dream" />
          </div>
          <div className="flex-1">
            <p className="text-xs font-semibold">무료 체험 1회 제공</p>
            <p className="text-[10px] text-muted-foreground">각 서류 유형별 1회 무료 AI 첨삭을 체험할 수 있습니다. 계속 이용하려면 Premium으로 업그레이드하세요.</p>
          </div>
          <Link href="/pricing">
            <span className="text-[10px] text-dream font-semibold hover:underline whitespace-nowrap">요금제 보기 →</span>
          </Link>
        </div>
        {boardContext && (
          <div className="inline-flex items-center gap-2 px-3 py-1.5 bg-dream/10 text-dream text-xs font-medium rounded-full">
            <Target size={12} />
            <span>
              "{boardContext.name}" 보드 맥락 자동 적용 — 지원 대학·학과가
              자동으로 반영됩니다
            </span>
          </div>
        )}
      </div>

      {/* Tab Navigation */}
      {activeTab !== "writing" && (
        <div className="flex gap-1 mb-6 border-b border-border">
          {[
            { id: "workspace" as const, label: "서류 작성" },
            { id: "saved" as const, label: "저장된 서류" },
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`px-4 py-2.5 text-sm font-medium border-b-2 transition-colors ${
                activeTab === tab.id
                  ? "border-dream text-dream"
                  : "border-transparent text-muted-foreground hover:text-foreground"
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>
      )}

      {/* ─── Workspace Tab ─── */}
      {activeTab === "workspace" && (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
          {docTypes.map((doc) => (
            <motion.div
              key={doc.id}
              whileHover={{ y: -4 }}
              className="bg-card border border-border rounded-xl p-6 cursor-pointer hover:border-dream/30 hover:shadow-md transition-all"
              onClick={() => startWriting(doc.id)}
            >
              <div
                className={`w-12 h-12 rounded-lg flex items-center justify-center mb-4 ${doc.color}`}
              >
                <doc.icon size={24} />
              </div>
              <h3 className="text-lg font-semibold mb-2">{doc.label}</h3>
              <p className="text-sm text-muted-foreground mb-4">
                {doc.description}
              </p>
              <div className="flex items-center gap-2 text-xs text-dream font-medium">
                <Plus size={14} />새 서류 작성하기
              </div>
            </motion.div>
          ))}
        </div>
      )}

      {/* ─── Saved Documents Tab ─── */}
      {activeTab === "saved" && (
        <div className="space-y-3">
          {savedDocs.map((doc) => {
            const typeInfo = docTypes.find((d) => d.id === doc.type);
            return (
              <motion.div
                key={doc.id}
                whileHover={{ x: 4 }}
                className="bg-card border border-border rounded-lg p-4 flex items-center gap-4 cursor-pointer hover:border-dream/30 transition-all"
                onClick={() => {
                  setSelectedDocType(doc.type);
                  setActiveTab("writing");
                  setWritingContent(
                    "고등학교 재학 기간 중 의학 분야에 대한 관심을 키워온 과정을 돌아보면, 가장 결정적인 계기는 고1 겨울 방학 때 참여한 의료 봉사활동이었습니다..."
                  );
                  setShowFeedback(doc.status === "첨삭 완료");
                }}
              >
                <div
                  className={`w-10 h-10 rounded-lg flex items-center justify-center shrink-0 ${typeInfo?.color}`}
                >
                  {typeInfo && <typeInfo.icon size={18} />}
                </div>
                <div className="flex-1 min-w-0">
                  <h4 className="text-sm font-semibold truncate">
                    {doc.title}
                  </h4>
                  <div className="flex items-center gap-3 mt-1 text-xs text-muted-foreground">
                    <span className="flex items-center gap-1">
                      <Clock size={10} />
                      {doc.updatedAt}
                    </span>
                    <span>{doc.wordCount}자</span>
                  </div>
                </div>
                <div className="flex items-center gap-3 shrink-0">
                  {doc.score !== null && (
                    <div className="text-right">
                      <div
                        className={`text-lg font-bold ${
                          doc.score >= 80
                            ? "text-emerald-600"
                            : doc.score >= 60
                            ? "text-amber-600"
                            : "text-red-500"
                        }`}
                      >
                        {doc.score}
                      </div>
                      <div className="text-[10px] text-muted-foreground">
                        AI 점수
                      </div>
                    </div>
                  )}
                  <span
                    className={`text-xs px-2 py-1 rounded-full ${
                      doc.status === "첨삭 완료"
                        ? "bg-emerald-50 text-emerald-600"
                        : doc.status === "분석 완료"
                        ? "bg-blue-50 text-blue-600"
                        : "bg-amber-50 text-amber-600"
                    }`}
                  >
                    {doc.status}
                  </span>
                </div>
              </motion.div>
            );
          })}
        </div>
      )}

      {/* ─── Writing Mode ─── */}
      {activeTab === "writing" && docTypeInfo && (
        <div>
          {/* Back button */}
          <button
            onClick={() => {
              setActiveTab("workspace");
              setShowFeedback(false);
            }}
            className="flex items-center gap-1.5 text-sm text-muted-foreground hover:text-foreground mb-4"
          >
            <ArrowLeft size={14} />
            서류 목록으로
          </button>

          <div className="grid grid-cols-1 lg:grid-cols-5 gap-6">
            {/* Left: Editor */}
            <div className="lg:col-span-3">
              <div className="bg-card border border-border rounded-xl overflow-hidden">
                {/* Editor Header */}
                <div className="flex items-center justify-between px-5 py-3 border-b border-border bg-secondary/30">
                  <div className="flex items-center gap-2">
                    <div
                      className={`w-7 h-7 rounded flex items-center justify-center ${docTypeInfo.color}`}
                    >
                      <docTypeInfo.icon size={14} />
                    </div>
                    <span className="text-sm font-semibold">
                      {docTypeInfo.label}
                    </span>
                    {boardContext && (
                      <span className="text-xs text-dream bg-dream/10 px-2 py-0.5 rounded-full">
                        {boardContext.name}
                      </span>
                    )}
                  </div>
                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => toast.info("저장 기능은 준비 중입니다")}
                      className="p-1.5 text-muted-foreground hover:text-foreground"
                    >
                      <Save size={14} />
                    </button>
                    <button
                      onClick={() => {
                        setWritingContent("");
                        setShowFeedback(false);
                      }}
                      className="p-1.5 text-muted-foreground hover:text-foreground"
                    >
                      <RotateCcw size={14} />
                    </button>
                  </div>
                </div>

                {/* Prompt Selection */}
                <div className="px-5 py-3 border-b border-border bg-secondary/10">
                  <p className="text-xs text-muted-foreground mb-2">
                    문항 선택
                  </p>
                  <div className="flex flex-wrap gap-2">
                    {docTypeInfo.prompts.map((prompt, i) => (
                      <button
                        key={i}
                        className="text-xs px-3 py-1.5 rounded-full border border-border hover:border-dream hover:text-dream transition-colors text-left max-w-xs truncate"
                        onClick={() =>
                          toast.info(`문항 ${i + 1}이 선택되었습니다`)
                        }
                      >
                        문항 {i + 1}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Text Editor */}
                <div className="p-5">
                  <textarea
                    value={writingContent}
                    onChange={(e) => setWritingContent(e.target.value)}
                    placeholder="여기에 서류 내용을 작성하세요. AI가 분석하고 첨삭해드립니다..."
                    className="w-full h-80 text-sm leading-relaxed resize-none outline-none bg-transparent placeholder:text-muted-foreground/50"
                  />
                </div>

                {/* Editor Footer */}
                <div className="flex items-center justify-between px-5 py-3 border-t border-border bg-secondary/10">
                  <span className="text-xs text-muted-foreground">
                    {writingContent.length}자
                  </span>
                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => {
                        navigator.clipboard.writeText(writingContent);
                        toast.success("클립보드에 복사되었습니다");
                      }}
                      className="flex items-center gap-1 text-xs text-muted-foreground hover:text-foreground px-2 py-1"
                    >
                      <Copy size={12} />
                      복사
                    </button>
                    <button
                      onClick={handleAIReview}
                      disabled={isAnalyzing}
                      className="flex items-center gap-1.5 px-4 py-2 bg-dream text-white text-sm font-medium rounded-lg hover:bg-dream/90 transition-colors disabled:opacity-50"
                    >
                      {isAnalyzing ? (
                        <>
                          <motion.div
                            animate={{ rotate: 360 }}
                            transition={{
                              repeat: Infinity,
                              duration: 1,
                              ease: "linear",
                            }}
                          >
                            <Sparkles size={14} />
                          </motion.div>
                          AI 분석 중...
                        </>
                      ) : (
                        <>
                          <Wand2 size={14} />
                          AI 첨삭 받기
                        </>
                      )}
                    </button>
                  </div>
                </div>
              </div>
            </div>

            {/* Right: AI Feedback Panel */}
            <div className="lg:col-span-2">
              <AnimatePresence mode="wait">
                {showFeedback ? (
                  <motion.div
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -20 }}
                    className="space-y-4"
                  >
                    {/* Score Card */}
                    <div className="bg-card border border-border rounded-xl p-5">
                      <div className="flex items-center gap-3 mb-3">
                        <div className="w-14 h-14 rounded-full bg-emerald-50 flex items-center justify-center">
                          <span className="text-2xl font-bold text-emerald-600">
                            {aiFeedback.overall.score}
                          </span>
                        </div>
                        <div>
                          <h3 className="text-sm font-semibold">
                            AI 종합 평가
                          </h3>
                          <div className="flex items-center gap-1 mt-0.5">
                            {[1, 2, 3, 4, 5].map((s) => (
                              <Star
                                key={s}
                                size={12}
                                className={
                                  s <= Math.round(aiFeedback.overall.score / 20)
                                    ? "text-amber-400 fill-amber-400"
                                    : "text-gray-200"
                                }
                              />
                            ))}
                          </div>
                        </div>
                      </div>
                      <p className="text-sm text-muted-foreground leading-relaxed">
                        {aiFeedback.overall.summary}
                      </p>
                    </div>

                    {/* Strengths */}
                    <div className="bg-card border border-border rounded-xl p-5">
                      <h3 className="flex items-center gap-2 text-sm font-semibold text-emerald-600 mb-3">
                        <CheckCircle2 size={16} />
                        강점
                      </h3>
                      <ul className="space-y-2">
                        {aiFeedback.strengths.map((s, i) => (
                          <li
                            key={i}
                            className="flex items-start gap-2 text-sm text-muted-foreground"
                          >
                            <span className="text-emerald-400 mt-0.5">•</span>
                            {s}
                          </li>
                        ))}
                      </ul>
                    </div>

                    {/* Improvements */}
                    <div className="bg-card border border-border rounded-xl p-5">
                      <h3 className="flex items-center gap-2 text-sm font-semibold text-amber-600 mb-3">
                        <Lightbulb size={16} />
                        개선 제안 ({aiFeedback.improvements.length}개)
                      </h3>
                      <div className="space-y-4">
                        {aiFeedback.improvements.map((item, i) => (
                          <div
                            key={i}
                            className="border-l-2 border-amber-300 pl-3"
                          >
                            <p className="text-sm font-medium flex items-center gap-1.5">
                              <AlertCircle
                                size={12}
                                className="text-amber-500"
                              />
                              {item.point}
                            </p>
                            <p className="text-xs text-muted-foreground mt-1">
                              {item.suggestion}
                            </p>
                            <div className="mt-2 p-2 bg-secondary/50 rounded text-xs text-foreground/80 italic">
                              예시: "{item.example}"
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  </motion.div>
                ) : (
                  <motion.div
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    className="bg-card border border-border rounded-xl p-8 text-center"
                  >
                    <div className="w-16 h-16 mx-auto mb-4 bg-secondary/50 rounded-full flex items-center justify-center">
                      <Wand2 size={24} className="text-muted-foreground" />
                    </div>
                    <h3 className="text-sm font-semibold mb-2">
                      AI 첨삭 대기 중
                    </h3>
                    <p className="text-xs text-muted-foreground leading-relaxed">
                      서류를 작성한 후 "AI 첨삭 받기" 버튼을 누르면
                      <br />
                      종합 평가, 강점, 구체적 개선 제안을 받을 수 있습니다.
                    </p>
                    {boardContext && (
                      <div className="mt-4 p-3 bg-dream/5 rounded-lg">
                        <p className="text-xs text-dream font-medium">
                          "{boardContext.name}" 보드 맥락이 적용되어
                          <br />
                          해당 대학·학과에 맞춤화된 첨삭을 제공합니다.
                        </p>
                      </div>
                    )}
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
