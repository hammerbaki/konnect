/*
 * 3안 Write — 보드 선택 + 글 유형 선택
 * Design: Inkwell — Editorial Ink & Paper
 */
import { useState } from "react";
import { useLocation } from "wouter";
import { motion } from "framer-motion";
import {
  PenLine,
  Send,
  Image,
  Link as LinkIcon,
  Bold,
  Italic,
  FileText,
  MessageSquare,
  Star,
  Heart,
  Target,
  ChevronDown,
} from "lucide-react";
import { toast } from "sonner";

/* ─── Boards for selection ─── */
const boardOptions = [
  { slug: "snu-medicine", name: "서울대 의대", type: "대학" },
  { slug: "snu", name: "서울대", type: "대학" },
  { slug: "yonsei", name: "연세대", type: "대학" },
  { slug: "korea-univ", name: "고려대", type: "대학" },
  { slug: "medicine", name: "의예과", type: "학과" },
  { slug: "cs", name: "컴퓨터공학", type: "학과" },
  { slug: "business", name: "경영학", type: "학과" },
  { slug: "doctor", name: "의사", type: "직업" },
  { slug: "lawyer", name: "변호사", type: "직업" },
  { slug: "developer", name: "개발자", type: "직업" },
  { slug: "reconnect", name: "다시, 잇다", type: "특수" },
  { slug: "n-soo", name: "N수생 라운지", type: "특수" },
  { slug: "study-group", name: "스터디 모집", type: "특수" },
];

/* ─── Post Types ─── */
const postTypeOptions = [
  { key: "info", label: "정보", icon: FileText, description: "유용한 정보를 공유합니다" },
  { key: "question", label: "질문", icon: MessageSquare, description: "궁금한 것을 물어봅니다" },
  { key: "review", label: "후기", icon: Star, description: "경험과 후기를 나눕니다" },
  { key: "cheer", label: "응원", icon: Heart, description: "서로 응원하고 격려합니다" },
  { key: "milestone", label: "이정표", icon: Target, description: "목표 달성을 인증합니다" },
];

const categories = ["인강 리뷰", "문제집 리뷰", "학원 리뷰", "수시", "정시", "학종", "수능 팁", "상담", "스터디", "자유"];

export default function Write() {
  const [, navigate] = useLocation();
  const [title, setTitle] = useState("");
  const [content, setContent] = useState("");
  const [category, setCategory] = useState("");
  const [selectedBoard, setSelectedBoard] = useState("");
  const [postType, setPostType] = useState("");
  const [boardDropdownOpen, setBoardDropdownOpen] = useState(false);

  const handleSubmit = () => {
    if (!title.trim() || !content.trim()) {
      toast.error("제목과 내용을 모두 입력해주세요.");
      return;
    }
    if (!selectedBoard) {
      toast.error("게시할 보드를 선택해주세요.");
      return;
    }
    if (!postType) {
      toast.error("글 유형을 선택해주세요.");
      return;
    }
    toast.success("게시글이 등록되었습니다! (+10 KNC)");
    navigate(`/boards/${selectedBoard}`);
  };

  const selectedBoardInfo = boardOptions.find((b) => b.slug === selectedBoard);

  return (
    <div className="max-w-3xl mx-auto px-4 lg:px-6 py-6">
      <div className="flex items-center gap-2 mb-4">
        <PenLine size={20} />
        <h1 className="editorial-heading text-2xl">글쓰기</h1>
      </div>
      <hr className="editorial-divider-thick mt-0" />

      <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="space-y-5">
        {/* Board Selection */}
        <div>
          <label className="text-xs font-semibold tracking-wider uppercase block mb-2">
            보드 선택 <span className="text-vermillion">*</span>
          </label>
          <div className="relative">
            <button
              onClick={() => setBoardDropdownOpen(!boardDropdownOpen)}
              className="w-full flex items-center justify-between px-4 py-2.5 text-sm border border-border bg-transparent hover:border-foreground transition-colors text-left"
            >
              {selectedBoardInfo ? (
                <span>
                  <span className="font-semibold">{selectedBoardInfo.name}</span>
                  <span className="text-[10px] text-muted-foreground ml-2">{selectedBoardInfo.type}</span>
                </span>
              ) : (
                <span className="text-muted-foreground">게시할 보드를 선택하세요</span>
              )}
              <ChevronDown size={14} className={`text-muted-foreground transition-transform ${boardDropdownOpen ? "rotate-180" : ""}`} />
            </button>
            {boardDropdownOpen && (
              <div className="absolute z-10 w-full mt-1 bg-background border border-border shadow-lg max-h-60 overflow-y-auto">
                {boardOptions.map((board) => (
                  <button
                    key={board.slug}
                    onClick={() => { setSelectedBoard(board.slug); setBoardDropdownOpen(false); }}
                    className={`w-full text-left px-4 py-2 text-sm hover:bg-secondary transition-colors flex items-center justify-between ${
                      selectedBoard === board.slug ? "bg-secondary font-semibold" : ""
                    }`}
                  >
                    <span>{board.name}</span>
                    <span className="text-[10px] text-muted-foreground">{board.type}</span>
                  </button>
                ))}
              </div>
            )}
          </div>
        </div>

        {/* Post Type */}
        <div>
          <label className="text-xs font-semibold tracking-wider uppercase block mb-2">
            글 유형 <span className="text-vermillion">*</span>
          </label>
          <div className="grid grid-cols-2 sm:grid-cols-5 gap-2">
            {postTypeOptions.map((pt) => (
              <button
                key={pt.key}
                onClick={() => setPostType(pt.key)}
                className={`flex flex-col items-center gap-1 px-3 py-2.5 text-xs transition-all border ${
                  postType === pt.key
                    ? "bg-foreground text-background font-semibold border-foreground"
                    : "border-border text-muted-foreground hover:text-foreground hover:border-foreground/50"
                }`}
              >
                <pt.icon size={14} />
                <span>{pt.label}</span>
              </button>
            ))}
          </div>
        </div>

        {/* Category */}
        <div>
          <label className="text-xs font-semibold tracking-wider uppercase block mb-2">
            카테고리 태그
          </label>
          <div className="flex gap-2 flex-wrap">
            {categories.map((cat) => (
              <button
                key={cat}
                onClick={() => setCategory(category === cat ? "" : cat)}
                className={`px-3 py-1.5 text-xs transition-all ${
                  category === cat
                    ? "bg-foreground text-background font-semibold"
                    : "border border-border text-muted-foreground hover:text-foreground"
                }`}
              >
                {cat}
              </button>
            ))}
          </div>
        </div>

        {/* Title */}
        <div>
          <label className="text-xs font-semibold tracking-wider uppercase block mb-2">
            제목 <span className="text-vermillion">*</span>
          </label>
          <input
            type="text"
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            placeholder="제목을 입력하세요"
            className="w-full px-4 py-3 text-lg font-serif font-bold border border-border bg-transparent focus:border-foreground outline-none transition-colors placeholder:text-muted-foreground/50"
          />
        </div>

        {/* Toolbar */}
        <div className="flex items-center gap-1 border border-border p-1">
          <button className="p-2 hover:bg-secondary transition-colors" onClick={() => toast.info("서식 기능은 준비 중입니다")}>
            <Bold size={14} />
          </button>
          <button className="p-2 hover:bg-secondary transition-colors" onClick={() => toast.info("서식 기능은 준비 중입니다")}>
            <Italic size={14} />
          </button>
          <div className="w-px h-5 bg-border mx-1" />
          <button className="p-2 hover:bg-secondary transition-colors" onClick={() => toast.info("이미지 업로드는 준비 중입니다")}>
            <Image size={14} />
          </button>
          <button className="p-2 hover:bg-secondary transition-colors" onClick={() => toast.info("링크 삽입은 준비 중입니다")}>
            <LinkIcon size={14} />
          </button>
        </div>

        {/* Content */}
        <div>
          <textarea
            value={content}
            onChange={(e) => setContent(e.target.value)}
            placeholder="내용을 입력하세요..."
            rows={15}
            className="w-full px-4 py-3 text-sm border border-border bg-transparent focus:border-foreground outline-none transition-colors resize-none leading-relaxed placeholder:text-muted-foreground/50"
          />
        </div>

        {/* Credit Notice */}
        <div className="p-3 bg-gold/5 border border-gold/20 flex items-center gap-2">
          <span className="credit-badge text-xs">+10 KNC</span>
          <span className="text-xs text-muted-foreground">게시글 작성 시 10 크레딧이 지급됩니다.</span>
        </div>

        {/* Submit */}
        <div className="flex items-center justify-end gap-3">
          <button
            onClick={() => navigate(selectedBoard ? `/boards/${selectedBoard}` : "/boards")}
            className="px-4 py-2 text-sm text-muted-foreground hover:text-foreground transition-colors"
          >
            취소
          </button>
          <button
            onClick={handleSubmit}
            className="inline-flex items-center gap-1.5 px-6 py-2 text-sm bg-foreground text-background hover:bg-foreground/90 transition-colors font-semibold"
          >
            <Send size={14} /> 등록
          </button>
        </div>
      </motion.div>
    </div>
  );
}
