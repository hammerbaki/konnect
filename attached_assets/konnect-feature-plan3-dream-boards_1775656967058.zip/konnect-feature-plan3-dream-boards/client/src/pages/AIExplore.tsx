/*
 * 3안 보완 — AI 탐색 엔진 (AI Explore)
 * 시맨틱 검색 + 꿈 기반 맞춤 추천 + 보드 맥락화
 * 기존 Explore.tsx와 별도로, AI 기반 딥 탐색 전용 페이지
 */
import { useState } from "react";
import { Link, useSearch } from "wouter";
import { motion, AnimatePresence } from "framer-motion";
import {
  Search,
  Compass,
  ChevronRight,
  LayoutGrid,
  Sparkles,
  Target,
  GraduationCap,
  Building2,
  BookOpen,
  Users,
  TrendingUp,
  Star,
  ArrowRight,
  Lightbulb,
  Zap,
  Filter,
  MapPin,
} from "lucide-react";
import { toast } from "sonner";

/* ─── Recommended Paths (dream-based) ─── */
const dreamPaths = [
  {
    id: 1,
    title: "도전 경로",
    subtitle: "꿈에 가장 가까운 길",
    university: "서울대학교 의예과",
    match: 92,
    color: "from-blue-500 to-blue-600",
    details: {
      admission: "수시 학생부종합 (일반전형)",
      gpa: "1.2 이내",
      activities: "의학 관련 세특 + 연구 경험",
      interview: "심층 면접 (MMI 형식)",
    },
  },
  {
    id: 2,
    title: "현실 경로",
    subtitle: "합격 가능성이 높은 길",
    university: "연세대학교 의예과",
    match: 85,
    color: "from-emerald-500 to-emerald-600",
    details: {
      admission: "수시 학생부종합 (활동우수형)",
      gpa: "1.5 이내",
      activities: "교과 성적 + 비교과 활동",
      interview: "인성 면접 + 적성 면접",
    },
  },
  {
    id: 3,
    title: "발견 경로",
    subtitle: "새로운 가능성의 길",
    university: "KAIST 바이오및뇌공학과",
    match: 78,
    color: "from-purple-500 to-purple-600",
    details: {
      admission: "수시 학생부종합 (일반전형)",
      gpa: "1.8 이내",
      activities: "수학·과학 심화 + 연구 프로젝트",
      interview: "구술 면접 (수학·과학)",
    },
  },
];

/* ─── Search results mock ─── */
const searchResults = [
  {
    type: "대학",
    title: "서울대학교 의예과",
    description:
      "2026학년도 수시 모집요강 기준, 학생부종합 일반전형 40명 모집. 1단계 서류 3배수 → 2단계 면접.",
    tags: ["수시", "학생부종합", "면접"],
    relevance: 95,
  },
  {
    type: "입시정보",
    title: "2026 의대 입시 변화 총정리",
    description:
      "의대 증원에 따른 2026학년도 입시 변화. 서울대 40→45명, 연세대 40→48명 등 주요 변경사항.",
    tags: ["의대", "증원", "2026"],
    relevance: 88,
  },
  {
    type: "전형",
    title: "학생부종합전형 평가요소 분석",
    description:
      "학업역량, 진로역량, 공동체역량 3대 평가요소별 세부 항목과 준비 전략.",
    tags: ["학종", "평가요소", "전략"],
    relevance: 82,
  },
  {
    type: "통계",
    title: "서울대 의예과 합격자 분석 (2025)",
    description:
      "2025학년도 합격자 내신 평균 1.18, 비교과 활동 평균 12.3개, 주요 세특 키워드 분석.",
    tags: ["합격자", "통계", "분석"],
    relevance: 79,
  },
  {
    type: "커뮤니티",
    title: "서울대 의예과 합격 수기 모음",
    description:
      "실제 합격생들의 준비 과정, 면접 후기, 생기부 구성 전략 등 생생한 경험담.",
    tags: ["합격수기", "면접후기", "경험"],
    relevance: 75,
  },
];

/* ─── Trending searches ─── */
const trendingSearches = [
  "2026 의대 수시 전형",
  "서울대 면접 기출",
  "생기부 세특 작성법",
  "학종 비교과 활동 추천",
  "의예과 합격자 내신",
  "자소서 작성 팁",
];

export default function AIExplore() {
  const searchString = useSearch();
  const params = new URLSearchParams(searchString);
  const boardSlug = params.get("board");

  const [query, setQuery] = useState("");
  const [hasSearched, setHasSearched] = useState(false);
  const [isSearching, setIsSearching] = useState(false);
  const [expandedPath, setExpandedPath] = useState<number | null>(null);

  const boardContext = boardSlug
    ? {
        name:
          boardSlug === "snu"
            ? "서울대"
            : boardSlug === "medicine"
            ? "의예과"
            : boardSlug,
      }
    : null;

  const handleSearch = (searchQuery?: string) => {
    const q = searchQuery || query;
    if (!q.trim()) return;
    setQuery(q);
    setIsSearching(true);
    setTimeout(() => {
      setIsSearching(false);
      setHasSearched(true);
    }, 1500);
  };

  return (
    <div className="max-w-7xl mx-auto px-4 lg:px-8 py-6 lg:py-10">
      {/* Breadcrumb */}
      <div className="flex items-center gap-2 text-sm text-muted-foreground mb-6">
        {boardSlug ? (
          <>
            <Link href="/boards">
              <span className="hover:text-foreground ink-link flex items-center gap-1">
                <LayoutGrid size={14} />
                꿈 보드
              </span>
            </Link>
            <ChevronRight size={12} />
            <Link href={`/boards/${boardSlug}`}>
              <span className="hover:text-foreground ink-link">
                {boardContext?.name}
              </span>
            </Link>
            <ChevronRight size={12} />
          </>
        ) : (
          <>
            <Link href="/">
              <span className="hover:text-foreground ink-link">홈</span>
            </Link>
            <ChevronRight size={12} />
          </>
        )}
        <span className="text-foreground font-medium">AI 탐색 엔진</span>
      </div>

      {/* Header */}
      <div className="mb-8">
        <div className="flex items-center gap-3 mb-3">
          <div className="w-10 h-10 bg-teal-100 text-teal-600 rounded-lg flex items-center justify-center">
            <Compass size={20} />
          </div>
          <div>
            <h1 className="text-2xl font-bold tracking-tight">
              AI 탐색 엔진
            </h1>
            <p className="text-sm text-muted-foreground">
              시맨틱 검색으로 대학·전형·입시 정보를 깊이 있게 탐색하세요
            </p>
          </div>
        </div>
        {boardContext && (
          <div className="inline-flex items-center gap-2 px-3 py-1.5 bg-dream/10 text-dream text-xs font-medium rounded-full">
            <Target size={12} />
            <span>
              "{boardContext.name}" 보드 맥락 — 검색 결과가 자동 맞춤화됩니다
            </span>
          </div>
        )}
      </div>

      {/* Search Bar */}
      <div className="relative mb-8">
        <div className="relative">
          <Search
            size={18}
            className="absolute left-4 top-1/2 -translate-y-1/2 text-muted-foreground"
          />
          <input
            type="text"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            onKeyDown={(e) => e.key === "Enter" && handleSearch()}
            placeholder={
              boardContext
                ? `"${boardContext.name}" 관련 정보를 검색하세요...`
                : "대학, 전형, 입시 정보를 검색하세요..."
            }
            className="w-full pl-11 pr-28 py-4 text-base border border-border rounded-xl outline-none focus:border-teal-400 focus:ring-2 focus:ring-teal-100 bg-card transition-all"
          />
          <button
            onClick={() => handleSearch()}
            disabled={isSearching}
            className="absolute right-2 top-1/2 -translate-y-1/2 flex items-center gap-1.5 px-4 py-2 bg-teal-600 text-white text-sm font-medium rounded-lg hover:bg-teal-700 transition-colors disabled:opacity-50"
          >
            {isSearching ? (
              <>
                <motion.div
                  animate={{ rotate: 360 }}
                  transition={{
                    repeat: Infinity,
                    duration: 1,
                    ease: "linear",
                  }}
                >
                  <Sparkles size={14} />
                </motion.div>
                검색 중...
              </>
            ) : (
              <>
                <Sparkles size={14} />
                AI 검색
              </>
            )}
          </button>
        </div>

        {/* Trending Searches */}
        {!hasSearched && (
          <div className="mt-3 flex flex-wrap gap-2">
            <span className="text-xs text-muted-foreground">인기 검색:</span>
            {trendingSearches.map((term) => (
              <button
                key={term}
                onClick={() => handleSearch(term)}
                className="text-xs px-2.5 py-1 bg-secondary rounded-full hover:bg-secondary/80 text-muted-foreground hover:text-foreground transition-colors"
              >
                {term}
              </button>
            ))}
          </div>
        )}
      </div>

      {/* ─── Before Search: Dream Paths ─── */}
      {!hasSearched && (
        <div>
          <h2 className="text-lg font-semibold mb-4 flex items-center gap-2">
            <Target size={18} className="text-dream" />
            나의 꿈 기반 추천 경로
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-5 mb-10">
            {dreamPaths.map((path) => (
              <motion.div
                key={path.id}
                whileHover={{ y: -4 }}
                className="bg-card border border-border rounded-xl overflow-hidden cursor-pointer hover:shadow-md transition-all"
                onClick={() =>
                  setExpandedPath(expandedPath === path.id ? null : path.id)
                }
              >
                <div
                  className={`h-2 bg-gradient-to-r ${path.color}`}
                />
                <div className="p-5">
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-xs font-semibold text-dream">
                      {path.title}
                    </span>
                    <span className="text-xs font-bold text-emerald-600">
                      매칭 {path.match}%
                    </span>
                  </div>
                  <h3 className="text-base font-semibold mb-1">
                    {path.university}
                  </h3>
                  <p className="text-xs text-muted-foreground">
                    {path.subtitle}
                  </p>

                  <AnimatePresence>
                    {expandedPath === path.id && (
                      <motion.div
                        initial={{ height: 0, opacity: 0 }}
                        animate={{ height: "auto", opacity: 1 }}
                        exit={{ height: 0, opacity: 0 }}
                        className="overflow-hidden"
                      >
                        <div className="mt-4 pt-4 border-t border-border space-y-2">
                          {Object.entries(path.details).map(([key, val]) => (
                            <div
                              key={key}
                              className="flex items-start gap-2 text-xs"
                            >
                              <span className="text-muted-foreground w-16 shrink-0">
                                {key === "admission"
                                  ? "전형"
                                  : key === "gpa"
                                  ? "내신"
                                  : key === "activities"
                                  ? "활동"
                                  : "면접"}
                              </span>
                              <span className="text-foreground">{val}</span>
                            </div>
                          ))}
                        </div>
                      </motion.div>
                    )}
                  </AnimatePresence>
                </div>
              </motion.div>
            ))}
          </div>

          {/* Quick Explore Categories */}
          <h2 className="text-lg font-semibold mb-4">빠른 탐색</h2>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
            {[
              {
                icon: Building2,
                label: "대학별 정보",
                color: "text-blue-600 bg-blue-50",
              },
              {
                icon: BookOpen,
                label: "전형 분석",
                color: "text-emerald-600 bg-emerald-50",
              },
              {
                icon: TrendingUp,
                label: "입시 통계",
                color: "text-purple-600 bg-purple-50",
              },
              {
                icon: Users,
                label: "합격 수기",
                color: "text-amber-600 bg-amber-50",
              },
            ].map((cat) => (
              <motion.div
                key={cat.label}
                whileHover={{ y: -2 }}
                className="bg-card border border-border rounded-lg p-4 cursor-pointer hover:border-teal-300 transition-all text-center"
                onClick={() => handleSearch(cat.label)}
              >
                <div
                  className={`w-10 h-10 rounded-lg flex items-center justify-center mx-auto mb-2 ${cat.color}`}
                >
                  <cat.icon size={20} />
                </div>
                <span className="text-sm font-medium">{cat.label}</span>
              </motion.div>
            ))}
          </div>
        </div>
      )}

      {/* ─── After Search: Results ─── */}
      {hasSearched && (
        <div>
          <div className="flex items-center justify-between mb-4">
            <p className="text-sm text-muted-foreground">
              "<span className="text-foreground font-medium">{query}</span>"에
              대한 AI 검색 결과 ({searchResults.length}건)
            </p>
            <button
              onClick={() => {
                setHasSearched(false);
                setQuery("");
              }}
              className="text-xs text-muted-foreground hover:text-foreground"
            >
              초기화
            </button>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* Results List */}
            <div className="lg:col-span-2 space-y-3">
              {searchResults.map((result, i) => (
                <motion.div
                  key={i}
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: i * 0.1 }}
                  className="bg-card border border-border rounded-lg p-4 hover:border-teal-300 transition-all cursor-pointer"
                  onClick={() => toast.info("상세 페이지는 준비 중입니다")}
                >
                  <div className="flex items-center gap-2 mb-2">
                    <span className="text-[10px] font-semibold px-2 py-0.5 bg-secondary rounded text-muted-foreground">
                      {result.type}
                    </span>
                    <span className="text-[10px] text-teal-600 font-medium">
                      관련도 {result.relevance}%
                    </span>
                  </div>
                  <h3 className="text-sm font-semibold mb-1">{result.title}</h3>
                  <p className="text-xs text-muted-foreground leading-relaxed mb-2">
                    {result.description}
                  </p>
                  <div className="flex flex-wrap gap-1.5">
                    {result.tags.map((tag) => (
                      <span
                        key={tag}
                        className="text-[10px] px-2 py-0.5 bg-teal-50 text-teal-600 rounded-full"
                      >
                        #{tag}
                      </span>
                    ))}
                  </div>
                </motion.div>
              ))}
            </div>

            {/* Sidebar: AI Summary */}
            <div className="space-y-4">
              <div className="bg-card border border-teal-200 rounded-xl p-5">
                <h3 className="flex items-center gap-2 text-sm font-semibold text-teal-600 mb-3">
                  <Sparkles size={14} />
                  AI 요약
                </h3>
                <p className="text-sm text-muted-foreground leading-relaxed">
                  "{query}"에 대한 핵심 정보를 요약하면, 2026학년도 의대 입시는
                  증원 영향으로 경쟁률 변화가 예상됩니다. 서울대 의예과는
                  학생부종합 일반전형으로 45명을 모집하며, 1단계 서류 3배수 →
                  2단계 면접으로 선발합니다.
                </p>
              </div>

              <div className="bg-card border border-border rounded-xl p-5">
                <h3 className="flex items-center gap-2 text-sm font-semibold mb-3">
                  <Lightbulb size={14} className="text-amber-500" />
                  관련 검색어
                </h3>
                <div className="space-y-2">
                  {[
                    "서울대 의예과 면접 기출",
                    "의대 학생부종합 준비 전략",
                    "2026 의대 증원 현황",
                    "의예과 합격자 생기부 분석",
                  ].map((term) => (
                    <button
                      key={term}
                      onClick={() => handleSearch(term)}
                      className="flex items-center gap-2 w-full text-left text-xs text-muted-foreground hover:text-foreground py-1.5 transition-colors"
                    >
                      <Search size={10} />
                      {term}
                    </button>
                  ))}
                </div>
              </div>

              {boardSlug && (
                <Link href={`/boards/${boardSlug}`}>
                  <span className="flex items-center justify-center gap-1.5 w-full px-4 py-2.5 text-sm bg-dream text-white rounded-lg hover:bg-dream/90 transition-colors">
                    <LayoutGrid size={14} />
                    보드로 돌아가기
                  </span>
                </Link>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
