/*
 * Design: Inkwell — Editorial Ink & Paper
 * - Product detail with editorial layout
 * - Purchase with credits or cash
 */
import { useState } from "react";
import { Link, useParams } from "wouter";
import { motion } from "framer-motion";
import {
  ArrowLeft,
  Star,
  Coins,
  ShoppingBag,
  BookOpen,
  Video,
  Heart,
  Share2,
  CheckCircle,
} from "lucide-react";
import { toast } from "sonner";

const productsData: Record<string, { title: string; author: string; category: string; type: string; price: number; discount: number; rating: number; reviews: number; sales: number; desc: string; creditPrice: number; features: string[]; toc: string[] }> = {
  "1": {
    title: "국어 1등급을 정말 원한다면",
    author: "김국어",
    category: "국어",
    type: "교재",
    price: 31000,
    discount: 10,
    rating: 4.8,
    reviews: 128,
    sales: 2340,
    creditPrice: 280,
    desc: "수능 국어 1등급을 위한 체계적 학습 가이드입니다. 비문학, 문학, 화법과 작문 전 영역을 커버하며, 기출 분석을 통해 출제 패턴을 파악하고 실전 감각을 기를 수 있습니다.",
    features: ["비문학 독해 7단계 전략", "문학 감상법 체계화", "화법과 작문 만점 공식", "최근 5개년 기출 분석", "실전 모의고사 3회분 포함"],
    toc: ["Chapter 1. 비문학 독해의 기본기", "Chapter 2. 비문학 유형별 전략", "Chapter 3. 현대시 감상법", "Chapter 4. 현대소설 분석법", "Chapter 5. 고전문학 접근법", "Chapter 6. 화법과 작문", "Chapter 7. 실전 모의고사"],
  },
};

const defaultProduct = {
  title: "상품을 찾을 수 없습니다",
  author: "",
  category: "",
  type: "",
  price: 0,
  discount: 0,
  rating: 0,
  reviews: 0,
  sales: 0,
  creditPrice: 0,
  desc: "",
  features: [],
  toc: [],
};

export default function ProductDetail() {
  const params = useParams<{ id: string }>();
  const product = productsData[params.id || ""] || defaultProduct;
  const [payMethod, setPayMethod] = useState<"credit" | "cash">("credit");
  const finalPrice = Math.round(product.price * (1 - product.discount / 100));

  const handlePurchase = () => {
    toast.success(
      payMethod === "credit"
        ? `${product.creditPrice} KNC로 구매가 완료되었습니다!`
        : `${finalPrice.toLocaleString()}원 결제가 완료되었습니다!`
    );
  };

  return (
    <div className="container py-6 max-w-4xl mx-auto">
      <Link href="/market">
        <span className="inline-flex items-center gap-1 text-sm text-muted-foreground hover:text-foreground mb-4">
          <ArrowLeft size={14} /> 마켓으로 돌아가기
        </span>
      </Link>

      <hr className="editorial-divider-double" />

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
      >
        <div className="grid md:grid-cols-[2fr_1fr] gap-8">
          {/* Left: Product Info */}
          <div>
            <div className="flex items-center gap-2 mb-3">
              <span className="ink-tag text-[10px]">{product.category}</span>
              <span className="ink-tag-filled bg-secondary text-[10px] flex items-center gap-0.5">
                {product.type === "강의" ? <Video size={10} /> : <BookOpen size={10} />}
                {product.type}
              </span>
            </div>
            <h1 className="editorial-heading text-2xl md:text-3xl mb-2">
              {product.title}
            </h1>
            <p className="text-sm text-muted-foreground mb-4">{product.author}</p>

            {/* Rating */}
            <div className="flex items-center gap-2 mb-6">
              <div className="flex items-center gap-0.5">
                {[...Array(5)].map((_, i) => (
                  <Star
                    key={i}
                    size={14}
                    className={
                      i < Math.floor(product.rating)
                        ? "text-gold fill-gold"
                        : "text-border"
                    }
                  />
                ))}
              </div>
              <span className="text-sm font-semibold">{product.rating}</span>
              <span className="text-xs text-muted-foreground">
                ({product.reviews}개 리뷰)
              </span>
              <span className="text-xs text-muted-foreground">
                · {product.sales.toLocaleString()}명 구매
              </span>
            </div>

            <hr className="editorial-divider-thick" />

            {/* Description */}
            <div className="mt-4 mb-6">
              <h2 className="editorial-heading text-lg mb-3">소개</h2>
              <p className="text-sm leading-relaxed text-foreground/80">
                {product.desc}
              </p>
            </div>

            {/* Features */}
            {product.features.length > 0 && (
              <div className="mb-6">
                <h2 className="editorial-heading text-lg mb-3">특징</h2>
                <div className="space-y-2">
                  {product.features.map((f, i) => (
                    <div key={i} className="flex items-start gap-2">
                      <CheckCircle size={14} className="text-indigo mt-0.5 shrink-0" />
                      <span className="text-sm">{f}</span>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* TOC */}
            {product.toc.length > 0 && (
              <div className="mb-6">
                <h2 className="editorial-heading text-lg mb-3">목차</h2>
                <div className="space-y-1">
                  {product.toc.map((item, i) => (
                    <div
                      key={i}
                      className="flex items-center gap-2 py-1.5 border-b border-border last:border-0"
                    >
                      <span className="text-[10px] text-muted-foreground w-6">
                        {String(i + 1).padStart(2, "0")}
                      </span>
                      <span className="text-sm">{item}</span>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>

          {/* Right: Purchase Card */}
          <div className="md:sticky md:top-20 self-start">
            <div className="border border-border p-5 bg-card">
              <h3 className="text-xs font-semibold tracking-wider uppercase mb-4">
                구매하기
              </h3>

              {/* Price */}
              <div className="mb-4">
                {product.discount > 0 && (
                  <div className="flex items-center gap-2 mb-1">
                    <span className="text-sm text-muted-foreground line-through">
                      {product.price.toLocaleString()}원
                    </span>
                    <span className="text-xs text-vermillion font-bold">
                      -{product.discount}%
                    </span>
                  </div>
                )}
                <span className="editorial-heading text-2xl">
                  {finalPrice.toLocaleString()}원
                </span>
              </div>

              {/* Payment Method */}
              <div className="space-y-2 mb-4">
                <button
                  onClick={() => setPayMethod("credit")}
                  className={`w-full flex items-center gap-2 p-3 text-sm transition-all ${
                    payMethod === "credit"
                      ? "border-2 border-gold bg-gold/5"
                      : "border border-border"
                  }`}
                >
                  <Coins size={16} className="text-gold" />
                  <div className="text-left flex-1">
                    <p className="font-semibold">크레딧 결제</p>
                    <p className="text-[10px] text-muted-foreground">
                      {product.creditPrice} KNC (추가 5% 할인)
                    </p>
                  </div>
                  {payMethod === "credit" && (
                    <CheckCircle size={16} className="text-gold" />
                  )}
                </button>
                <button
                  onClick={() => setPayMethod("cash")}
                  className={`w-full flex items-center gap-2 p-3 text-sm transition-all ${
                    payMethod === "cash"
                      ? "border-2 border-foreground"
                      : "border border-border"
                  }`}
                >
                  <ShoppingBag size={16} />
                  <div className="text-left flex-1">
                    <p className="font-semibold">일반 결제</p>
                    <p className="text-[10px] text-muted-foreground">
                      {finalPrice.toLocaleString()}원
                    </p>
                  </div>
                  {payMethod === "cash" && (
                    <CheckCircle size={16} />
                  )}
                </button>
              </div>

              {/* Purchase Button */}
              <button
                onClick={handlePurchase}
                className="w-full py-3 bg-foreground text-background text-sm font-semibold hover:bg-foreground/90 transition-colors mb-3"
              >
                {payMethod === "credit"
                  ? `${product.creditPrice} KNC로 구매`
                  : `${finalPrice.toLocaleString()}원 결제`}
              </button>

              {/* Actions */}
              <div className="flex items-center gap-2">
                <button
                  onClick={() => toast.success("위시리스트에 추가했습니다")}
                  className="flex-1 flex items-center justify-center gap-1 py-2 text-xs border border-border hover:border-foreground transition-colors"
                >
                  <Heart size={12} /> 찜하기
                </button>
                <button
                  onClick={() => toast.success("링크가 복사되었습니다")}
                  className="flex-1 flex items-center justify-center gap-1 py-2 text-xs border border-border hover:border-foreground transition-colors"
                >
                  <Share2 size={12} /> 공유
                </button>
              </div>
            </div>
          </div>
        </div>
      </motion.div>
    </div>
  );
}
