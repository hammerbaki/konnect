/*
 * Design: Neo-Brutalism + Gen-Z Energy
 * - Chat bubble UI with thick borders
 * - AI mentor "Kony" character
 * - Suggested question chips
 * - Typing indicator animation
 */
import { useState, useRef, useEffect, useCallback } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Send, Bot, User, Sparkles, ArrowDown } from "lucide-react";

interface Message {
  id: number;
  role: "user" | "assistant";
  content: string;
  timestamp: Date;
}

const suggestedQuestions = [
  "수시와 정시 중 어떤 전형이 유리할까요?",
  "내신 3등급으로 갈 수 있는 대학은?",
  "생기부 세특 어떻게 준비하면 좋을까요?",
  "면접 준비는 언제부터 시작해야 하나요?",
  "수능 D-100 학습 계획 세워주세요",
  "학종과 교과전형의 차이가 뭔가요?",
];

const aiResponses: Record<string, string> = {
  "수시와 정시 중 어떤 전형이 유리할까요?":
    "좋은 질문이에요! 🤔 수시와 정시 중 유리한 전형은 본인의 강점에 따라 달라져요.\n\n📌 **내신이 강하다면** → 수시 교과전형이 유리해요\n📌 **비교과 활동이 풍부하다면** → 수시 학종이 유리해요\n📌 **수능 실력이 뛰어나다면** → 정시가 유리해요\n\n보통 내신 1~3등급이면 수시를, 수능 모의고사 성적이 좋다면 정시를 중심으로 준비하는 것을 추천해요. 물론 수시와 정시를 병행하는 것이 가장 안전한 전략이에요! 💪",
  "내신 3등급으로 갈 수 있는 대학은?":
    "내신 3등급이면 충분히 좋은 대학에 진학할 수 있어요! 🎓\n\n**수시 교과전형 기준:**\n• 건국대, 동국대, 홍익대 일부 학과\n• 숭실대, 국민대, 세종대 다수 학과\n• 지방 거점 국립대(부산대, 경북대 등)\n\n**학종 기준:**\n• 내신 외 비교과 활동이 우수하면 더 상위 대학도 가능!\n\n**정시 기준:**\n• 수능 성적에 따라 크게 달라져요\n\n구체적인 성적과 희망 학과를 알려주시면 더 맞춤형 추천을 드릴 수 있어요! 📊",
  "생기부 세특 어떻게 준비하면 좋을까요?":
    "세특(세부능력 및 특기사항) 준비 꿀팁을 알려드릴게요! ✨\n\n**1단계: 진로와 연결하기**\n각 교과목에서 배운 내용을 희망 진로와 연결하는 탐구활동을 해보세요.\n\n**2단계: 깊이 있는 탐구**\n단순 조사가 아닌, 가설 설정 → 실험/분석 → 결론 도출의 과정을 보여주세요.\n\n**3단계: 수업 참여**\n발표, 토론, 모둠활동에 적극적으로 참여하고, 선생님께 질문을 많이 하세요.\n\n**4단계: 독서 연계**\n교과 관련 도서를 읽고 보고서를 작성하면 세특에 기록될 수 있어요.\n\n꾸준히 준비하면 분명 좋은 결과가 있을 거예요! 📚",
  "면접 준비는 언제부터 시작해야 하나요?":
    "면접 준비 시기와 방법을 알려드릴게요! 🎤\n\n**시기:**\n• 수시 원서 접수 후 (9월~) 본격 시작\n• 하지만 평소 시사 이슈 정리는 미리미리!\n\n**준비 방법:**\n1. **생기부 숙지**: 본인의 생기부를 완벽히 파악하세요\n2. **예상 질문 준비**: 지원 동기, 학업 계획, 세특 관련 질문\n3. **모의 면접**: 친구나 선생님과 연습\n4. **시사 이슈**: 지원 학과 관련 최신 이슈 정리\n5. **대학별 기출**: 각 대학의 면접 기출문제 분석\n\n면접은 연습량이 실력이에요! 화이팅! 💪",
  "수능 D-100 학습 계획 세워주세요":
    "수능 D-100 학습 전략을 알려드릴게요! ⏰\n\n**[국어]**\n• 기출문제 3개년 반복 풀이\n• 비문학 지문 매일 2개씩 연습\n• 문학 작품 정리 노트 만들기\n\n**[수학]**\n• 킬러 문항 유형별 정리\n• 오답노트 매일 복습\n• 주 2회 실전 모의고사\n\n**[영어]**\n• 매일 듣기 연습 30분\n• 빈칸추론, 순서배열 집중 훈련\n\n**[탐구]**\n• 개념 1회독 완료 후 기출 반복\n• 주요 실험/자료 해석 연습\n\n**일일 루틴:**\n🌅 6시 기상 → 📖 오전: 취약과목 → 🍚 점심 → 📝 오후: 기출풀이 → 🌙 저녁: 오답정리\n\n컨디션 관리도 중요해요! 충분한 수면 꼭 챙기세요 😊",
  "학종과 교과전형의 차이가 뭔가요?":
    "학종과 교과전형의 핵심 차이를 정리해드릴게요! 📋\n\n**학생부교과전형 (교과)**\n• 내신 성적이 가장 중요 (정량 평가)\n• 비교과 활동의 비중이 낮음\n• 수능 최저학력기준 있는 경우 많음\n• 내신 상위권에게 유리\n\n**학생부종합전형 (학종)**\n• 생기부 전체를 종합적으로 평가\n• 세특, 창체, 독서 등 비교과도 중요\n• 서류평가 + 면접 (대학에 따라 다름)\n• 내신이 다소 낮아도 비교과로 보완 가능\n\n**한 줄 요약:**\n교과 = 내신 성적 싸움 📊\n학종 = 나만의 스토리 싸움 📖\n\n본인의 강점에 맞는 전형을 선택하는 게 핵심이에요!",
};

function getAIResponse(userMessage: string): string {
  const matched = Object.entries(aiResponses).find(([key]) =>
    userMessage.includes(key.slice(0, 10))
  );
  if (matched) return matched[1];

  if (userMessage.includes("수능") || userMessage.includes("시험")) {
    return "수능 관련 질문이시군요! 🎯 수능은 매년 11월 셋째 주 목요일에 시행되며, 국어·수학·영어·탐구·제2외국어 영역으로 구성됩니다. 더 구체적인 질문을 해주시면 맞춤형 답변을 드릴 수 있어요!";
  }
  if (userMessage.includes("대학") || userMessage.includes("학교")) {
    return "대학 관련 궁금증이 있으시군요! 🏫 희망하시는 대학이나 학과, 현재 성적 등을 알려주시면 더 정확한 상담을 해드릴 수 있어요. 어떤 부분이 가장 궁금하신가요?";
  }
  if (userMessage.includes("스트레스") || userMessage.includes("힘들") || userMessage.includes("불안")) {
    return "입시 준비가 힘드시죠... 😢 충분히 이해해요. 고3 시기는 누구에게나 힘든 시간이에요.\n\n잠깐 심호흡을 해볼까요? 🌬️\n\n1. 4초 동안 숨을 들이쉬고\n2. 7초 동안 참고\n3. 8초 동안 내쉬세요\n\n지금 이 순간에도 열심히 준비하고 있는 당신이 정말 대단해요! 결과가 어떻든 이 과정 자체가 성장이에요. 언제든 이야기하고 싶을 때 찾아와 주세요 💙";
  }

  return "좋은 질문이에요! 😊 입시에 대해 더 자세히 알려드리고 싶은데, 조금 더 구체적으로 질문해 주시면 맞춤형 답변을 드릴 수 있어요.\n\n예를 들어:\n• 희망 대학/학과\n• 현재 내신/모의고사 성적\n• 관심 있는 전형 (수시/정시)\n\n등을 함께 알려주세요! 🎓";
}

export default function Chat() {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: 0,
      role: "assistant",
      content:
        "안녕하세요! 저는 AI 입시 멘토 **코니**예요 🎓\n\n입시에 대한 궁금한 점이 있으면 무엇이든 물어보세요! 수시, 정시, 학종, 면접 등 모든 입시 관련 상담을 도와드릴게요.\n\n아래 추천 질문을 눌러보거나, 직접 질문을 입력해 주세요!",
      timestamp: new Date(),
    },
  ]);
  const [input, setInput] = useState("");
  const [isTyping, setIsTyping] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  const scrollToBottom = useCallback(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, []);

  useEffect(() => {
    scrollToBottom();
  }, [messages, scrollToBottom]);

  const sendMessage = useCallback(
    (text: string) => {
      if (!text.trim()) return;

      const userMsg: Message = {
        id: Date.now(),
        role: "user",
        content: text.trim(),
        timestamp: new Date(),
      };
      setMessages((prev) => [...prev, userMsg]);
      setInput("");
      setIsTyping(true);

      setTimeout(() => {
        const response = getAIResponse(text);
        const aiMsg: Message = {
          id: Date.now() + 1,
          role: "assistant",
          content: response,
          timestamp: new Date(),
        };
        setMessages((prev) => [...prev, aiMsg]);
        setIsTyping(false);
      }, 1000 + Math.random() * 1000);
    },
    []
  );

  const handleSubmit = useCallback(
    (e: React.FormEvent) => {
      e.preventDefault();
      sendMessage(input);
    },
    [input, sendMessage]
  );

  return (
    <div className="container py-4 flex flex-col" style={{ height: "calc(100vh - 8rem)" }}>
      {/* Chat Header */}
      <div className="brutal-card bg-primary text-white p-4 rounded-lg mb-4 flex items-center gap-3">
        <div className="w-12 h-12 bg-konnect-yellow rounded-full border-3 border-white flex items-center justify-center">
          <Bot size={24} className="text-foreground" />
        </div>
        <div>
          <h2 className="font-display text-xl">AI 멘토 코니</h2>
          <p className="text-sm opacity-80 flex items-center gap-1">
            <span className="w-2 h-2 bg-green-400 rounded-full inline-block" />
            온라인 · 24시간 상담 가능
          </p>
        </div>
        <div className="ml-auto">
          <span className="brutal-tag bg-konnect-yellow text-foreground text-xs">
            <Sparkles size={12} className="inline mr-1" />
            AI
          </span>
        </div>
      </div>

      {/* Messages Area */}
      <div className="flex-1 overflow-y-auto space-y-4 pr-2">
        <AnimatePresence>
          {messages.map((msg) => (
            <motion.div
              key={msg.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className={`flex gap-3 ${msg.role === "user" ? "flex-row-reverse" : ""}`}
            >
              <div
                className={`w-8 h-8 rounded-full border-2 border-foreground flex items-center justify-center shrink-0 ${
                  msg.role === "assistant" ? "bg-konnect-blue text-white" : "bg-konnect-yellow"
                }`}
              >
                {msg.role === "assistant" ? <Bot size={16} /> : <User size={16} />}
              </div>
              <div
                className={`max-w-[80%] brutal-card p-4 rounded-lg ${
                  msg.role === "user"
                    ? "bg-primary text-white"
                    : "bg-white text-foreground"
                }`}
              >
                <div className="text-sm whitespace-pre-wrap leading-relaxed">
                  {msg.content.split("**").map((part, i) =>
                    i % 2 === 1 ? (
                      <strong key={i}>{part}</strong>
                    ) : (
                      <span key={i}>{part}</span>
                    )
                  )}
                </div>
              </div>
            </motion.div>
          ))}
        </AnimatePresence>

        {/* Typing Indicator */}
        {isTyping && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="flex gap-3"
          >
            <div className="w-8 h-8 rounded-full border-2 border-foreground bg-konnect-blue text-white flex items-center justify-center shrink-0">
              <Bot size={16} />
            </div>
            <div className="brutal-card bg-white p-4 rounded-lg">
              <div className="flex gap-1">
                <span className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: "0ms" }} />
                <span className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: "150ms" }} />
                <span className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: "300ms" }} />
              </div>
            </div>
          </motion.div>
        )}

        <div ref={messagesEndRef} />
      </div>

      {/* Suggested Questions */}
      {messages.length <= 1 && (
        <div className="py-3">
          <p className="text-xs font-bold text-muted-foreground mb-2 flex items-center gap-1">
            <ArrowDown size={12} /> 추천 질문
          </p>
          <div className="flex flex-wrap gap-2">
            {suggestedQuestions.map((q, i) => (
              <button
                key={i}
                onClick={() => sendMessage(q)}
                className="brutal-tag bg-secondary text-foreground hover:bg-konnect-yellow transition-colors text-xs"
              >
                {q}
              </button>
            ))}
          </div>
        </div>
      )}

      {/* Input Area */}
      <form onSubmit={handleSubmit} className="flex gap-2 pt-3">
        <input
          ref={inputRef}
          type="text"
          value={input}
          onChange={(e) => setInput(e.target.value)}
          placeholder="입시 관련 질문을 입력하세요..."
          className="flex-1 brutal-card bg-white px-4 py-3 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-primary"
          disabled={isTyping}
        />
        <button
          type="submit"
          disabled={!input.trim() || isTyping}
          className="brutal-btn bg-primary text-white px-4 py-3 rounded-lg disabled:opacity-50"
        >
          <Send size={20} />
        </button>
      </form>
    </div>
  );
}
