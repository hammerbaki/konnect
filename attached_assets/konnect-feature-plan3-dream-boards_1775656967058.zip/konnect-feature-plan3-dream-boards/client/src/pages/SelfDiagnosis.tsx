/*
 * 3안 최종 — 자기진단 & 평가 (무료)
 * 4종 진단: AI 적성 분석, 학업 역량 자가 진단, 입시 전략 진단, 학습 습관 진단
 * 월간 성장 리포트 (무료)
 * → 유료 AI 도구로의 전환 퍼널 입구 역할
 */
import { useState } from "react";
import { Link } from "wouter";
import { motion, AnimatePresence } from "framer-motion";
import {
  Brain, ClipboardCheck, Target, BookOpen, TrendingUp,
  ChevronRight, CheckCircle, ArrowRight, Crown, Sparkles,
  BarChart3, Compass, GraduationCap, Zap, Star,
} from "lucide-react";
import { toast } from "sonner";

/* ─── 진단 유형 ─── */
type DiagnosisType = "aptitude" | "academic" | "strategy" | "habit";

interface DiagnosisCard {
  key: DiagnosisType;
  icon: any;
  title: string;
  subtitle: string;
  description: string;
  questions: number;
  duration: string;
  color: string;
  bgColor: string;
  borderColor: string;
}

const diagnosisCards: DiagnosisCard[] = [
  {
    key: "aptitude",
    icon: Brain,
    title: "AI 적성 분석",
    subtitle: "나에게 맞는 계열 찾기",
    description: "성향, 흥미, 강점을 분석하여 최적의 계열과 학과를 추천합니다. 레이더 차트로 역량 분포를 시각화합니다.",
    questions: 20,
    duration: "약 5분",
    color: "text-violet-600",
    bgColor: "bg-violet-50",
    borderColor: "border-violet-200",
  },
  {
    key: "academic",
    icon: BarChart3,
    title: "학업 역량 자가 진단",
    subtitle: "과목별 Gap 분석",
    description: "현재 성적과 목표 대학 기준을 비교하여 과목별 Gap을 분석합니다. 우선 보완 과목과 학습 전략을 제시합니다.",
    questions: 15,
    duration: "약 4분",
    color: "text-blue-600",
    bgColor: "bg-blue-50",
    borderColor: "border-blue-200",
  },
  {
    key: "strategy",
    icon: Target,
    title: "입시 전략 진단",
    subtitle: "수시/정시 적합도 분석",
    description: "내신, 모의고사, 비교과 활동을 종합하여 수시와 정시 중 어떤 전형이 유리한지 분석합니다.",
    questions: 12,
    duration: "약 3분",
    color: "text-emerald-600",
    bgColor: "bg-emerald-50",
    borderColor: "border-emerald-200",
  },
  {
    key: "habit",
    icon: BookOpen,
    title: "학습 습관 진단",
    subtitle: "효율적인 공부법 찾기",
    description: "학습 패턴, 시간 관리, 집중력 등을 분석하여 나에게 맞는 효율적인 공부법을 추천합니다.",
    questions: 10,
    duration: "약 3분",
    color: "text-amber-600",
    bgColor: "bg-amber-50",
    borderColor: "border-amber-200",
  },
];

/* ─── 적성 분석 설문 ─── */
const aptitudeQuestions = [
  {
    id: 1,
    question: "새로운 과학적 발견이나 기술에 대해 읽을 때 어떤 느낌이 드나요?",
    options: [
      { text: "원리가 궁금해서 더 깊이 파고들고 싶다", scores: { science: 3, engineering: 2 } as Record<string, number> },
      { text: "이것이 사회에 미칠 영향이 궁금하다", scores: { humanities: 2, business: 2 } as Record<string, number> },
      { text: "이것을 활용한 창작물이 떠오른다", scores: { arts: 3, humanities: 1 } as Record<string, number> },
      { text: "이것으로 사업 기회를 만들 수 있을지 생각한다", scores: { business: 3, engineering: 1 } as Record<string, number> },
    ],
  },
  {
    id: 2,
    question: "팀 프로젝트에서 당신이 주로 맡는 역할은?",
    options: [
      { text: "자료 조사와 분석을 담당한다", scores: { science: 2, academic: 2 } as Record<string, number> },
      { text: "전체 방향을 설정하고 조율한다", scores: { business: 2, law: 2 } as Record<string, number> },
      { text: "발표 자료를 디자인하고 시각화한다", scores: { arts: 3 } as Record<string, number> },
      { text: "팀원들의 의견을 종합하고 갈등을 조정한다", scores: { education: 2, humanities: 2 } as Record<string, number> },
    ],
  },
  {
    id: 3,
    question: "가장 보람을 느끼는 순간은?",
    options: [
      { text: "어려운 문제를 논리적으로 풀어냈을 때", scores: { science: 2, engineering: 2, med: 1 } as Record<string, number> },
      { text: "다른 사람을 도와서 감사 인사를 받았을 때", scores: { med: 2, education: 2 } as Record<string, number> },
      { text: "나만의 작품이나 결과물을 완성했을 때", scores: { arts: 3, engineering: 1 } as Record<string, number> },
      { text: "사회적 불공정을 개선하는 데 기여했을 때", scores: { law: 3, humanities: 1 } as Record<string, number> },
    ],
  },
  {
    id: 4,
    question: "여가 시간에 주로 무엇을 하나요?",
    options: [
      { text: "다큐멘터리나 과학 영상을 본다", scores: { science: 2, med: 1 } as Record<string, number> },
      { text: "소설이나 에세이를 읽는다", scores: { humanities: 3 } as Record<string, number> },
      { text: "그림을 그리거나 음악을 듣는다", scores: { arts: 3 } as Record<string, number> },
      { text: "경제 뉴스나 시사 이슈를 확인한다", scores: { business: 2, law: 2 } as Record<string, number> },
    ],
  },
  {
    id: 5,
    question: "10년 후 나의 모습으로 가장 끌리는 것은?",
    options: [
      { text: "연구실에서 새로운 발견을 하는 연구자", scores: { science: 3, med: 1 } as Record<string, number> },
      { text: "환자를 치료하며 생명을 살리는 의료인", scores: { med: 3 } as Record<string, number> },
      { text: "기업을 이끌거나 창업한 경영인", scores: { business: 3 } as Record<string, number> },
      { text: "학생들을 가르치며 성장을 돕는 교육자", scores: { education: 3 } as Record<string, number> },
    ],
  },
];

/* ─── 학업 역량 진단 설문 ─── */
const academicQuestions = [
  {
    id: 1,
    question: "현재 국어 내신 등급은?",
    options: [
      { text: "1~2등급", value: 90 },
      { text: "3~4등급", value: 70 },
      { text: "5~6등급", value: 50 },
      { text: "7등급 이하", value: 30 },
    ],
  },
  {
    id: 2,
    question: "현재 수학 내신 등급은?",
    options: [
      { text: "1~2등급", value: 90 },
      { text: "3~4등급", value: 70 },
      { text: "5~6등급", value: 50 },
      { text: "7등급 이하", value: 30 },
    ],
  },
  {
    id: 3,
    question: "현재 영어 내신 등급은?",
    options: [
      { text: "1~2등급", value: 90 },
      { text: "3~4등급", value: 70 },
      { text: "5~6등급", value: 50 },
      { text: "7등급 이하", value: 30 },
    ],
  },
  {
    id: 4,
    question: "현재 탐구 과목 내신 등급은?",
    options: [
      { text: "1~2등급", value: 90 },
      { text: "3~4등급", value: 70 },
      { text: "5~6등급", value: 50 },
      { text: "7등급 이하", value: 30 },
    ],
  },
  {
    id: 5,
    question: "목표 대학 수준은?",
    options: [
      { text: "SKY (서울대/연세대/고려대)", value: 95 },
      { text: "상위권 (성균관대/한양대/중앙대 등)", value: 85 },
      { text: "중상위권 (건국대/동국대/홍익대 등)", value: 75 },
      { text: "아직 정하지 못했다", value: 0 },
    ],
  },
];

/* ─── 결과 차트 컴포넌트 ─── */
function RadarChart({ scores }: { scores: Record<string, number> }) {
  const labels: Record<string, string> = {
    science: "자연과학",
    engineering: "공학",
    med: "의·약학",
    business: "경영·경제",
    law: "법·행정",
    humanities: "인문·사회",
    arts: "예·체능",
    education: "교육",
  };

  const entries = Object.entries(scores)
    .map(([k, v]) => ({ key: k, label: labels[k] || k, score: v }))
    .sort((a, b) => b.score - a.score);

  const maxScore = Math.max(...entries.map((e) => e.score), 1);

  return (
    <div className="space-y-2">
      {entries.map((entry, i) => (
        <motion.div
          key={entry.key}
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: 0.1 * i }}
          className="flex items-center gap-3"
        >
          <span className="text-xs text-muted-foreground w-20 text-right shrink-0">{entry.label}</span>
          <div className="flex-1 h-6 bg-secondary rounded-sm overflow-hidden relative">
            <motion.div
              initial={{ width: 0 }}
              animate={{ width: `${(entry.score / maxScore) * 100}%` }}
              transition={{ duration: 0.8, delay: 0.1 * i }}
              className={`h-full rounded-sm ${i === 0 ? "bg-dream" : i === 1 ? "bg-dream/70" : "bg-dream/40"}`}
            />
            <span className="absolute right-2 top-1/2 -translate-y-1/2 text-[10px] font-mono font-bold">
              {Math.round((entry.score / maxScore) * 100)}%
            </span>
          </div>
        </motion.div>
      ))}
    </div>
  );
}

/* ─── 학업 Gap 차트 ─── */
function GapChart({ answers, target }: { answers: number[]; target: number }) {
  const subjects = ["국어", "수학", "영어", "탐구"];
  return (
    <div className="space-y-3">
      {subjects.map((subj, i) => {
        const current = answers[i] || 50;
        const gap = target > 0 ? Math.max(0, target - current) : 0;
        return (
          <motion.div
            key={subj}
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.1 * i }}
          >
            <div className="flex items-center justify-between mb-1">
              <span className="text-xs font-semibold">{subj}</span>
              <span className="text-[10px] text-muted-foreground">
                현재 {current}점 {target > 0 && `/ 목표 ${target}점`}
              </span>
            </div>
            <div className="h-5 bg-secondary rounded-sm overflow-hidden relative">
              <motion.div
                initial={{ width: 0 }}
                animate={{ width: `${current}%` }}
                transition={{ duration: 0.8, delay: 0.1 * i }}
                className="h-full bg-blue-500 rounded-sm"
              />
              {target > 0 && (
                <div
                  className="absolute top-0 h-full w-0.5 bg-red-500"
                  style={{ left: `${target}%` }}
                />
              )}
            </div>
            {gap > 0 && (
              <p className="text-[9px] text-red-500 mt-0.5">Gap: {gap}점 부족 — 보완 필요</p>
            )}
          </motion.div>
        );
      })}
    </div>
  );
}

/* ─── Main Component ─── */
export default function SelfDiagnosis() {
  const [activeDiagnosis, setActiveDiagnosis] = useState<DiagnosisType | null>(null);
  const [currentQ, setCurrentQ] = useState(0);
  const [aptitudeScores, setAptitudeScores] = useState<Record<string, number>>({});
  const [academicAnswers, setAcademicAnswers] = useState<number[]>([]);
  const [showResult, setShowResult] = useState(false);
  const [completedDiagnoses, setCompletedDiagnoses] = useState<DiagnosisType[]>([]);

  const handleStartDiagnosis = (type: DiagnosisType) => {
    if (type === "strategy" || type === "habit") {
      toast.info("이 진단은 곧 오픈됩니다. AI 적성 분석 또는 학업 역량 진단을 먼저 체험해 보세요!");
      return;
    }
    setActiveDiagnosis(type);
    setCurrentQ(0);
    setShowResult(false);
    setAptitudeScores({});
    setAcademicAnswers([]);
  };

  const handleAptitudeAnswer = (scores: Record<string, number>) => {
    const newScores = { ...aptitudeScores };
    Object.entries(scores).forEach(([k, v]) => {
      newScores[k] = (newScores[k] || 0) + v;
    });
    setAptitudeScores(newScores);

    if (currentQ < aptitudeQuestions.length - 1) {
      setCurrentQ(currentQ + 1);
    } else {
      setShowResult(true);
      if (!completedDiagnoses.includes("aptitude")) {
        setCompletedDiagnoses([...completedDiagnoses, "aptitude"]);
      }
    }
  };

  const handleAcademicAnswer = (value: number) => {
    const newAnswers = [...academicAnswers, value];
    setAcademicAnswers(newAnswers);

    if (currentQ < academicQuestions.length - 1) {
      setCurrentQ(currentQ + 1);
    } else {
      setShowResult(true);
      if (!completedDiagnoses.includes("academic")) {
        setCompletedDiagnoses([...completedDiagnoses, "academic"]);
      }
    }
  };

  const handleBack = () => {
    setActiveDiagnosis(null);
    setShowResult(false);
    setCurrentQ(0);
  };

  /* ─── 결과 화면: 적성 분석 ─── */
  const renderAptitudeResult = () => {
    const sorted = Object.entries(aptitudeScores).sort((a, b) => b[1] - a[1]);
    const top = sorted[0];
    const boardMap: Record<string, string> = {
      science: "natural-sci", engineering: "engineering", med: "med-pharm",
      business: "business-econ", law: "law-admin", humanities: "humanities",
      arts: "arts-sports", education: "education",
    };
    const labelMap: Record<string, string> = {
      science: "자연과학 계열", engineering: "공학 계열", med: "의·약학 계열",
      business: "경영·경제 계열", law: "법·행정 계열", humanities: "인문·사회 계열",
      arts: "예·체능 계열", education: "교육 계열",
    };

    return (
      <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="max-w-2xl mx-auto">
        <div className="text-center mb-6">
          <div className="inline-flex items-center gap-2 px-4 py-2 bg-dream/10 text-dream rounded-full mb-3">
            <Sparkles size={16} />
            <span className="text-sm font-semibold">적성 분석 완료!</span>
          </div>
          <h2 className="font-serif text-xl font-bold mb-1">
            당신에게 가장 어울리는 계열은
          </h2>
          <p className="text-2xl font-serif font-bold text-dream">
            {top ? labelMap[top[0]] || top[0] : "분석 중"}
          </p>
        </div>

        <div className="border border-border p-6 mb-6">
          <h3 className="font-serif font-bold text-sm mb-4">역량 분포 차트</h3>
          <RadarChart scores={aptitudeScores} />
        </div>

        {/* 추천 보드 */}
        {top && boardMap[top[0]] && (
          <div className="border-2 border-dream/20 bg-dream/5 p-5 mb-6 rounded-lg">
            <h3 className="font-serif font-bold text-sm mb-2">추천 꿈 보드</h3>
            <p className="text-xs text-muted-foreground mb-3">
              진단 결과를 바탕으로 아래 보드에 참여하면 맞춤형 콘텐츠와 AI 도구를 이용할 수 있습니다.
            </p>
            <Link href={`/boards/${boardMap[top[0]]}`}>
              <span className="inline-flex items-center gap-2 px-4 py-2.5 bg-dream text-white text-sm font-semibold rounded hover:bg-dream/90 transition-colors">
                {labelMap[top[0]]} 보드 참여하기 <ArrowRight size={14} />
              </span>
            </Link>
          </div>
        )}

        {/* 유료 전환 CTA */}
        <div className="border border-dream/20 bg-gradient-to-r from-dream/5 to-violet-50 p-5 rounded-lg">
          <div className="flex items-center gap-2 mb-2">
            <Crown size={16} className="text-dream" />
            <h3 className="font-serif font-bold text-sm">더 깊은 분석이 필요하다면?</h3>
          </div>
          <p className="text-xs text-muted-foreground mb-3">
            AI 서류 도구와 면접 시뮬레이터로 실전 준비를 시작하세요. 첫 1회는 무료입니다.
          </p>
          <div className="flex gap-2">
            <Link href="/tools/document">
              <span className="inline-flex items-center gap-1 px-3 py-2 text-xs bg-foreground text-background font-semibold hover:bg-foreground/90 transition-colors">
                AI 자소서 첨삭 체험 <ArrowRight size={12} />
              </span>
            </Link>
            <Link href="/tools/interview">
              <span className="inline-flex items-center gap-1 px-3 py-2 text-xs border border-foreground text-foreground font-semibold hover:bg-secondary transition-colors">
                AI 면접 연습 체험 <ArrowRight size={12} />
              </span>
            </Link>
          </div>
        </div>

        <div className="text-center mt-6">
          <button onClick={handleBack} className="text-sm text-muted-foreground hover:text-foreground">
            ← 다른 진단 받기
          </button>
        </div>
      </motion.div>
    );
  };

  /* ─── 결과 화면: 학업 역량 ─── */
  const renderAcademicResult = () => {
    const target = academicAnswers[4] || 0;
    return (
      <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="max-w-2xl mx-auto">
        <div className="text-center mb-6">
          <div className="inline-flex items-center gap-2 px-4 py-2 bg-blue-100 text-blue-700 rounded-full mb-3">
            <BarChart3 size={16} />
            <span className="text-sm font-semibold">학업 역량 진단 완료!</span>
          </div>
          <h2 className="font-serif text-xl font-bold">과목별 Gap 분석 결과</h2>
        </div>

        <div className="border border-border p-6 mb-6">
          <h3 className="font-serif font-bold text-sm mb-4">현재 수준 vs 목표</h3>
          <GapChart answers={academicAnswers} target={target} />
          <div className="mt-4 p-3 bg-blue-50 rounded-lg">
            <p className="text-xs text-blue-700 font-semibold mb-1">📊 종합 분석</p>
            <p className="text-[11px] text-muted-foreground">
              {target > 0
                ? `목표 대학 기준(${target}점)과 비교했을 때, 가장 보완이 필요한 과목부터 집중 학습을 권장합니다.`
                : "목표 대학을 설정하면 더 정확한 Gap 분석이 가능합니다. 꿈 보드에서 목표를 설정해 보세요."}
            </p>
          </div>
        </div>

        {/* 유료 전환 CTA */}
        <div className="border border-dream/20 bg-gradient-to-r from-dream/5 to-blue-50 p-5 rounded-lg">
          <div className="flex items-center gap-2 mb-2">
            <Crown size={16} className="text-dream" />
            <h3 className="font-serif font-bold text-sm">맞춤형 학습 전략이 필요하다면?</h3>
          </div>
          <p className="text-xs text-muted-foreground mb-3">
            AI 서류 도구로 생기부 세특을 분석하고, 자소서 첨삭을 받아보세요. 첫 1회는 무료입니다.
          </p>
          <div className="flex gap-2">
            <Link href="/tools/document">
              <span className="inline-flex items-center gap-1 px-3 py-2 text-xs bg-foreground text-background font-semibold hover:bg-foreground/90 transition-colors">
                AI 생기부 분석 체험 <ArrowRight size={12} />
              </span>
            </Link>
            <Link href="/boards">
              <span className="inline-flex items-center gap-1 px-3 py-2 text-xs border border-foreground text-foreground font-semibold hover:bg-secondary transition-colors">
                꿈 보드 탐색 <ArrowRight size={12} />
              </span>
            </Link>
          </div>
        </div>

        <div className="text-center mt-6">
          <button onClick={handleBack} className="text-sm text-muted-foreground hover:text-foreground">
            ← 다른 진단 받기
          </button>
        </div>
      </motion.div>
    );
  };

  /* ─── 설문 진행 화면 ─── */
  const renderQuiz = () => {
    if (activeDiagnosis === "aptitude") {
      const q = aptitudeQuestions[currentQ];
      return (
        <motion.div key={currentQ} initial={{ opacity: 0, x: 30 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -30 }} className="max-w-2xl mx-auto">
          <div className="mb-6">
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs text-muted-foreground">질문 {currentQ + 1} / {aptitudeQuestions.length}</span>
              <button onClick={handleBack} className="text-xs text-muted-foreground hover:text-foreground">취소</button>
            </div>
            <div className="h-1.5 bg-secondary rounded-full overflow-hidden">
              <motion.div
                className="h-full bg-dream rounded-full"
                initial={{ width: 0 }}
                animate={{ width: `${((currentQ + 1) / aptitudeQuestions.length) * 100}%` }}
              />
            </div>
          </div>
          <h2 className="font-serif text-lg font-bold mb-6">{q.question}</h2>
          <div className="space-y-3">
            {q.options.map((opt, i) => (
              <motion.button
                key={i}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.05 * i }}
                onClick={() => handleAptitudeAnswer(opt.scores)}
                className="w-full text-left p-4 border border-border hover:border-dream hover:bg-dream/5 transition-all text-sm rounded-lg"
              >
                <span className="text-muted-foreground mr-2 font-mono text-xs">{String.fromCharCode(65 + i)}.</span>
                {opt.text}
              </motion.button>
            ))}
          </div>
        </motion.div>
      );
    }

    if (activeDiagnosis === "academic") {
      const q = academicQuestions[currentQ];
      return (
        <motion.div key={currentQ} initial={{ opacity: 0, x: 30 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -30 }} className="max-w-2xl mx-auto">
          <div className="mb-6">
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs text-muted-foreground">질문 {currentQ + 1} / {academicQuestions.length}</span>
              <button onClick={handleBack} className="text-xs text-muted-foreground hover:text-foreground">취소</button>
            </div>
            <div className="h-1.5 bg-secondary rounded-full overflow-hidden">
              <motion.div
                className="h-full bg-blue-500 rounded-full"
                initial={{ width: 0 }}
                animate={{ width: `${((currentQ + 1) / academicQuestions.length) * 100}%` }}
              />
            </div>
          </div>
          <h2 className="font-serif text-lg font-bold mb-6">{q.question}</h2>
          <div className="space-y-3">
            {q.options.map((opt, i) => (
              <motion.button
                key={i}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.05 * i }}
                onClick={() => handleAcademicAnswer(opt.value)}
                className="w-full text-left p-4 border border-border hover:border-blue-500 hover:bg-blue-50 transition-all text-sm rounded-lg"
              >
                <span className="text-muted-foreground mr-2 font-mono text-xs">{String.fromCharCode(65 + i)}.</span>
                {opt.text}
              </motion.button>
            ))}
          </div>
        </motion.div>
      );
    }

    return null;
  };

  /* ─── 메인 화면 (진단 선택) ─── */
  return (
    <div className="max-w-5xl mx-auto px-4 lg:px-6 py-8">
      {!activeDiagnosis ? (
        <>
          {/* Header */}
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="text-center mb-8">
            <div className="inline-flex items-center gap-2 px-3 py-1.5 bg-emerald-100 text-emerald-700 text-xs font-semibold rounded-full mb-3">
              <ClipboardCheck size={12} />
              무료
            </div>
            <h1 className="font-serif text-2xl md:text-3xl font-bold mb-2">자기진단 & 평가</h1>
            <p className="text-sm text-muted-foreground max-w-lg mx-auto">
              나를 정확히 알아야 꿈에 가까워집니다. 4종 무료 진단으로 현재 위치를 파악하고, 맞춤형 성장 전략을 받아보세요.
            </p>
          </motion.div>

          {/* 진단 카드 그리드 */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-8">
            {diagnosisCards.map((card, i) => {
              const isCompleted = completedDiagnoses.includes(card.key);
              return (
                <motion.div
                  key={card.key}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.1 * i }}
                  className={`relative border ${card.borderColor} ${card.bgColor} p-5 rounded-lg hover:shadow-md transition-all cursor-pointer group`}
                  onClick={() => handleStartDiagnosis(card.key)}
                >
                  {isCompleted && (
                    <div className="absolute top-3 right-3">
                      <CheckCircle size={18} className="text-emerald-500" />
                    </div>
                  )}
                  <div className="flex items-start gap-3">
                    <div className={`w-10 h-10 ${card.bgColor} border ${card.borderColor} rounded-lg flex items-center justify-center shrink-0`}>
                      <card.icon size={20} className={card.color} />
                    </div>
                    <div className="flex-1">
                      <h3 className="font-serif font-bold text-sm mb-0.5">{card.title}</h3>
                      <p className="text-xs text-muted-foreground mb-2">{card.subtitle}</p>
                      <p className="text-[11px] text-muted-foreground leading-relaxed">{card.description}</p>
                      <div className="flex items-center gap-3 mt-3 text-[10px] text-muted-foreground">
                        <span>{card.questions}문항</span>
                        <span>·</span>
                        <span>{card.duration}</span>
                        <span className="ml-auto inline-flex items-center gap-1 text-emerald-600 font-semibold">
                          무료 <ChevronRight size={10} />
                        </span>
                      </div>
                    </div>
                  </div>
                </motion.div>
              );
            })}
          </div>

          {/* 월간 성장 리포트 */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.5 }}
            className="border border-border p-5 rounded-lg mb-8"
          >
            <div className="flex items-center gap-3 mb-3">
              <div className="w-10 h-10 bg-dream/10 rounded-lg flex items-center justify-center">
                <TrendingUp size={20} className="text-dream" />
              </div>
              <div>
                <h3 className="font-serif font-bold text-sm">월간 성장 리포트</h3>
                <p className="text-xs text-muted-foreground">매월 자동 생성되는 성장 분석 보고서</p>
              </div>
              <span className="ml-auto text-[10px] bg-emerald-100 text-emerald-700 px-2 py-1 rounded-full font-semibold">무료</span>
            </div>
            <p className="text-[11px] text-muted-foreground leading-relaxed">
              진단 결과의 변화 추이, 학습 목표 달성률, 보드 활동 통계를 종합하여 매월 성장 리포트를 자동 생성합니다.
              꿈 보드에 참여하면 동료 평균과 비교 분석도 제공됩니다.
            </p>
            <button
              onClick={() => toast.info("진단을 2회 이상 완료하면 리포트가 자동 생성됩니다")}
              className="mt-3 text-xs text-dream font-semibold hover:underline"
            >
              리포트 미리보기 →
            </button>
          </motion.div>

          {/* Premium 전환 배너 */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.6 }}
            className="bg-gradient-to-r from-dream/10 via-violet-50 to-amber-50 border border-dream/20 p-6 rounded-lg"
          >
            <div className="flex items-center gap-2 mb-2">
              <Crown size={18} className="text-dream" />
              <h3 className="font-serif font-bold text-base">진단 후, 실전 준비는 Premium으로</h3>
            </div>
            <p className="text-xs text-muted-foreground mb-4 max-w-xl">
              자기진단으로 현재 위치를 파악했다면, AI 서류 도구와 면접 시뮬레이터로 실전 준비를 시작하세요.
              각 도구의 첫 1회는 무료로 체험할 수 있습니다.
            </p>
            <div className="flex flex-wrap gap-3">
              <Link href="/tools/document">
                <span className="inline-flex items-center gap-1.5 px-4 py-2 text-xs bg-foreground text-background font-semibold hover:bg-foreground/90 transition-colors rounded">
                  <Crown size={11} /> AI 자소서 첨삭 (1회 무료)
                </span>
              </Link>
              <Link href="/tools/document">
                <span className="inline-flex items-center gap-1.5 px-4 py-2 text-xs border border-foreground text-foreground font-semibold hover:bg-secondary transition-colors rounded">
                  <Crown size={11} /> AI 생기부 분석 (1회 무료)
                </span>
              </Link>
              <Link href="/tools/interview">
                <span className="inline-flex items-center gap-1.5 px-4 py-2 text-xs border border-foreground text-foreground font-semibold hover:bg-secondary transition-colors rounded">
                  <Crown size={11} /> AI 면접 연습 (1회 무료)
                </span>
              </Link>
            </div>
            <div className="mt-3">
              <Link href="/pricing">
                <span className="text-xs text-dream font-semibold hover:underline">전체 요금제 보기 →</span>
              </Link>
            </div>
          </motion.div>
        </>
      ) : showResult ? (
        activeDiagnosis === "aptitude" ? renderAptitudeResult() : renderAcademicResult()
      ) : (
        <AnimatePresence mode="wait">
          {renderQuiz()}
        </AnimatePresence>
      )}
    </div>
  );
}
