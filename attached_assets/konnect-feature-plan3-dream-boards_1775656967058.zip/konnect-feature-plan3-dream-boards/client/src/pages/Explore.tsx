/*
 * Konnect v3 — 대학·학과 탐색 페이지
 * AI가 3가지 경로 제안: 도전 / 현실 / 발견
 */
import { useState } from "react";
import { Link } from "wouter";
import { motion } from "framer-motion";
import {
  Compass,
  Sparkles,
  GraduationCap,
  TrendingUp,
  Star,
  ChevronRight,
  Search,
  Flame,
  Target,
  Zap,
  Heart,
  MapPin,
  BookOpen,
} from "lucide-react";
import { toast } from "sonner";

const pathways = [
  {
    type: "도전",
    color: "text-dream",
    bg: "bg-dream/5",
    border: "border-dream/20",
    icon: Flame,
    university: "서울대학교 의과대학",
    cutoff: "상위 0.3%",
    description: "가장 높은 목표. 현재 성적에서 큰 도약이 필요하지만, 불가능하지 않습니다.",
    requirements: ["수능 전과목 1등급", "생명과학 심화 세특", "의료 봉사 경험"],
    matchRate: 23,
  },
  {
    type: "현실",
    color: "text-coral",
    bg: "bg-coral/5",
    border: "border-coral/20",
    icon: Target,
    university: "연세대학교 의예과",
    cutoff: "상위 0.8%",
    description: "현재 성적 추세를 유지하면 충분히 도달할 수 있는 현실적인 목표입니다.",
    requirements: ["수능 주요과목 1등급", "자연계열 세특", "의학 관련 독서"],
    matchRate: 58,
  },
  {
    type: "발견",
    color: "text-gold",
    bg: "bg-gold/5",
    border: "border-gold/20",
    icon: Sparkles,
    university: "KAIST 의과학대학원 (학석사 연계)",
    cutoff: "상위 2%",
    description: "당신이 몰랐던 경로. 연구 중심 의학을 원한다면 이 길도 있습니다.",
    requirements: ["수학·과학 1등급", "연구 경험", "영어 논문 독해력"],
    matchRate: 72,
  },
];

const universities = [
  { name: "서울대학교", location: "서울 관악구", departments: 83, dreamers: 1247, rank: 1 },
  { name: "연세대학교", location: "서울 서대문구", departments: 79, dreamers: 1089, rank: 2 },
  { name: "고려대학교", location: "서울 성북구", departments: 81, dreamers: 1034, rank: 3 },
  { name: "KAIST", location: "대전 유성구", departments: 36, dreamers: 678, rank: 4 },
  { name: "성균관대학교", location: "서울 종로구", departments: 72, dreamers: 567, rank: 5 },
  { name: "한양대학교", location: "서울 성동구", departments: 76, dreamers: 534, rank: 6 },
];

const departments = [
  { name: "의예과", field: "의학", popularity: 95, avgCutoff: "상위 0.5%" },
  { name: "컴퓨터공학과", field: "공학", popularity: 92, avgCutoff: "상위 3%" },
  { name: "경영학과", field: "상경", popularity: 88, avgCutoff: "상위 5%" },
  { name: "법학과", field: "법학", popularity: 85, avgCutoff: "상위 4%" },
  { name: "간호학과", field: "의학", popularity: 82, avgCutoff: "상위 8%" },
  { name: "생명과학부", field: "자연과학", popularity: 78, avgCutoff: "상위 6%" },
];

export default function Explore() {
  const [activeTab, setActiveTab] = useState<"pathway" | "university" | "department">("pathway");

  return (
    <div className="max-w-7xl mx-auto px-4 lg:px-6 py-6">
      {/* Hero */}
      <section className="mb-8">
        <div className="relative overflow-hidden rounded-xl">
          <img
            src="https://d2xsxph8kpxj0f.cloudfront.net/310519663433131621/A3XszkVKVy7WNitpyWDbEe/v3-path-design-9amRFwJ4976nQdpHrH9V2g.webp"
            alt="경로 탐색"
            className="w-full h-44 lg:h-56 object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-ink/80 via-ink/30 to-transparent" />
          <div className="absolute bottom-5 left-5 lg:bottom-8 lg:left-8">
            <span className="text-[10px] uppercase tracking-[0.2em] text-gold font-semibold">
              Path Explorer
            </span>
            <h1 className="editorial-heading text-2xl lg:text-4xl text-white mt-1">
              대학·학과 탐색
            </h1>
            <p className="text-white/60 text-sm mt-1">
              AI가 나의 꿈에 맞는 3가지 경로를 제안합니다
            </p>
          </div>
        </div>
      </section>

      {/* Tab Navigation */}
      <div className="flex gap-1 mb-6 border-b border-border">
        {[
          { key: "pathway" as const, label: "AI 경로 추천", icon: Compass },
          { key: "university" as const, label: "대학 탐색", icon: GraduationCap },
          { key: "department" as const, label: "학과 탐색", icon: BookOpen },
        ].map((tab) => (
          <button
            key={tab.key}
            onClick={() => setActiveTab(tab.key)}
            className={`flex items-center gap-1.5 px-4 py-2.5 text-sm font-medium border-b-2 transition-colors ${
              activeTab === tab.key
                ? "border-dream text-dream"
                : "border-transparent text-muted-foreground hover:text-foreground"
            }`}
          >
            <tab.icon size={14} />
            {tab.label}
          </button>
        ))}
      </div>

      {/* AI 경로 추천 */}
      {activeTab === "pathway" && (
        <div className="space-y-6">
          <div className="bg-dream/5 border border-dream/20 rounded-lg p-5">
            <div className="flex items-center gap-2 mb-2">
              <Sparkles size={16} className="text-dream" />
              <span className="text-sm font-semibold text-dream">AI 경로 분석 결과</span>
            </div>
            <p className="text-sm text-muted-foreground">
              나의 꿈 <span className="font-bold text-foreground">"서울대 의대에서 희귀질환을 연구하겠다"</span>를 기반으로
              3가지 경로를 분석했습니다.
            </p>
          </div>

          <div className="grid lg:grid-cols-3 gap-4">
            {pathways.map((path) => (
              <motion.div
                key={path.type}
                className={`ink-card p-5 ${path.bg} border ${path.border}`}
                whileHover={{ y: -4 }}
              >
                <div className="flex items-center gap-2 mb-3">
                  <path.icon size={18} className={path.color} />
                  <span className={`text-sm font-bold ${path.color}`}>{path.type} 경로</span>
                </div>
                <h3 className="editorial-heading text-lg mb-1">{path.university}</h3>
                <span className="text-[10px] text-muted-foreground">{path.cutoff}</span>
                <p className="text-sm text-muted-foreground mt-3 leading-relaxed">
                  {path.description}
                </p>
                <div className="mt-4">
                  <p className="text-[10px] font-semibold uppercase tracking-wider mb-2">필요 요건</p>
                  <ul className="space-y-1">
                    {path.requirements.map((r, i) => (
                      <li key={i} className="text-xs text-muted-foreground flex items-center gap-1.5">
                        <ChevronRight size={10} className={path.color} />
                        {r}
                      </li>
                    ))}
                  </ul>
                </div>
                <div className="mt-4 pt-3 border-t border-border">
                  <div className="flex items-center justify-between mb-1">
                    <span className="text-[10px] text-muted-foreground">매칭률</span>
                    <span className={`text-sm font-bold ${path.color}`}>{path.matchRate}%</span>
                  </div>
                  <div className="w-full h-2 bg-border rounded-full overflow-hidden">
                    <div
                      className={`h-full rounded-full ${
                        path.type === "도전" ? "bg-dream" :
                        path.type === "현실" ? "bg-coral" : "bg-gold"
                      }`}
                      style={{ width: `${path.matchRate}%` }}
                    />
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      )}

      {/* 대학 탐색 */}
      {activeTab === "university" && (
        <div>
          <div className="relative mb-6">
            <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
            <input
              type="text"
              placeholder="대학교 이름으로 검색..."
              className="w-full pl-10 pr-4 py-2.5 border border-border rounded-lg text-sm focus:border-dream outline-none"
              onFocus={() => toast.info("검색 기능은 준비 중입니다")}
            />
          </div>
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {universities.map((uni) => (
              <motion.div key={uni.name} className="ink-card p-5" whileHover={{ y: -2 }}>
                <div className="flex items-center gap-2 mb-2">
                  <GraduationCap size={18} className="text-dream" />
                  <h3 className="text-base font-semibold">{uni.name}</h3>
                </div>
                <div className="space-y-1.5 text-sm text-muted-foreground">
                  <p className="flex items-center gap-1.5">
                    <MapPin size={12} /> {uni.location}
                  </p>
                  <p>{uni.departments}개 학과</p>
                  <p className="text-coral font-semibold">
                    {uni.dreamers.toLocaleString()}명이 꿈꾸는 중
                  </p>
                </div>
                <button
                  className="mt-3 text-xs text-dream font-semibold flex items-center gap-1"
                  onClick={() => toast.info("대학 상세 페이지는 준비 중입니다")}
                >
                  자세히 보기 <ChevronRight size={12} />
                </button>
              </motion.div>
            ))}
          </div>
        </div>
      )}

      {/* 학과 탐색 */}
      {activeTab === "department" && (
        <div>
          <div className="relative mb-6">
            <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
            <input
              type="text"
              placeholder="학과 이름으로 검색..."
              className="w-full pl-10 pr-4 py-2.5 border border-border rounded-lg text-sm focus:border-dream outline-none"
              onFocus={() => toast.info("검색 기능은 준비 중입니다")}
            />
          </div>
          <div className="space-y-3">
            {departments.map((dept) => (
              <motion.div key={dept.name} className="ink-card p-4 flex items-center gap-4" whileHover={{ x: 4 }}>
                <div className="flex-1">
                  <div className="flex items-center gap-2 mb-1">
                    <h3 className="text-base font-semibold">{dept.name}</h3>
                    <span className="ink-tag text-[10px]">{dept.field}</span>
                  </div>
                  <p className="text-sm text-muted-foreground">
                    평균 커트라인: {dept.avgCutoff}
                  </p>
                </div>
                <div className="text-right">
                  <div className="flex items-center gap-1 mb-1">
                    <Flame size={12} className="text-coral" />
                    <span className="text-sm font-bold">{dept.popularity}%</span>
                  </div>
                  <span className="text-[10px] text-muted-foreground">인기도</span>
                </div>
                <ChevronRight size={16} className="text-muted-foreground" />
              </motion.div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
