/*
 * Design: Inkwell — Editorial Ink & Paper
 * - Credit system dashboard with gold accents
 * - Blockchain-ready credit management
 * - Earn/spend history
 */
import { useState } from "react";
import { motion } from "framer-motion";
import {
  Coins,
  ArrowUpRight,
  ArrowDownLeft,
  Gift,
  ShoppingBag,
  PenLine,
  Heart,
  MessageSquare,
  Trophy,
  Shield,
  Link as LinkIcon,
  TrendingUp,
} from "lucide-react";
import { toast } from "sonner";

const earnMethods = [
  { icon: PenLine, action: "게시글 작성", amount: "+10 KNC", desc: "커뮤니티에 게시글을 작성하면 크레딧을 획득합니다." },
  { icon: MessageSquare, action: "댓글 작성", amount: "+5 KNC", desc: "게시글에 댓글을 달면 크레딧을 획득합니다." },
  { icon: Heart, action: "좋아요 받기", amount: "+2 KNC", desc: "내 게시글이 좋아요를 받으면 크레딧을 획득합니다." },
  { icon: Trophy, action: "인기글 선정", amount: "+50 KNC", desc: "게시글이 인기글에 선정되면 보너스 크레딧을 받습니다." },
  { icon: Gift, action: "출석 체크", amount: "+3 KNC", desc: "매일 출석 체크를 하면 크레딧을 획득합니다." },
  { icon: ShoppingBag, action: "콘텐츠 판매", amount: "판매가의 80%", desc: "마켓에서 콘텐츠를 판매하면 판매가의 80%를 크레딧으로 받습니다." },
];

const history = [
  { type: "earn" as const, action: "게시글 작성", amount: 10, date: "2026.04.06", desc: "서울대 학종 세특 주제 추천 모음" },
  { type: "earn" as const, action: "인기글 선정", amount: 50, date: "2026.04.06", desc: "서울대 학종 세특 주제 추천 모음" },
  { type: "spend" as const, action: "교재 구매", amount: -280, date: "2026.04.05", desc: "국어 1등급을 정말 원한다면" },
  { type: "earn" as const, action: "댓글 작성", amount: 5, date: "2026.04.05", desc: "수학 킬러문항 풀이 패턴 정리" },
  { type: "earn" as const, action: "출석 체크", amount: 3, date: "2026.04.05", desc: "일일 출석 보상" },
  { type: "earn" as const, action: "좋아요 받기", amount: 12, date: "2026.04.04", desc: "좋아요 6개 수신" },
  { type: "spend" as const, action: "강의 구매", amount: -360, date: "2026.04.03", desc: "물리학1 개념 완성 강의" },
  { type: "earn" as const, action: "콘텐츠 판매", amount: 200, date: "2026.04.02", desc: "영어 독해 비법노트 판매 수익" },
];

export default function Credits() {
  const [activeTab, setActiveTab] = useState<"overview" | "history" | "earn">("overview");

  const totalEarned = history.filter((h) => h.type === "earn").reduce((sum, h) => sum + h.amount, 0);
  const totalSpent = Math.abs(history.filter((h) => h.type === "spend").reduce((sum, h) => sum + h.amount, 0));

  return (
    <div className="max-w-7xl mx-auto px-4 lg:px-6 py-6">
      {/* Header */}
      <div className="flex items-center gap-3 mb-2">
        <Coins size={20} className="text-gold" />
        <h1 className="editorial-heading text-2xl">크레딧</h1>
      </div>
      <p className="text-sm text-muted-foreground mb-4">
        Konnect 크레딧(KNC)으로 교재와 강의를 구매하고, 활동으로 크레딧을 획득하세요.
      </p>
      <hr className="editorial-divider-thick mt-0" />

      {/* Credit Balance Card */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="relative overflow-hidden border border-border p-6 mb-6"
      >
        <div className="absolute top-0 right-0 w-48 h-48 opacity-5">
          <img
            src="https://d2xsxph8kpxj0f.cloudfront.net/310519663433131621/A3XszkVKVy7WNitpyWDbEe/v2-credit-system-QaKSQoGWvi5Z7fW9mm2KHp.webp"
            alt=""
            className="w-full h-full object-cover"
          />
        </div>
        <div className="relative z-10">
          <div className="flex items-center gap-2 mb-1">
            <span className="text-xs text-muted-foreground">보유 크레딧</span>
            <span className="ink-tag-filled bg-gold/10 text-gold text-[10px] flex items-center gap-0.5">
              <Shield size={8} /> 블록체인 보호
            </span>
          </div>
          <div className="flex items-baseline gap-2 mb-4">
            <span className="editorial-heading text-4xl text-gold">1,250</span>
            <span className="text-sm text-muted-foreground">KNC</span>
          </div>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <div>
              <p className="text-[10px] text-muted-foreground uppercase tracking-wider">총 획득</p>
              <p className="text-sm font-semibold text-indigo flex items-center gap-1">
                <ArrowDownLeft size={12} /> {totalEarned.toLocaleString()} KNC
              </p>
            </div>
            <div>
              <p className="text-[10px] text-muted-foreground uppercase tracking-wider">총 사용</p>
              <p className="text-sm font-semibold text-vermillion flex items-center gap-1">
                <ArrowUpRight size={12} /> {totalSpent.toLocaleString()} KNC
              </p>
            </div>
            <div>
              <p className="text-[10px] text-muted-foreground uppercase tracking-wider">이번 달</p>
              <p className="text-sm font-semibold flex items-center gap-1">
                <TrendingUp size={12} className="text-gold" /> +280 KNC
              </p>
            </div>
            <div>
              <p className="text-[10px] text-muted-foreground uppercase tracking-wider">블록체인</p>
              <p className="text-sm font-semibold flex items-center gap-1">
                <LinkIcon size={12} /> 준비 중
              </p>
            </div>
          </div>
        </div>
      </motion.div>

      {/* Tabs */}
      <div className="flex gap-4 mb-6">
        {[
          { key: "overview" as const, label: "개요" },
          { key: "history" as const, label: "내역" },
          { key: "earn" as const, label: "획득 방법" },
        ].map((tab) => (
          <button
            key={tab.key}
            onClick={() => setActiveTab(tab.key)}
            className={`text-sm pb-1 transition-all ${
              activeTab === tab.key
                ? "text-foreground font-semibold border-b-2 border-foreground"
                : "text-muted-foreground hover:text-foreground"
            }`}
          >
            {tab.label}
          </button>
        ))}
      </div>

      {activeTab === "overview" && (
        <div className="grid md:grid-cols-2 gap-6">
          {/* Blockchain Info */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="border border-border p-5"
          >
            <div className="flex items-center gap-2 mb-3">
              <LinkIcon size={16} className="text-indigo" />
              <h3 className="editorial-heading text-lg">블록체인 크레딧</h3>
            </div>
            <p className="text-sm text-muted-foreground leading-relaxed mb-4">
              Konnect 크레딧(KNC)은 블록체인 기반으로 관리될 예정입니다.
              모든 거래 내역이 투명하게 기록되며, 위변조가 불가능합니다.
            </p>
            <div className="space-y-2">
              <div className="flex items-center gap-2 text-sm">
                <Shield size={14} className="text-gold" />
                <span>투명한 거래 기록</span>
              </div>
              <div className="flex items-center gap-2 text-sm">
                <Shield size={14} className="text-gold" />
                <span>위변조 불가능한 보안</span>
              </div>
              <div className="flex items-center gap-2 text-sm">
                <Shield size={14} className="text-gold" />
                <span>탈중앙화 자산 관리</span>
              </div>
            </div>
            <div className="mt-4 p-3 bg-gold/5 border border-gold/20">
              <p className="text-xs text-gold font-semibold">Coming Soon</p>
              <p className="text-[10px] text-muted-foreground mt-1">
                블록체인 네트워크 연동이 준비 중입니다. 현재 크레딧은 안전하게 보관됩니다.
              </p>
            </div>
          </motion.div>

          {/* Quick Stats */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.1 }}
            className="border border-border p-5"
          >
            <h3 className="editorial-heading text-lg mb-4">크레딧 활용</h3>
            <div className="space-y-3">
              <div className="flex items-center justify-between py-2 border-b border-border">
                <div className="flex items-center gap-2">
                  <ShoppingBag size={14} />
                  <span className="text-sm">교재 구매</span>
                </div>
                <span className="text-xs text-muted-foreground">추가 5% 할인</span>
              </div>
              <div className="flex items-center justify-between py-2 border-b border-border">
                <div className="flex items-center gap-2">
                  <ShoppingBag size={14} />
                  <span className="text-sm">강의 구매</span>
                </div>
                <span className="text-xs text-muted-foreground">추가 5% 할인</span>
              </div>
              <div className="flex items-center justify-between py-2 border-b border-border">
                <div className="flex items-center gap-2">
                  <Gift size={14} />
                  <span className="text-sm">크레딧 선물</span>
                </div>
                <span className="text-xs text-muted-foreground">다른 사용자에게 전송</span>
              </div>
              <div className="flex items-center justify-between py-2">
                <div className="flex items-center gap-2">
                  <Trophy size={14} />
                  <span className="text-sm">프리미엄 콘텐츠</span>
                </div>
                <span className="text-xs text-muted-foreground">독점 콘텐츠 열람</span>
              </div>
            </div>
          </motion.div>
        </div>
      )}

      {activeTab === "history" && (
        <div>
          <hr className="editorial-divider-thick mt-0 mb-0" />
          <div className="divide-y divide-border">
            {history.map((item, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ delay: 0.05 * i }}
                className="py-3 flex items-center gap-3"
              >
                <div
                  className={`w-8 h-8 flex items-center justify-center shrink-0 ${
                    item.type === "earn"
                      ? "bg-indigo/10 text-indigo"
                      : "bg-vermillion/10 text-vermillion"
                  }`}
                >
                  {item.type === "earn" ? (
                    <ArrowDownLeft size={14} />
                  ) : (
                    <ArrowUpRight size={14} />
                  )}
                </div>
                <div className="flex-1">
                  <p className="text-sm font-medium">{item.action}</p>
                  <p className="text-[10px] text-muted-foreground">{item.desc}</p>
                </div>
                <div className="text-right shrink-0">
                  <p
                    className={`text-sm font-bold ${
                      item.type === "earn" ? "text-indigo" : "text-vermillion"
                    }`}
                  >
                    {item.amount > 0 ? "+" : ""}
                    {item.amount} KNC
                  </p>
                  <p className="text-[10px] text-muted-foreground">{item.date}</p>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      )}

      {activeTab === "earn" && (
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {earnMethods.map((method, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.1 * i }}
              className="ink-card p-4"
            >
              <div className="flex items-start gap-3">
                <div className="p-2 bg-gold/10 text-gold">
                  <method.icon size={16} />
                </div>
                <div>
                  <div className="flex items-center gap-2 mb-1">
                    <h3 className="text-sm font-semibold">{method.action}</h3>
                    <span className="credit-badge text-xs">{method.amount}</span>
                  </div>
                  <p className="text-xs text-muted-foreground leading-relaxed">
                    {method.desc}
                  </p>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      )}
    </div>
  );
}
