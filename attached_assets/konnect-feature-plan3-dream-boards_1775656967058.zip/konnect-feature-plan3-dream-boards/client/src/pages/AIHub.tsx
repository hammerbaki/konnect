/*
 * Design: Inkwell — Editorial Ink & Paper
 * AI Hub — 3대 아젠다(인강·문제집·학원) 연동 AI 서비스
 */
import { useState, useRef, useEffect } from "react";
import { motion } from "framer-motion";
import {
  Sparkles,
  Send,
  TrendingUp,
  BookOpen,
  MessageSquare,
  Brain,
  Target,
  GraduationCap,
  ChevronRight,
  Bot,
  User,
  Monitor,
  MapPin,
} from "lucide-react";
import { toast } from "sonner";

type Message = {
  role: "user" | "ai";
  text: string;
};

const aiFeatures = [
  {
    id: 1,
    icon: Monitor,
    title: "내 성적에 맞는 인강 추천",
    desc: "현재 등급과 목표를 입력하면 AI가 최적의 인강 조합을 추천합니다.",
    tag: "인강",
    color: "text-indigo",
    bg: "bg-indigo/10",
  },
  {
    id: 2,
    icon: BookOpen,
    title: "과목별 문제집 로드맵",
    desc: "현재 실력과 수능까지 남은 기간에 맞는 문제집 순서를 AI가 설계합니다.",
    tag: "문제집",
    color: "text-vermillion",
    bg: "bg-vermillion/10",
  },
  {
    id: 3,
    icon: MapPin,
    title: "우리 동네 학원 비교 분석",
    desc: "지역과 과목을 입력하면 AI가 주변 학원을 비교 분석합니다.",
    tag: "학원",
    color: "text-gold",
    bg: "bg-gold/10",
  },
  {
    id: 4,
    icon: Target,
    title: "맞춤 대학 추천",
    desc: "내신, 모의고사 성적을 입력하면 AI가 합격 가능 대학을 추천합니다.",
    tag: "추천",
    color: "text-indigo",
    bg: "bg-indigo/10",
  },
  {
    id: 5,
    icon: Brain,
    title: "학습 플래너",
    desc: "남은 기간과 목표에 맞는 인강+문제집+자습 통합 학습 계획을 생성합니다.",
    tag: "계획",
    color: "text-indigo",
    bg: "bg-indigo/10",
  },
  {
    id: 6,
    icon: MessageSquare,
    title: "AI 면접 코치",
    desc: "실전 면접 질문을 생성하고 답변을 피드백합니다.",
    tag: "연습",
    color: "text-indigo",
    bg: "bg-indigo/10",
  },
];

const quickQuestions = [
  "수학 3등급인데 어떤 인강 들어야 해?",
  "국어 문제집 순서 추천해줘",
  "강남 수학학원 비교해줘",
  "내신 2등급이면 어디 갈 수 있어?",
  "수능 D-200 학습 계획 짜줘",
];

const aiResponses: Record<string, string> = {
  "수학 3등급인데 어떤 인강 들어야 해?":
    "수학 3등급이시라면 다음 인강 조합을 추천합니다:\n\n[1단계: 개념 재정립]\n• 양승진 '시발점' 수학1+수학2 — 기초 개념을 탄탄하게 잡아줍니다\n• 난이도: 중하 | 수강생 41,300명 | 평점 4.8\n\n[2단계: 유형 훈련]\n• 현우진 '뉴런' — 개념 이해 후 문제 풀이 패턴을 익히기 좋습니다\n• 난이도: 중상 | 수강생 45,200명 | 평점 4.9\n\n[병행 문제집]\n• 쎈 수학1 → 블랙라벨 순으로 난이도를 올려가세요\n\n예상 소요 기간: 약 3~4개월",
  "국어 문제집 순서 추천해줘":
    "국어 문제집 로드맵을 추천합니다:\n\n[STEP 1: 기초 다지기 (1~2개월)]\n• 매3비 (매일 지문 3개씩 비문학) — 비문학 독해력 기초\n• 매3문 (매일 지문 3개씩 문학) — 문학 감상 기초\n\n[STEP 2: EBS 연계 (2~3개월)]\n• EBS 수능특강 국어 — 수능 연계 필수\n• 가격: 9,900원 | 평점 4.5\n\n[STEP 3: 기출 분석 (2개월)]\n• 마더텅 수능기출 국어 — 연도별 기출 회독\n\n[STEP 4: 실전 (1개월)]\n• 봉투 모의고사 — 실전 감각 키우기\n\n총 예상 비용: 약 55,000원",
  "강남 수학학원 비교해줘":
    "강남구 수학 관련 학원을 비교 분석합니다:\n\n[1] 시대인재 대치캠퍼스\n• 종합학원 | 평점 4.8 | 리뷰 342개\n• 월 50~80만원 | 자습실 완비, 1:1 상담\n• 특징: 체계적 커리큘럼, 자습 관리 강점\n\n[2] 청솔학원 대치점\n• 종합학원 | 평점 4.7 | 리뷰 289개\n• 월 60~90만원 | 기숙형 관리\n• 특징: 재수생 전문, 높은 합격률\n\n[3] 대치국어 논술학원\n• 논술 전문 | 평점 4.8 | 리뷰 145개\n• 월 30~50만원 | 소수정예\n• 특징: 대학별 맞춤 논술 지도\n\n추천: 자기관리가 되면 시대인재, 관리형이 필요하면 청솔",
  "내신 2등급이면 어디 갈 수 있어?":
    "내신 2등급대라면 교과전형 기준으로 다음 대학들을 고려해볼 수 있습니다:\n\n• 건국대, 동국대, 홍익대 등 상위권 대학의 일부 학과\n• 숙명여대, 성신여대 등 여대 교과전형\n• 경희대, 한국외대 일부 학과\n\n다만 계열과 학과에 따라 차이가 크므로, 정확한 성적과 희망 학과를 알려주시면 더 구체적인 분석이 가능합니다.",
  "수능 D-200 학습 계획 짜줘":
    "D-200 통합 학습 플랜을 제안합니다:\n\n[Phase 1: D-200~D-150] 개념 완성\n• 인강: 양승진 시발점(수학) + 박광일 올인원(국어)\n• 문제집: 수학의 정석 + 매3비\n• 학원: 주 2회 약점 과목 보충\n\n[Phase 2: D-150~D-100] 기출 분석\n• 인강: 기출 분석 강의 수강\n• 문제집: 마더텅 기출 + EBS 수능특강\n• 학원: 모의고사 + 오답 관리\n\n[Phase 3: D-100~D-50] 실전 연습\n• 주 2회 실전 모의고사\n• 봉투 모의고사 풀이\n• 취약 단원 집중 보강",
};

export default function AIHub() {
  const [activeTab, setActiveTab] = useState<"features" | "chat">("features");
  const [messages, setMessages] = useState<Message[]>([
    {
      role: "ai",
      text: "안녕하세요! Konnect AI 멘토입니다.\n\n어떤 인강을 들을지, 어떤 문제집을 풀지, 어떤 학원을 다닐지 — 구체적인 고민을 물어보세요. 아래 추천 질문을 눌러보셔도 좋습니다.",
    },
  ]);
  const [input, setInput] = useState("");
  const [isTyping, setIsTyping] = useState(false);
  const chatEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    chatEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  const handleSend = (text?: string) => {
    const msg = text || input.trim();
    if (!msg) return;
    setInput("");
    setMessages((prev) => [...prev, { role: "user", text: msg }]);
    setIsTyping(true);

    setTimeout(() => {
      const response =
        aiResponses[msg] ||
        "좋은 질문이네요! 해당 주제에 대해 분석 중입니다.\n\n(프로토타입에서는 미리 준비된 질문에 대해서만 상세 답변이 제공됩니다. 추천 질문을 눌러보세요!)";
      setMessages((prev) => [...prev, { role: "ai", text: response }]);
      setIsTyping(false);
    }, 1200);
  };

  return (
    <div className="max-w-7xl mx-auto px-4 lg:px-6 py-6">
      {/* Header */}
      <div className="flex items-center gap-3 mb-2">
        <Sparkles size={20} className="text-indigo" />
        <h1 className="editorial-heading text-2xl">AI 콘텐츠</h1>
      </div>
      <p className="text-sm text-muted-foreground mb-4">
        AI가 분석한 인강·문제집·학원 추천과 맞춤 입시 상담을 이용하세요.
      </p>
      <hr className="editorial-divider-thick mt-0" />

      {/* Tabs */}
      <div className="flex gap-4 mb-6">
        <button
          onClick={() => setActiveTab("features")}
          className={`text-sm pb-1 transition-all ${
            activeTab === "features"
              ? "text-foreground font-semibold border-b-2 border-foreground"
              : "text-muted-foreground hover:text-foreground"
          }`}
        >
          AI 서비스
        </button>
        <button
          onClick={() => setActiveTab("chat")}
          className={`text-sm pb-1 transition-all ${
            activeTab === "chat"
              ? "text-foreground font-semibold border-b-2 border-foreground"
              : "text-muted-foreground hover:text-foreground"
          }`}
        >
          AI 상담
        </button>
      </div>

      {activeTab === "features" ? (
        <div>
          {/* Hero Image */}
          <div className="relative overflow-hidden mb-8">
            <img
              src="https://d2xsxph8kpxj0f.cloudfront.net/310519663433131621/A3XszkVKVy7WNitpyWDbEe/v2-ai-content-2YPsVm7QfGZe56rXFynVJF.webp"
              alt="AI Content"
              className="w-full h-40 md:h-56 object-cover"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-background/80 to-transparent" />
            <div className="absolute bottom-4 left-4">
              <span className="ink-tag-filled bg-indigo text-white text-[10px]">
                AI POWERED
              </span>
              <p className="text-sm font-serif font-bold mt-1">
                인강·문제집·학원, AI가 최적의 조합을 찾아드립니다
              </p>
            </div>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
            {aiFeatures.map((feature, i) => (
              <motion.div
                key={feature.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.1 * i }}
                className="ink-card p-5 group cursor-pointer"
                onClick={() => {
                  setActiveTab("chat");
                  toast.info(`${feature.title} — AI 상담에서 물어보세요`);
                }}
              >
                <div className="flex items-start gap-3">
                  <div className={`p-2 ${feature.bg} ${feature.color}`}>
                    <feature.icon size={18} />
                  </div>
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-1">
                      <span className={`ink-tag-filled ${feature.bg} ${feature.color} text-[10px]`}>
                        {feature.tag}
                      </span>
                    </div>
                    <h3 className="font-serif font-bold text-sm mb-1">
                      {feature.title}
                    </h3>
                    <p className="text-xs text-muted-foreground leading-relaxed">
                      {feature.desc}
                    </p>
                  </div>
                  <ChevronRight
                    size={16}
                    className="text-muted-foreground group-hover:text-indigo transition-colors shrink-0 mt-1"
                  />
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      ) : (
        /* Chat Interface */
        <div className="max-w-2xl mx-auto">
          <div className="border border-border bg-card">
            <div className="px-4 py-3 border-b border-border flex items-center gap-2">
              <Bot size={16} className="text-indigo" />
              <span className="text-sm font-semibold">AI 멘토</span>
              <span className="text-[10px] text-muted-foreground">
                인강·문제집·학원 추천 전문
              </span>
            </div>

            <div className="h-[400px] overflow-y-auto p-4 space-y-4">
              {messages.map((msg, i) => (
                <motion.div
                  key={i}
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  className={`flex gap-2 ${
                    msg.role === "user" ? "justify-end" : "justify-start"
                  }`}
                >
                  {msg.role === "ai" && (
                    <div className="w-7 h-7 bg-indigo text-white flex items-center justify-center shrink-0">
                      <Bot size={14} />
                    </div>
                  )}
                  <div
                    className={`max-w-[80%] px-3 py-2 text-sm leading-relaxed whitespace-pre-line ${
                      msg.role === "user"
                        ? "bg-foreground text-background"
                        : "bg-secondary text-foreground"
                    }`}
                  >
                    {msg.text}
                  </div>
                  {msg.role === "user" && (
                    <div className="w-7 h-7 bg-foreground text-background flex items-center justify-center shrink-0">
                      <User size={14} />
                    </div>
                  )}
                </motion.div>
              ))}
              {isTyping && (
                <div className="flex gap-2">
                  <div className="w-7 h-7 bg-indigo text-white flex items-center justify-center shrink-0">
                    <Bot size={14} />
                  </div>
                  <div className="bg-secondary px-3 py-2 text-sm">
                    <span className="animate-pulse">답변 작성 중...</span>
                  </div>
                </div>
              )}
              <div ref={chatEndRef} />
            </div>

            <div className="px-4 py-2 border-t border-border">
              <div className="flex gap-2 overflow-x-auto pb-2">
                {quickQuestions.map((q) => (
                  <button
                    key={q}
                    onClick={() => handleSend(q)}
                    className="shrink-0 px-3 py-1 text-xs border border-border hover:border-indigo hover:text-indigo transition-colors"
                  >
                    {q}
                  </button>
                ))}
              </div>
            </div>

            <div className="px-4 py-3 border-t border-border flex gap-2">
              <input
                type="text"
                value={input}
                onChange={(e) => setInput(e.target.value)}
                onKeyDown={(e) => e.key === "Enter" && handleSend()}
                placeholder="어떤 인강/문제집/학원이 좋을지 물어보세요..."
                className="flex-1 px-3 py-2 text-sm border border-border bg-transparent focus:border-indigo outline-none transition-colors"
              />
              <button
                onClick={() => handleSend()}
                className="px-3 py-2 bg-indigo text-white hover:bg-indigo/90 transition-colors"
              >
                <Send size={16} />
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
