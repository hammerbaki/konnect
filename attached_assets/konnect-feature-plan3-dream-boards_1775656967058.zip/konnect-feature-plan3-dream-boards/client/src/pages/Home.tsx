/*
 * Konnect v3 — "꿈을 잇다" Home
 * 추상 70% (꿈 선언, 스토리, 응원, 성장) + 구체 30% (인강·문제집·학원)
 * "다시, 잇다" — 재도전자를 위한 감성 양념
 * PC: main feed + right sidebar / Mobile: single column
 */
import { Link } from "wouter";
import { motion } from "framer-motion";
import {
  ArrowRight,
  Star,
  Heart,
  MessageCircleHeart,
  Sparkles,
  TrendingUp,
  Compass,
  GraduationCap,
  Monitor,
  BookOpen,
  MapPin,
  Coins,
  Users,
  Flame,
  PenLine,
  ChevronRight,
  Award,
  Target,
  Zap,
  RotateCcw,
  Sunrise,
} from "lucide-react";

/* ── Mock Data ── */

const dreamComrades = [
  { name: "의대지망생A", dream: "서울대 의대", daysActive: 142 },
  { name: "공대러B", dream: "KAIST 전산학부", daysActive: 98 },
  { name: "법대꿈C", dream: "고려대 법학", daysActive: 67 },
];

const storyFeed = [
  {
    id: 1,
    author: "꿈을향해",
    avatar: "K",
    dream: "서울대 의대",
    title: "모의고사 3등급에서 시작한 나의 이야기",
    excerpt: "6월 모의고사 수학 3등급을 받고 눈앞이 캄캄했다. 하지만 포기하지 않기로 했다. 매일 새벽 5시에 일어나 기출 3회독을 시작했고...",
    cheers: 312,
    comments: 67,
    time: "2시간 전",
    tag: "성장기",
    milestone: "수학 2등급 달성",
    isReStarter: false,
  },
  {
    id: 2,
    author: "다시봄",
    avatar: "D",
    dream: "연세대 의예과",
    title: "두 번째 도전, 이번엔 다르다는 걸 안다",
    excerpt: "작년 수능 후 한 달을 울었다. 하지만 눈물이 마른 자리에 새로운 결심이 피어났다. 이번엔 왜 공부하는지를 먼저 물었다. 그리고 답을 찾았다.",
    cheers: 567,
    comments: 134,
    time: "3시간 전",
    tag: "다시, 잇다",
    milestone: "꿈 재선언",
    isReStarter: true,
  },
  {
    id: 3,
    author: "끝까지간다",
    avatar: "E",
    dream: "서강대 경영학과",
    title: "D-220, 슬럼프가 왔을 때 나를 구한 한 마디",
    excerpt: "\"지금 힘든 건 네가 성장하고 있다는 증거야.\" 담임 선생님의 이 한 마디가 다시 책상에 앉게 만들었다...",
    cheers: 234,
    comments: 45,
    time: "8시간 전",
    tag: "응원",
    milestone: "연속 30일 학습",
    isReStarter: false,
  },
  {
    id: 4,
    author: "두번째봄꽃",
    avatar: "B",
    dream: "서울대 경제학부",
    title: "작년의 나에게 보내는 편지",
    excerpt: "1년 전의 나에게. 너는 실패한 게 아니야. 다만 아직 준비가 덜 됐을 뿐이었어. 지금의 나는 그때보다 훨씬 단단해졌어. 고마워, 포기하지 않아줘서.",
    cheers: 892,
    comments: 203,
    time: "5시간 전",
    tag: "다시, 잇다",
    milestone: null,
    isReStarter: true,
  },
];

const topDreams = [
  { dream: "서울대학교", dreamers: 1247, icon: "🏛️" },
  { dream: "연세대학교", dreamers: 1089, icon: "🦅" },
  { dream: "고려대학교", dreamers: 1034, icon: "🐯" },
  { dream: "KAIST", dreamers: 678, icon: "🔬" },
  { dream: "서울대 의대", dreamers: 523, icon: "🩺" },
];

const growthMilestones = [
  { label: "꿈 선언", done: true },
  { label: "첫 이야기", done: true },
  { label: "10일 연속", done: true },
  { label: "첫 응원 100", done: false },
  { label: "꿈 동료 50명", done: false },
];

const quickTools = [
  { icon: Monitor, title: "인강 비교", sub: "1,247 리뷰", href: "/lectures", color: "text-indigo" },
  { icon: BookOpen, title: "문제집 리뷰", sub: "892 리뷰", href: "/workbooks", color: "text-vermillion" },
  { icon: MapPin, title: "학원 찾기", sub: "2,156 정보", href: "/academies", color: "text-gold" },
];

/* "다시, 잇다" 전용 데이터 */
const reStarterQuotes = [
  { text: "멈춘 게 아니라 숨을 고른 것이다.", author: "다시봄" },
  { text: "같은 꿈이라도 두 번째는 더 깊다.", author: "두번째봄꽃" },
  { text: "작년의 눈물이 올해의 잉크가 되었다.", author: "다시, 잇다 멤버" },
];

const reStarterStats = {
  total: 4237,
  thisMonth: 312,
  avgImprovement: "1.8등급",
};

export default function Home() {
  return (
    <div className="max-w-7xl mx-auto px-4 lg:px-6 py-6">
      {/* ═══ HERO — 꿈의 선언 ═══ */}
      <section className="mb-8">
        <div className="relative overflow-hidden rounded-xl">
          <img
            src="https://d2xsxph8kpxj0f.cloudfront.net/310519663433131621/A3XszkVKVy7WNitpyWDbEe/v3-hero-dream-kSVtSQjiGKaTguFYwP6Y5v.webp"
            alt="꿈을 잇다"
            className="w-full h-56 lg:h-80 object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-ink/80 via-ink/30 to-transparent" />
          <div className="absolute bottom-5 left-5 lg:bottom-10 lg:left-10 right-5 lg:right-10">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6 }}
            >
              <span className="text-[10px] uppercase tracking-[0.2em] text-gold font-semibold">
                Konnect v3
              </span>
              <h1 className="editorial-heading text-3xl lg:text-5xl text-white mt-1 leading-tight">
                꿈을 잇다.
              </h1>
              <p className="text-white/70 text-sm lg:text-base mt-2 max-w-lg">
                어떤 인강을 들을지 묻기 전에, 왜 공부하는지를 먼저 묻는다.
              </p>
              <div className="flex items-center gap-3 mt-4">
                <Link href="/dream">
                  <span className="inline-flex items-center gap-2 px-5 py-2.5 bg-dream text-white text-sm font-semibold rounded-lg hover:bg-dream/90 transition-colors">
                    <Star size={16} />
                    나의 꿈 선언하기
                  </span>
                </Link>
                <Link href="/stories">
                  <span className="inline-flex items-center gap-2 px-5 py-2.5 bg-white/10 text-white text-sm font-medium rounded-lg backdrop-blur-sm hover:bg-white/20 transition-colors">
                    이야기 둘러보기
                  </span>
                </Link>
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* ═══ DESKTOP 2-column / MOBILE single ═══ */}
      <div className="lg:grid lg:grid-cols-[1fr_320px] lg:gap-8">
        {/* ── Main Feed ── */}
        <div>
          {/* 나의 꿈 카드 (개인화) */}
          <section className="mb-8">
            <div className="dream-card p-5 lg:p-6">
              <div className="flex items-start justify-between">
                <div>
                  <span className="text-[10px] uppercase tracking-[0.15em] text-dream font-semibold">
                    나의 꿈 선언
                  </span>
                  <h2 className="editorial-heading text-xl lg:text-2xl mt-1">
                    "서울대 의대에서 희귀질환을 연구하겠다"
                  </h2>
                  <p className="text-sm text-muted-foreground mt-2">
                    선언한 지 <span className="font-bold text-dream">142일</span> · 꿈 동료{" "}
                    <span className="font-bold text-coral">312명</span>
                  </p>
                </div>
                <Link href="/dream">
                  <span className="text-xs text-dream hover:underline">수정 →</span>
                </Link>
              </div>
              <div className="flex items-center gap-2 mt-4">
                {growthMilestones.map((m, i) => (
                  <div key={i} className="flex items-center gap-1">
                    <div
                      className={`w-3 h-3 rounded-full border-2 ${
                        m.done
                          ? "bg-dream border-dream"
                          : "border-muted-foreground/30"
                      }`}
                    />
                    <span className={`text-[10px] ${m.done ? "text-foreground font-medium" : "text-muted-foreground"}`}>
                      {m.label}
                    </span>
                    {i < growthMilestones.length - 1 && (
                      <div className={`w-4 h-px ${m.done ? "bg-dream" : "bg-border"}`} />
                    )}
                  </div>
                ))}
              </div>
            </div>
          </section>

          {/* 오늘의 메시지 */}
          <section className="mb-8">
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.3 }}
              className="bg-gradient-to-r from-dream/5 via-coral/5 to-gold/5 border border-dream/10 rounded-lg p-5 text-center"
            >
              <p className="text-sm text-muted-foreground mb-1">오늘의 한 마디</p>
              <p className="editorial-heading text-lg lg:text-xl">
                "지금 흘리는 땀은, 미래의 너를 만드는 잉크다."
              </p>
              <p className="text-xs text-muted-foreground mt-2">
                — 같은 꿈을 꾸는 312명이 오늘도 함께하고 있어요
              </p>
            </motion.div>
          </section>

          {/* ═══ "다시, 잇다" — 재도전자 전용 섹션 ═══ */}
          <section className="mb-8">
            <motion.div
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.4 }}
              className="relative overflow-hidden rounded-xl border-2 border-coral/20 bg-gradient-to-br from-coral/5 via-background to-gold/5"
            >
              {/* 상단 라벨 */}
              <div className="px-5 lg:px-6 pt-5 lg:pt-6">
                <div className="flex items-center gap-2 mb-3">
                  <div className="w-8 h-8 bg-coral/10 rounded-full flex items-center justify-center">
                    <Sunrise size={16} className="text-coral" />
                  </div>
                  <div>
                    <h2 className="editorial-heading text-lg flex items-center gap-2">
                      다시, 잇다.
                      <span className="text-[9px] font-sans font-semibold tracking-wider text-coral bg-coral/10 px-2 py-0.5 rounded-full uppercase">
                        Re:Connect
                      </span>
                    </h2>
                    <p className="text-xs text-muted-foreground">
                      끊어진 줄 알았던 꿈을, 다시 이어가는 사람들
                    </p>
                  </div>
                </div>
              </div>

              {/* 인용구 캐러셀 */}
              <div className="px-5 lg:px-6 pb-4">
                <div className="bg-white/60 dark:bg-ink/30 backdrop-blur-sm rounded-lg p-4 border border-coral/10">
                  <p className="editorial-heading text-base lg:text-lg text-center leading-relaxed">
                    "{reStarterQuotes[0].text}"
                  </p>
                  <p className="text-xs text-coral text-center mt-2 font-medium">
                    — {reStarterQuotes[0].author}
                  </p>
                </div>
              </div>

              {/* 통계 */}
              <div className="grid grid-cols-3 border-t border-coral/10">
                <div className="p-4 text-center border-r border-coral/10">
                  <p className="editorial-heading text-xl text-coral">{reStarterStats.total.toLocaleString()}</p>
                  <p className="text-[10px] text-muted-foreground mt-0.5">다시 꿈꾸는 사람</p>
                </div>
                <div className="p-4 text-center border-r border-coral/10">
                  <p className="editorial-heading text-xl text-dream">+{reStarterStats.thisMonth}</p>
                  <p className="text-[10px] text-muted-foreground mt-0.5">이번 달 합류</p>
                </div>
                <div className="p-4 text-center">
                  <p className="editorial-heading text-xl text-gold">{reStarterStats.avgImprovement}</p>
                  <p className="text-[10px] text-muted-foreground mt-0.5">평균 성적 향상</p>
                </div>
              </div>

              {/* CTA */}
              <div className="px-5 lg:px-6 pb-5 lg:pb-6 pt-3">
                <Link href="/stories">
                  <span className="flex items-center justify-center gap-2 w-full py-2.5 bg-coral text-white text-sm font-semibold rounded-lg hover:bg-coral/90 transition-colors">
                    <RotateCcw size={14} />
                    다시, 잇다 이야기 보기
                  </span>
                </Link>
                <p className="text-[10px] text-muted-foreground text-center mt-2 italic">
                  "멈춘 것이 아니다. 더 멀리 뛰기 위해 숨을 고른 것이다."
                </p>
              </div>
            </motion.div>
          </section>

          {/* ═══ 스토리 스트림 ═══ */}
          <section className="mb-8">
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-2">
                <MessageCircleHeart size={18} className="text-coral" />
                <h2 className="editorial-heading text-lg">스토리 스트림</h2>
              </div>
              <Link href="/stories">
                <span className="text-xs text-muted-foreground hover:text-foreground ink-link">
                  전체보기 →
                </span>
              </Link>
            </div>
            <hr className="editorial-divider-thick mt-0 mb-0" />

            <div className="space-y-0 divide-y divide-border">
              {storyFeed.map((story) => (
                <Link key={story.id} href={`/stories`}>
                  <motion.div
                    className="py-5 group"
                    whileHover={{ x: 4 }}
                    transition={{ duration: 0.15 }}
                  >
                    <div className="flex items-center gap-2 mb-2">
                      <div className={`w-7 h-7 ${story.isReStarter ? 'bg-coral/10 text-coral' : 'bg-dream/10 text-dream'} rounded-full flex items-center justify-center text-xs font-bold`}>
                        {story.avatar}
                      </div>
                      <span className="text-sm font-semibold">{story.author}</span>
                      <span className={`text-[10px] ${story.isReStarter ? 'text-coral bg-coral/10' : 'text-dream bg-dream/10'} px-1.5 py-0.5 rounded`}>
                        {story.dream}
                      </span>
                      {story.isReStarter && (
                        <span className="text-[9px] font-semibold text-coral bg-coral/10 px-1.5 py-0.5 rounded-full flex items-center gap-0.5">
                          <Sunrise size={8} />
                          다시, 잇다
                        </span>
                      )}
                      <span className="text-[10px] text-muted-foreground ml-auto">
                        {story.time}
                      </span>
                    </div>

                    {story.milestone && (
                      <div className="flex items-center gap-1.5 mb-2">
                        <Award size={12} className="text-gold" />
                        <span className="text-[10px] font-semibold text-gold">
                          마일스톤: {story.milestone}
                        </span>
                      </div>
                    )}

                    <h3 className="text-base font-serif font-bold group-hover:text-dream transition-colors mb-1.5">
                      {story.title}
                    </h3>
                    <p className="text-sm text-muted-foreground leading-relaxed line-clamp-2">
                      {story.excerpt}
                    </p>

                    <div className="flex items-center gap-4 mt-3">
                      <span className={`ink-tag text-[10px] ${story.tag === '다시, 잇다' ? '!bg-coral/10 !text-coral !border-coral/20' : ''}`}>
                        {story.tag}
                      </span>
                      <span className="flex items-center gap-1 text-coral text-xs font-semibold">
                        <Heart size={12} className="fill-coral" /> {story.cheers} 응원
                      </span>
                      <span className="flex items-center gap-1 text-xs text-muted-foreground">
                        <MessageCircleHeart size={12} /> {story.comments}
                      </span>
                    </div>
                  </motion.div>
                </Link>
              ))}
            </div>

            <Link href="/write">
              <div className="mt-4 p-4 border border-dashed border-dream/30 rounded-lg text-center hover:bg-dream/5 transition-colors group">
                <PenLine size={20} className="mx-auto text-dream mb-2" />
                <p className="text-sm font-semibold text-dream">나의 이야기를 들려주세요</p>
                <p className="text-xs text-muted-foreground mt-1">
                  당신의 한 줄이 누군가에게 큰 힘이 됩니다
                </p>
              </div>
            </Link>
          </section>

          {/* ═══ 구체 30% — 도구 섹션 ═══ */}
          <section className="mb-8">
            <div className="flex items-center gap-2 mb-4">
              <Target size={16} className="text-muted-foreground" />
              <h2 className="editorial-heading text-lg">꿈을 위한 도구</h2>
              <span className="text-[10px] text-muted-foreground bg-muted px-2 py-0.5 rounded">
                구체 영역
              </span>
            </div>
            <hr className="editorial-divider-thick mt-0 mb-4" />

            <div className="grid grid-cols-3 gap-3">
              {quickTools.map((tool) => (
                <Link key={tool.title} href={tool.href}>
                  <div className="ink-card p-4 group text-center h-full">
                    <tool.icon size={24} className={`${tool.color} mx-auto mb-2`} />
                    <p className="text-sm font-semibold">{tool.title}</p>
                    <p className="text-[10px] text-muted-foreground mt-0.5">{tool.sub}</p>
                    <span className={`text-[10px] font-semibold ${tool.color} flex items-center justify-center gap-0.5 mt-2 group-hover:gap-1.5 transition-all`}>
                      바로가기 <ArrowRight size={10} />
                    </span>
                  </div>
                </Link>
              ))}
            </div>

            <p className="text-xs text-muted-foreground text-center mt-3 italic">
              "꿈이 방향이라면, 인강·문제집·학원은 그 길 위의 도구입니다."
            </p>
          </section>

          {/* 경로 설계 CTA */}
          <section className="mb-8">
            <div className="relative overflow-hidden rounded-xl">
              <img
                src="https://d2xsxph8kpxj0f.cloudfront.net/310519663433131621/A3XszkVKVy7WNitpyWDbEe/v3-path-design-9amRFwJ4976nQdpHrH9V2g.webp"
                alt="경로 설계"
                className="w-full h-40 lg:h-52 object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-r from-ink/70 to-ink/30" />
              <div className="absolute inset-0 flex items-center px-6 lg:px-10">
                <div>
                  <span className="text-[10px] uppercase tracking-[0.15em] text-gold font-semibold">
                    경로 설계
                  </span>
                  <h3 className="editorial-heading text-xl lg:text-2xl text-white mt-1">
                    어떤 대학, 어떤 학과, 어떤 직업?
                  </h3>
                  <p className="text-white/60 text-sm mt-1 max-w-md">
                    AI가 3가지 경로를 제안합니다 — 도전, 현실, 발견
                  </p>
                  <Link href="/explore">
                    <span className="inline-flex items-center gap-2 mt-3 px-4 py-2 bg-gold text-ink text-sm font-semibold rounded-lg hover:bg-gold/90 transition-colors">
                      <Compass size={14} />
                      경로 탐색하기
                    </span>
                  </Link>
                </div>
              </div>
            </div>
          </section>
        </div>

        {/* ── Right Sidebar (Desktop) ── */}
        <aside className="hidden lg:block space-y-6">
          {/* "다시, 잇다" 사이드바 카드 */}
          <div className="ink-card p-4 bg-gradient-to-b from-coral/5 to-transparent border-coral/20">
            <div className="flex items-center gap-2 mb-3">
              <Sunrise size={14} className="text-coral" />
              <span className="text-xs font-semibold tracking-wider uppercase text-coral">
                다시, 잇다
              </span>
            </div>
            <p className="text-sm leading-relaxed mb-3">
              <span className="font-bold text-coral">{reStarterStats.total.toLocaleString()}명</span>이
              끊어진 꿈을 다시 잇고 있습니다.
            </p>
            <div className="space-y-2 mb-3">
              {reStarterQuotes.slice(1).map((q, i) => (
                <div key={i} className="bg-coral/5 rounded-lg p-2.5">
                  <p className="text-xs italic leading-relaxed">"{q.text}"</p>
                  <p className="text-[10px] text-coral mt-1">— {q.author}</p>
                </div>
              ))}
            </div>
            <Link href="/stories">
              <span className="text-xs text-coral hover:underline block text-center font-medium">
                다시, 잇다 이야기 더 보기 →
              </span>
            </Link>
          </div>

          {/* 꿈 동료 */}
          <div className="dream-card p-4">
            <div className="flex items-center gap-2 mb-3">
              <Users size={14} className="text-dream" />
              <span className="text-xs font-semibold tracking-wider uppercase text-dream">
                같은 꿈을 꾸는 사람들
              </span>
            </div>
            <div className="space-y-2.5">
              {dreamComrades.map((c, i) => (
                <div key={i} className="flex items-center gap-2.5">
                  <div className="w-8 h-8 bg-dream/10 text-dream rounded-full flex items-center justify-center text-xs font-bold">
                    {c.name[0]}
                  </div>
                  <div className="flex-1">
                    <p className="text-sm font-medium">{c.name}</p>
                    <p className="text-[10px] text-muted-foreground">{c.dream} · {c.daysActive}일째</p>
                  </div>
                  <button className="cheer-btn text-[10px] py-1 px-2.5">
                    응원
                  </button>
                </div>
              ))}
            </div>
            <Link href="/dream">
              <span className="text-xs text-dream hover:underline mt-3 block text-center">
                꿈 동료 더 보기 →
              </span>
            </Link>
          </div>

          {/* 인기 꿈 랭킹 */}
          <div className="ink-card p-4">
            <div className="flex items-center gap-2 mb-3">
              <Flame size={14} className="text-coral" />
              <span className="text-xs font-semibold tracking-wider uppercase">
                인기 꿈 TOP 5
              </span>
            </div>
            <div className="space-y-2.5">
              {topDreams.map((d, i) => (
                <div key={i} className="flex items-center gap-2.5">
                  <span className="text-lg font-mono font-bold text-muted-foreground/40 w-5 text-right shrink-0">
                    {i + 1}
                  </span>
                  <span className="text-base">{d.icon}</span>
                  <div className="flex-1">
                    <p className="text-sm font-medium">{d.dream}</p>
                    <p className="text-[10px] text-muted-foreground">{d.dreamers.toLocaleString()}명이 꿈꾸는 중</p>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* 성장 미니 대시보드 */}
          <div className="ink-card p-4">
            <div className="flex items-center gap-2 mb-3">
              <TrendingUp size={14} className="text-growth" />
              <span className="text-xs font-semibold tracking-wider uppercase">나의 성장</span>
            </div>
            <div className="grid grid-cols-3 gap-2 text-center mb-3">
              <div className="bg-secondary/50 rounded-lg p-2">
                <p className="text-lg font-bold text-dream">142</p>
                <p className="text-[10px] text-muted-foreground">연속 일수</p>
              </div>
              <div className="bg-secondary/50 rounded-lg p-2">
                <p className="text-lg font-bold text-coral">47</p>
                <p className="text-[10px] text-muted-foreground">작성 이야기</p>
              </div>
              <div className="bg-secondary/50 rounded-lg p-2">
                <p className="text-lg font-bold text-gold">1,250</p>
                <p className="text-[10px] text-muted-foreground">KNC</p>
              </div>
            </div>
            <Link href="/growth">
              <span className="text-xs text-muted-foreground hover:text-foreground ink-link block text-center">
                성장 대시보드 →
              </span>
            </Link>
          </div>

          {/* AI 경로 추천 */}
          <div className="ink-card p-4 bg-dream/5 border-dream/20">
            <div className="flex items-center gap-2 mb-3">
              <Sparkles size={14} className="text-dream" />
              <span className="text-xs font-semibold tracking-wider uppercase">AI 경로 추천</span>
            </div>
            <p className="text-sm leading-relaxed mb-3">
              나의 꿈과 현재 성적을 기반으로 AI가 <span className="font-bold text-dream">3가지 경로</span>를 제안합니다.
            </p>
            <Link href="/explore">
              <span className="flex items-center justify-center gap-1.5 w-full py-2 bg-dream text-white text-sm font-semibold rounded-lg hover:bg-dream/90 transition-colors">
                <Compass size={14} />
                경로 탐색
              </span>
            </Link>
          </div>

          {/* 크레딧 */}
          <div className="ink-card p-4">
            <div className="flex items-center gap-2 mb-2">
              <Coins size={14} className="text-gold" />
              <span className="text-xs font-semibold tracking-wider uppercase">성장의 화폐</span>
            </div>
            <div className="flex items-baseline gap-1 mb-1">
              <span className="editorial-heading text-2xl text-gold">1,250</span>
              <span className="text-xs text-muted-foreground">KNC</span>
            </div>
            <div className="flex items-center gap-2 text-[10px] text-muted-foreground mb-3">
              <Award size={10} /> Lv.3 꿈의 탐험가 · 다음 레벨까지 750 KNC
            </div>
            <p className="text-[10px] text-muted-foreground italic mb-2">
              "크레딧은 점수가 아니라, 성장의 발자국입니다."
            </p>
            <Link href="/credits">
              <span className="text-xs text-muted-foreground hover:text-foreground ink-link">
                크레딧 관리 →
              </span>
            </Link>
          </div>
        </aside>
      </div>
    </div>
  );
}
