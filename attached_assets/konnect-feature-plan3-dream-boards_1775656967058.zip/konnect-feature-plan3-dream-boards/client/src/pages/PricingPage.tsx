/*
 * 3안 최종 — 요금제 안내 페이지
 * 무료 기능 vs Premium 기능 비교
 * 하이브리드 과금 모델 (구독 + 건별)
 */
import { useState } from "react";
import { Link } from "wouter";
import { motion } from "framer-motion";
import {
  Check, X, Crown, Zap, ClipboardCheck, Brain, FileEdit,
  Mic, Compass, Target, TrendingUp, ArrowRight, Star,
  Users, BookOpen, BarChart3,
} from "lucide-react";
import { toast } from "sonner";

type PlanType = "free" | "premium" | "payperuse";

interface Feature {
  name: string;
  free: string | boolean;
  premium: string | boolean;
  payperuse: string | boolean;
  category: "diagnosis" | "ai-tool" | "community" | "report";
}

const features: Feature[] = [
  // 자기진단 (무료)
  { name: "AI 적성 분석", free: true, premium: true, payperuse: true, category: "diagnosis" },
  { name: "학업 역량 자가 진단", free: true, premium: true, payperuse: true, category: "diagnosis" },
  { name: "입시 전략 진단 (수시/정시)", free: true, premium: true, payperuse: true, category: "diagnosis" },
  { name: "학습 습관 진단", free: true, premium: true, payperuse: true, category: "diagnosis" },
  { name: "월간 성장 리포트", free: true, premium: true, payperuse: true, category: "report" },
  // 커뮤니티 (무료)
  { name: "꿈 보드 참여 (무제한)", free: true, premium: true, payperuse: true, category: "community" },
  { name: "게시글 작성 & 댓글", free: true, premium: true, payperuse: true, category: "community" },
  { name: "AI 탐색 엔진", free: true, premium: true, payperuse: true, category: "community" },
  { name: "동료 로드맵 비교", free: true, premium: true, payperuse: true, category: "community" },
  // AI 도구 (유료)
  { name: "AI 생기부 분석", free: "1회 무료", premium: "무제한", payperuse: "건당 2,000원", category: "ai-tool" },
  { name: "AI 자소서 첨삭", free: "1회 무료", premium: "무제한", payperuse: "건당 3,000원", category: "ai-tool" },
  { name: "AI 면접 연습 (3문항)", free: "1회 무료", premium: "무제한", payperuse: "건당 2,500원", category: "ai-tool" },
  { name: "AI 면접 연습 (풀세트 10문항)", free: false, premium: "무제한", payperuse: "건당 5,000원", category: "ai-tool" },
  { name: "AI 학업계획서 작성", free: false, premium: "무제한", payperuse: "건당 3,000원", category: "ai-tool" },
  // 리포트 (유료)
  { name: "심층 역량 분석 리포트", free: false, premium: true, payperuse: "건당 5,000원", category: "report" },
  { name: "대학별 맞춤 전략 리포트", free: false, premium: true, payperuse: "건당 8,000원", category: "report" },
];

const plans = [
  {
    key: "free" as PlanType,
    name: "무료",
    price: "₩0",
    period: "영구 무료",
    description: "자기진단과 커뮤니티 기능을 무료로 이용하세요",
    highlight: false,
    cta: "현재 이용 중",
    ctaDisabled: true,
    icon: ClipboardCheck,
    color: "text-emerald-600",
    bgColor: "bg-emerald-50",
    borderColor: "border-emerald-200",
  },
  {
    key: "premium" as PlanType,
    name: "Premium",
    price: "₩19,900",
    period: "/ 월",
    description: "모든 AI 도구를 무제한으로 이용하세요",
    highlight: true,
    cta: "Premium 시작하기",
    ctaDisabled: false,
    icon: Crown,
    color: "text-dream",
    bgColor: "bg-dream/5",
    borderColor: "border-dream/30",
  },
  {
    key: "payperuse" as PlanType,
    name: "건별 결제",
    price: "₩2,000~",
    period: "/ 건",
    description: "필요한 도구만 골라서 사용하세요",
    highlight: false,
    cta: "건별 결제 이용하기",
    ctaDisabled: false,
    icon: Zap,
    color: "text-blue-600",
    bgColor: "bg-blue-50",
    borderColor: "border-blue-200",
  },
];

function FeatureValue({ value }: { value: string | boolean }) {
  if (value === true) return <Check size={16} className="text-emerald-500 mx-auto" />;
  if (value === false) return <X size={16} className="text-muted-foreground/30 mx-auto" />;
  return <span className="text-xs text-center">{value}</span>;
}

export default function PricingPage() {
  const [billingCycle, setBillingCycle] = useState<"monthly" | "yearly">("monthly");

  return (
    <div className="max-w-5xl mx-auto px-4 lg:px-6 py-8">
      {/* Header */}
      <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="text-center mb-10">
        <h1 className="font-serif text-2xl md:text-3xl font-bold mb-2">요금제 안내</h1>
        <p className="text-sm text-muted-foreground max-w-lg mx-auto">
          자기진단과 커뮤니티는 영구 무료. AI 서류 도구와 면접 연습은 Premium으로 업그레이드하세요.
        </p>

        {/* Billing Toggle */}
        <div className="flex items-center justify-center gap-3 mt-5">
          <button
            onClick={() => setBillingCycle("monthly")}
            className={`px-4 py-2 text-sm transition-all rounded ${
              billingCycle === "monthly" ? "bg-foreground text-background font-semibold" : "text-muted-foreground hover:text-foreground"
            }`}
          >
            월간 결제
          </button>
          <button
            onClick={() => setBillingCycle("yearly")}
            className={`px-4 py-2 text-sm transition-all rounded relative ${
              billingCycle === "yearly" ? "bg-foreground text-background font-semibold" : "text-muted-foreground hover:text-foreground"
            }`}
          >
            연간 결제
            <span className="absolute -top-2 -right-2 text-[9px] bg-dream text-white px-1.5 py-0.5 rounded-full font-bold">
              -20%
            </span>
          </button>
        </div>
      </motion.div>

      {/* Plan Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-12">
        {plans.map((plan, i) => (
          <motion.div
            key={plan.key}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 * i }}
            className={`relative border-2 ${plan.highlight ? plan.borderColor : "border-border"} p-6 rounded-lg ${plan.highlight ? "shadow-lg" : ""}`}
          >
            {plan.highlight && (
              <div className="absolute -top-3 left-1/2 -translate-x-1/2 px-3 py-1 bg-dream text-white text-[10px] font-bold rounded-full">
                추천
              </div>
            )}
            <div className="flex items-center gap-2 mb-3">
              <div className={`w-8 h-8 ${plan.bgColor} rounded-lg flex items-center justify-center`}>
                <plan.icon size={16} className={plan.color} />
              </div>
              <h3 className="font-serif font-bold text-lg">{plan.name}</h3>
            </div>
            <div className="mb-3">
              <span className="text-2xl font-bold">
                {plan.key === "premium" && billingCycle === "yearly" ? "₩15,900" : plan.price}
              </span>
              <span className="text-sm text-muted-foreground ml-1">{plan.period}</span>
            </div>
            <p className="text-xs text-muted-foreground mb-5">{plan.description}</p>
            <button
              onClick={() => {
                if (plan.ctaDisabled) return;
                toast.info("결제 기능은 곧 오픈됩니다. 무료 체험을 먼저 이용해 보세요!");
              }}
              disabled={plan.ctaDisabled}
              className={`w-full py-2.5 text-sm font-semibold rounded transition-all ${
                plan.highlight
                  ? "bg-dream text-white hover:bg-dream/90"
                  : plan.ctaDisabled
                  ? "bg-secondary text-muted-foreground cursor-default"
                  : "bg-foreground text-background hover:bg-foreground/90"
              }`}
            >
              {plan.cta}
            </button>
          </motion.div>
        ))}
      </div>

      {/* Feature Comparison Table */}
      <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.4 }}>
        <h2 className="font-serif text-xl font-bold text-center mb-6">기능 비교표</h2>

        <div className="border border-border rounded-lg overflow-hidden">
          {/* Header */}
          <div className="grid grid-cols-4 bg-secondary/50 text-xs font-semibold">
            <div className="p-3">기능</div>
            <div className="p-3 text-center">무료</div>
            <div className="p-3 text-center text-dream">Premium</div>
            <div className="p-3 text-center">건별 결제</div>
          </div>

          {/* Diagnosis */}
          <div className="px-3 py-2 bg-emerald-50/50 text-[10px] font-semibold text-emerald-700 flex items-center gap-1">
            <ClipboardCheck size={10} /> 자기진단 & 평가
          </div>
          {features.filter((f) => f.category === "diagnosis").map((f) => (
            <div key={f.name} className="grid grid-cols-4 border-t border-border/50 text-xs">
              <div className="p-3 text-muted-foreground">{f.name}</div>
              <div className="p-3 flex items-center justify-center"><FeatureValue value={f.free} /></div>
              <div className="p-3 flex items-center justify-center"><FeatureValue value={f.premium} /></div>
              <div className="p-3 flex items-center justify-center"><FeatureValue value={f.payperuse} /></div>
            </div>
          ))}

          {/* Community */}
          <div className="px-3 py-2 bg-blue-50/50 text-[10px] font-semibold text-blue-700 flex items-center gap-1">
            <Users size={10} /> 커뮤니티
          </div>
          {features.filter((f) => f.category === "community").map((f) => (
            <div key={f.name} className="grid grid-cols-4 border-t border-border/50 text-xs">
              <div className="p-3 text-muted-foreground">{f.name}</div>
              <div className="p-3 flex items-center justify-center"><FeatureValue value={f.free} /></div>
              <div className="p-3 flex items-center justify-center"><FeatureValue value={f.premium} /></div>
              <div className="p-3 flex items-center justify-center"><FeatureValue value={f.payperuse} /></div>
            </div>
          ))}

          {/* AI Tools */}
          <div className="px-3 py-2 bg-dream/5 text-[10px] font-semibold text-dream flex items-center gap-1">
            <Crown size={10} /> AI 도구 (Premium)
          </div>
          {features.filter((f) => f.category === "ai-tool").map((f) => (
            <div key={f.name} className="grid grid-cols-4 border-t border-border/50 text-xs">
              <div className="p-3 text-muted-foreground">{f.name}</div>
              <div className="p-3 flex items-center justify-center"><FeatureValue value={f.free} /></div>
              <div className="p-3 flex items-center justify-center"><FeatureValue value={f.premium} /></div>
              <div className="p-3 flex items-center justify-center"><FeatureValue value={f.payperuse} /></div>
            </div>
          ))}

          {/* Reports */}
          <div className="px-3 py-2 bg-amber-50/50 text-[10px] font-semibold text-amber-700 flex items-center gap-1">
            <BarChart3 size={10} /> 리포트
          </div>
          {features.filter((f) => f.category === "report").map((f) => (
            <div key={f.name} className="grid grid-cols-4 border-t border-border/50 text-xs">
              <div className="p-3 text-muted-foreground">{f.name}</div>
              <div className="p-3 flex items-center justify-center"><FeatureValue value={f.free} /></div>
              <div className="p-3 flex items-center justify-center"><FeatureValue value={f.premium} /></div>
              <div className="p-3 flex items-center justify-center"><FeatureValue value={f.payperuse} /></div>
            </div>
          ))}
        </div>
      </motion.div>

      {/* FAQ */}
      <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.5 }} className="mt-12">
        <h2 className="font-serif text-xl font-bold text-center mb-6">자주 묻는 질문</h2>
        <div className="space-y-4 max-w-2xl mx-auto">
          {[
            {
              q: "무료 체험은 어떻게 이용하나요?",
              a: "AI 생기부 분석, 자소서 첨삭, 면접 연습 각각 1회씩 무료로 체험할 수 있습니다. 별도 결제 정보 입력 없이 바로 이용 가능합니다.",
            },
            {
              q: "Premium과 건별 결제 중 어떤 것이 유리한가요?",
              a: "월 5회 이상 AI 도구를 사용한다면 Premium이 유리합니다. 가끔 필요할 때만 사용한다면 건별 결제가 경제적입니다.",
            },
            {
              q: "연간 결제 시 환불이 가능한가요?",
              a: "결제 후 7일 이내 미사용 시 전액 환불이 가능합니다. 이후에는 잔여 기간에 대한 부분 환불이 적용됩니다.",
            },
            {
              q: "자기진단은 정말 무료인가요?",
              a: "네, 4종 자기진단(적성 분석, 학업 역량, 입시 전략, 학습 습관)과 월간 성장 리포트는 영구 무료입니다. 횟수 제한도 없습니다.",
            },
          ].map((faq, i) => (
            <div key={i} className="border border-border p-4 rounded-lg">
              <h3 className="font-semibold text-sm mb-2">{faq.q}</h3>
              <p className="text-xs text-muted-foreground leading-relaxed">{faq.a}</p>
            </div>
          ))}
        </div>
      </motion.div>

      {/* Bottom CTA */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.6 }}
        className="text-center mt-12 p-8 bg-gradient-to-r from-dream/5 via-violet-50 to-amber-50 border border-dream/20 rounded-lg"
      >
        <h3 className="font-serif text-lg font-bold mb-2">아직 고민 중이라면?</h3>
        <p className="text-sm text-muted-foreground mb-4">
          먼저 무료 자기진단으로 시작하세요. 나를 알면 꿈이 보입니다.
        </p>
        <div className="flex justify-center gap-3">
          <Link href="/diagnosis">
            <span className="inline-flex items-center gap-1.5 px-5 py-2.5 text-sm bg-foreground text-background font-semibold rounded hover:bg-foreground/90 transition-colors">
              무료 자기진단 시작 <ArrowRight size={14} />
            </span>
          </Link>
          <Link href="/boards">
            <span className="inline-flex items-center gap-1.5 px-5 py-2.5 text-sm border border-foreground text-foreground font-semibold rounded hover:bg-secondary transition-colors">
              꿈 보드 둘러보기
            </span>
          </Link>
        </div>
      </motion.div>
    </div>
  );
}
