/*
 * Konnect v3 — 직업 탐색 페이지
 * 꿈에서 직업으로, 직업에서 학과로, 학과에서 대학으로 역추적
 */
import { useState } from "react";
import { Link } from "wouter";
import { motion } from "framer-motion";
import {
  Briefcase,
  GraduationCap,
  TrendingUp,
  Heart,
  ChevronRight,
  Search,
  Star,
  Users,
  Sparkles,
  ArrowRight,
} from "lucide-react";
import { toast } from "sonner";

const careers = [
  {
    id: 1,
    title: "의사",
    field: "의학",
    avgSalary: "1억 2천만원",
    growth: "+5%",
    description: "환자를 진단하고 치료하는 의료 전문가. 전문의 과정 포함 최소 11년의 교육 필요.",
    requiredDepts: ["의예과", "의학과"],
    dreamers: 2340,
    relatedCareers: ["치과의사", "한의사", "수의사"],
  },
  {
    id: 2,
    title: "소프트웨어 개발자",
    field: "IT",
    avgSalary: "7천만원",
    growth: "+22%",
    description: "소프트웨어를 설계하고 개발하는 전문가. AI, 클라우드, 보안 등 다양한 분야.",
    requiredDepts: ["컴퓨터공학과", "소프트웨어학과", "정보통신공학과"],
    dreamers: 1890,
    relatedCareers: ["데이터 과학자", "AI 엔지니어", "보안 전문가"],
  },
  {
    id: 3,
    title: "변호사",
    field: "법학",
    avgSalary: "9천만원",
    growth: "+3%",
    description: "법률 자문과 소송 대리를 수행하는 법률 전문가. 로스쿨 3년 과정 필요.",
    requiredDepts: ["법학과", "법학전문대학원"],
    dreamers: 1560,
    relatedCareers: ["검사", "판사", "법무사"],
  },
  {
    id: 4,
    title: "경영 컨설턴트",
    field: "경영",
    avgSalary: "8천만원",
    growth: "+12%",
    description: "기업의 경영 전략을 분석하고 개선 방안을 제시하는 전문가.",
    requiredDepts: ["경영학과", "경제학과", "산업공학과"],
    dreamers: 1230,
    relatedCareers: ["투자은행가", "회계사", "마케팅 전문가"],
  },
  {
    id: 5,
    title: "생명과학 연구원",
    field: "자연과학",
    avgSalary: "5천5백만원",
    growth: "+18%",
    description: "생명 현상을 연구하고 신약 개발, 유전자 치료 등에 기여하는 연구자.",
    requiredDepts: ["생명과학부", "생물학과", "생화학과"],
    dreamers: 890,
    relatedCareers: ["약학 연구원", "바이오 엔지니어", "임상시험 전문가"],
  },
  {
    id: 6,
    title: "건축가",
    field: "예술/공학",
    avgSalary: "6천만원",
    growth: "+7%",
    description: "건축물을 설계하고 감리하는 전문가. 공학적 지식과 예술적 감각이 모두 필요.",
    requiredDepts: ["건축학과", "건축공학과"],
    dreamers: 670,
    relatedCareers: ["인테리어 디자이너", "도시계획가", "조경설계사"],
  },
];

export default function Career() {
  const [selectedField, setSelectedField] = useState("전체");
  const fields = ["전체", "의학", "IT", "법학", "경영", "자연과학", "예술/공학"];

  const filtered = selectedField === "전체"
    ? careers
    : careers.filter((c) => c.field === selectedField);

  return (
    <div className="max-w-7xl mx-auto px-4 lg:px-6 py-6">
      {/* Header */}
      <section className="mb-6">
        <span className="text-[10px] uppercase tracking-[0.2em] text-dream font-semibold">
          Career Explorer
        </span>
        <h1 className="editorial-heading text-2xl lg:text-3xl mt-1">직업 탐색</h1>
        <p className="text-sm text-muted-foreground mt-1">
          어떤 사람이 되고 싶은지 탐색하고, 그 꿈에 맞는 학과와 대학을 역추적합니다.
        </p>
        <hr className="editorial-divider-thick mt-4" />
      </section>

      {/* Field Filter */}
      <div className="flex gap-2 mb-6 overflow-x-auto pb-2">
        {fields.map((f) => (
          <button
            key={f}
            onClick={() => setSelectedField(f)}
            className={`px-3 py-1.5 text-sm rounded-lg whitespace-nowrap transition-colors ${
              selectedField === f
                ? "bg-dream text-white font-semibold"
                : "bg-secondary text-muted-foreground hover:bg-accent"
            }`}
          >
            {f}
          </button>
        ))}
      </div>

      <div className="lg:grid lg:grid-cols-[1fr_320px] lg:gap-8">
        <div className="space-y-4">
          {filtered.map((career) => (
            <motion.div
              key={career.id}
              className="ink-card p-5"
              whileHover={{ y: -2 }}
            >
              <div className="flex items-start justify-between mb-3">
                <div>
                  <div className="flex items-center gap-2 mb-1">
                    <Briefcase size={16} className="text-dream" />
                    <h3 className="editorial-heading text-lg">{career.title}</h3>
                    <span className="ink-tag text-[10px]">{career.field}</span>
                  </div>
                  <p className="text-sm text-muted-foreground leading-relaxed">
                    {career.description}
                  </p>
                </div>
              </div>

              <div className="grid grid-cols-3 gap-3 my-4">
                <div className="bg-secondary/50 rounded-lg p-2.5 text-center">
                  <p className="text-sm font-bold text-gold">{career.avgSalary}</p>
                  <p className="text-[10px] text-muted-foreground">평균 연봉</p>
                </div>
                <div className="bg-secondary/50 rounded-lg p-2.5 text-center">
                  <p className="text-sm font-bold text-growth">{career.growth}</p>
                  <p className="text-[10px] text-muted-foreground">성장률</p>
                </div>
                <div className="bg-secondary/50 rounded-lg p-2.5 text-center">
                  <p className="text-sm font-bold text-coral">{career.dreamers.toLocaleString()}</p>
                  <p className="text-[10px] text-muted-foreground">꿈꾸는 중</p>
                </div>
              </div>

              <div className="mb-3">
                <p className="text-[10px] font-semibold uppercase tracking-wider mb-1.5">관련 학과</p>
                <div className="flex flex-wrap gap-1.5">
                  {career.requiredDepts.map((d) => (
                    <span key={d} className="text-xs bg-dream/10 text-dream px-2 py-0.5 rounded">
                      {d}
                    </span>
                  ))}
                </div>
              </div>

              <div>
                <p className="text-[10px] font-semibold uppercase tracking-wider mb-1.5">유사 직업</p>
                <div className="flex flex-wrap gap-1.5">
                  {career.relatedCareers.map((r) => (
                    <span key={r} className="text-xs bg-secondary text-muted-foreground px-2 py-0.5 rounded">
                      {r}
                    </span>
                  ))}
                </div>
              </div>
            </motion.div>
          ))}
        </div>

        {/* Sidebar */}
        <aside className="hidden lg:block space-y-6">
          <div className="dream-card p-4">
            <div className="flex items-center gap-2 mb-3">
              <Sparkles size={14} className="text-dream" />
              <span className="text-xs font-semibold tracking-wider uppercase text-dream">
                꿈 → 직업 → 학과
              </span>
            </div>
            <p className="text-sm leading-relaxed text-muted-foreground mb-3">
              직업을 선택하면 필요한 <span className="font-bold text-foreground">학과</span>와{" "}
              <span className="font-bold text-foreground">대학</span>을 역추적할 수 있습니다.
            </p>
            <Link href="/explore">
              <span className="flex items-center justify-center gap-1.5 w-full py-2 bg-dream text-white text-sm font-semibold rounded-lg hover:bg-dream/90 transition-colors">
                대학·학과 탐색 <ArrowRight size={14} />
              </span>
            </Link>
          </div>

          <div className="ink-card p-4">
            <div className="flex items-center gap-2 mb-3">
              <TrendingUp size={14} className="text-growth" />
              <span className="text-xs font-semibold tracking-wider uppercase">성장 직업 TOP</span>
            </div>
            <div className="space-y-2.5">
              {careers
                .sort((a, b) => parseInt(b.growth) - parseInt(a.growth))
                .slice(0, 4)
                .map((c, i) => (
                  <div key={c.id} className="flex items-center gap-2.5">
                    <span className="text-lg font-mono font-bold text-muted-foreground/40 w-5 text-right shrink-0">
                      {i + 1}
                    </span>
                    <div className="flex-1">
                      <p className="text-sm font-medium">{c.title}</p>
                      <p className="text-[10px] text-muted-foreground">{c.field}</p>
                    </div>
                    <span className="text-xs font-bold text-growth">{c.growth}</span>
                  </div>
                ))}
            </div>
          </div>
        </aside>
      </div>
    </div>
  );
}
