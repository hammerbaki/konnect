/*
 * Design: Neo-Brutalism + Gen-Z Energy
 * - Quiz cards with thick borders
 * - Animated feedback on answer selection
 * - Progress bar, score counter, streak display
 */
import { useState, useCallback } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { CheckCircle, XCircle, ArrowRight, RotateCcw, Trophy, Zap, Star } from "lucide-react";
import { toast } from "sonner";

interface QuizQuestion {
  id: number;
  question: string;
  options: string[];
  correct: number;
  explanation: string;
  category: string;
}

const quizData: QuizQuestion[] = [
  {
    id: 1,
    question: "2027학년도 수능에서 '통합사회'와 '통합과학'은 어떤 영역에 해당할까요?",
    options: ["선택과목", "공통과목", "탐구영역", "제2외국어"],
    correct: 1,
    explanation: "통합사회와 통합과학은 2028학년도부터 변경 예정이지만, 2027학년도까지는 공통과목으로 분류됩니다.",
    category: "수능 기본",
  },
  {
    id: 2,
    question: "학생부종합전형(학종)에서 가장 중요하게 평가하는 요소는?",
    options: ["내신 성적만", "수능 성적", "학교생활기록부 전체", "자기소개서"],
    correct: 2,
    explanation: "학종은 학교생활기록부의 교과 성적, 세부능력특기사항, 창의적 체험활동 등을 종합적으로 평가합니다.",
    category: "수시 전형",
  },
  {
    id: 3,
    question: "정시 전형에서 '가/나/다' 군의 의미는?",
    options: ["성적 등급 구분", "모집 시기 구분", "대학 등급 구분", "학과 분류 구분"],
    correct: 1,
    explanation: "정시는 가/나/다 군으로 나뉘어 모집 시기가 다르며, 각 군별로 1개 대학에만 지원할 수 있어 최대 3개 대학에 지원 가능합니다.",
    category: "정시 전형",
  },
  {
    id: 4,
    question: "수능 영어 영역의 평가 방식은?",
    options: ["상대평가", "절대평가", "P/F 평가", "서술형 평가"],
    correct: 1,
    explanation: "수능 영어는 2018학년도부터 절대평가로 전환되었습니다. 원점수 90점 이상이면 1등급입니다.",
    category: "수능 기본",
  },
  {
    id: 5,
    question: "다음 중 '논술전형'에 대한 설명으로 올바른 것은?",
    options: [
      "모든 대학에서 실시한다",
      "수능 최저학력기준이 없다",
      "대학별 논술고사를 치른다",
      "학생부 성적만으로 선발한다",
    ],
    correct: 2,
    explanation: "논술전형은 대학별로 자체 출제한 논술고사를 통해 선발하며, 일부 대학은 수능 최저학력기준을 적용합니다.",
    category: "수시 전형",
  },
  {
    id: 6,
    question: "수능 탐구영역에서 최대 몇 과목까지 선택할 수 있나요?",
    options: ["1과목", "2과목", "3과목", "4과목"],
    correct: 1,
    explanation: "수능 탐구영역은 사회탐구와 과학탐구 중 최대 2과목까지 선택할 수 있습니다.",
    category: "수능 기본",
  },
  {
    id: 7,
    question: "'수시 6장'이라는 말의 의미는?",
    options: [
      "수시에 6번 지원 가능",
      "6개 대학에 원서 제출 가능",
      "6개 학과에 지원 가능",
      "6번 면접을 볼 수 있음",
    ],
    correct: 1,
    explanation: "수시모집에서는 최대 6개 대학(6장)에 원서를 접수할 수 있습니다. 전형 유형에 관계없이 총 6회입니다.",
    category: "수시 전형",
  },
  {
    id: 8,
    question: "다음 중 '교과전형'의 특징으로 맞는 것은?",
    options: [
      "비교과 활동이 가장 중요하다",
      "내신 성적 중심으로 선발한다",
      "수능 성적으로만 선발한다",
      "면접이 필수이다",
    ],
    correct: 1,
    explanation: "교과전형은 학교 내신 성적(교과 성적)을 중심으로 학생을 선발하는 전형입니다.",
    category: "수시 전형",
  },
];

export default function Quiz() {
  const [currentQ, setCurrentQ] = useState(0);
  const [selected, setSelected] = useState<number | null>(null);
  const [score, setScore] = useState(0);
  const [streak, setStreak] = useState(0);
  const [showResult, setShowResult] = useState(false);
  const [answered, setAnswered] = useState(false);
  const [quizComplete, setQuizComplete] = useState(false);

  const question = quizData[currentQ];
  const progress = ((currentQ + (answered ? 1 : 0)) / quizData.length) * 100;

  const handleSelect = useCallback(
    (idx: number) => {
      if (answered) return;
      setSelected(idx);
      setAnswered(true);
      setShowResult(true);

      if (idx === question.correct) {
        setScore((s) => s + 1);
        setStreak((s) => s + 1);
        toast.success("정답! 🎉", { duration: 1500 });
      } else {
        setStreak(0);
        toast.error("아쉬워요! 😢", { duration: 1500 });
      }
    },
    [answered, question.correct]
  );

  const handleNext = useCallback(() => {
    if (currentQ < quizData.length - 1) {
      setCurrentQ((q) => q + 1);
      setSelected(null);
      setAnswered(false);
      setShowResult(false);
    } else {
      setQuizComplete(true);
    }
  }, [currentQ]);

  const handleRestart = useCallback(() => {
    setCurrentQ(0);
    setSelected(null);
    setScore(0);
    setStreak(0);
    setAnswered(false);
    setShowResult(false);
    setQuizComplete(false);
  }, []);

  if (quizComplete) {
    const percentage = Math.round((score / quizData.length) * 100);
    return (
      <div className="container py-12">
        <motion.div
          initial={{ scale: 0.8, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          className="max-w-lg mx-auto text-center"
        >
          <div className="brutal-card bg-white p-8 rounded-lg">
            <Trophy size={64} className="mx-auto text-konnect-yellow mb-4" />
            <h2 className="font-display text-4xl mb-2">퀴즈 완료!</h2>
            <div className="brutal-tag bg-konnect-yellow text-foreground text-lg my-4 inline-block">
              {score} / {quizData.length} 정답
            </div>
            <p className="text-2xl font-bold mb-2">{percentage}%</p>
            <p className="text-muted-foreground mb-6">
              {percentage >= 80
                ? "대단해요! 입시 전문가 수준이에요! 🏆"
                : percentage >= 60
                ? "잘했어요! 조금만 더 공부하면 완벽해요! 💪"
                : "괜찮아요! 매일 퀴즈를 풀면서 실력을 쌓아봐요! 📚"}
            </p>
            <button
              onClick={handleRestart}
              className="brutal-btn bg-primary text-white px-8 py-3 text-lg inline-flex items-center gap-2"
            >
              <RotateCcw size={20} /> 다시 풀기
            </button>
          </div>
        </motion.div>
      </div>
    );
  }

  return (
    <div className="container py-8">
      <div className="max-w-2xl mx-auto">
        {/* Quiz Header with Image */}
        {currentQ === 0 && !answered && (
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            className="brutal-card rounded-lg overflow-hidden mb-6"
          >
            <img
              src="https://d2xsxph8kpxj0f.cloudfront.net/310519663433131621/A3XszkVKVy7WNitpyWDbEe/quiz-section-nU44qodQjDba2mF42efyKn.webp"
              alt="입시 퀴즈"
              className="w-full h-40 object-cover"
            />
          </motion.div>
        )}

        {/* Header */}
        <div className="flex items-center justify-between mb-6">
          <div>
            <span className="brutal-tag bg-konnect-blue text-white text-xs">
              {question.category}
            </span>
          </div>
          <div className="flex items-center gap-4">
            {streak >= 2 && (
              <motion.div
                initial={{ scale: 0 }}
                animate={{ scale: 1 }}
                className="flex items-center gap-1 brutal-tag bg-konnect-red text-white"
              >
                <Zap size={14} /> {streak}연속!
              </motion.div>
            )}
            <div className="flex items-center gap-1 brutal-tag bg-konnect-yellow text-foreground">
              <Star size={14} /> {score}점
            </div>
          </div>
        </div>

        {/* Progress Bar */}
        <div className="brutal-card bg-white p-1 rounded-full mb-8">
          <div
            className="h-4 bg-primary rounded-full transition-all duration-500"
            style={{ width: `${progress}%` }}
          />
        </div>

        {/* Question Card */}
        <AnimatePresence mode="wait">
          <motion.div
            key={currentQ}
            initial={{ opacity: 0, x: 50 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -50 }}
            transition={{ duration: 0.3 }}
          >
            <div className="brutal-card bg-white p-6 md:p-8 rounded-lg mb-6">
              <div className="text-sm text-muted-foreground mb-2 font-bold">
                Q{currentQ + 1} / {quizData.length}
              </div>
              <h2 className="font-display text-xl md:text-2xl leading-snug">
                {question.question}
              </h2>
            </div>

            {/* Options */}
            <div className="space-y-3">
              {question.options.map((opt, idx) => {
                let optionStyle = "bg-white hover:translate-x-1";
                if (showResult) {
                  if (idx === question.correct) {
                    optionStyle = "bg-green-100 border-green-600";
                  } else if (idx === selected && idx !== question.correct) {
                    optionStyle = "bg-red-100 border-red-500";
                  } else {
                    optionStyle = "bg-gray-50 opacity-60";
                  }
                }

                return (
                  <motion.button
                    key={idx}
                    onClick={() => handleSelect(idx)}
                    disabled={answered}
                    whileTap={!answered ? { scale: 0.98 } : undefined}
                    className={`w-full text-left brutal-card p-4 rounded-lg flex items-center gap-4 transition-all ${optionStyle}`}
                  >
                    <span className="w-8 h-8 flex items-center justify-center border-2 border-current rounded-full font-bold text-sm shrink-0">
                      {String.fromCharCode(65 + idx)}
                    </span>
                    <span className="font-medium flex-1">{opt}</span>
                    {showResult && idx === question.correct && (
                      <CheckCircle className="text-green-600 shrink-0" size={22} />
                    )}
                    {showResult && idx === selected && idx !== question.correct && (
                      <XCircle className="text-red-500 shrink-0" size={22} />
                    )}
                  </motion.button>
                );
              })}
            </div>

            {/* Explanation */}
            {showResult && (
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                className="mt-6"
              >
                <div className="brutal-card bg-konnect-yellow/30 p-5 rounded-lg">
                  <p className="font-bold text-sm mb-1">해설</p>
                  <p className="text-sm leading-relaxed">{question.explanation}</p>
                </div>
                <button
                  onClick={handleNext}
                  className="brutal-btn bg-primary text-white px-8 py-3 text-lg mt-4 w-full flex items-center justify-center gap-2"
                >
                  {currentQ < quizData.length - 1 ? (
                    <>
                      다음 문제 <ArrowRight size={20} />
                    </>
                  ) : (
                    <>
                      결과 보기 <Trophy size={20} />
                    </>
                  )}
                </button>
              </motion.div>
            )}
          </motion.div>
        </AnimatePresence>
      </div>
    </div>
  );
}
