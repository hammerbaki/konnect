/*
 * 3안 보완 — AI 면접 시뮬레이터 (Interview Simulator)
 * 실시간 대화형 AI 면접 + 종합 피드백 + 이력 저장
 * 보드 맥락화: URL 쿼리로 보드 slug 전달 시 대학·학과 자동 입력
 */
import { useState, useRef, useEffect } from "react";
import { Link, useSearch } from "wouter";
import { motion, AnimatePresence } from "framer-motion";
import {
  Mic,
  MicOff,
  Send,
  ChevronRight,
  LayoutGrid,
  User,
  Bot,
  Play,
  Clock,
  Star,
  Award,
  CheckCircle2,
  AlertTriangle,
  Lightbulb,
  RotateCcw,
  History,
  Target,
  GraduationCap,
  MessageSquare,
  BarChart3,
  ArrowLeft,
  Crown,
  Sparkles,
} from "lucide-react";
import { toast } from "sonner";

/* ─── Interview Types ─── */
const interviewTypes = [
  {
    id: "depth",
    label: "심층 면접",
    description: "전공 적합성 및 학업 역량 평가",
    icon: "🔬",
    duration: "15~20분",
    questions: 5,
  },
  {
    id: "personality",
    label: "인성 면접",
    description: "가치관, 공동체 의식, 리더십 평가",
    icon: "💬",
    duration: "10~15분",
    questions: 4,
  },
  {
    id: "document",
    label: "제시문 면접",
    description: "제시문 분석 및 논리적 사고력 평가",
    icon: "📄",
    duration: "20~25분",
    questions: 3,
  },
];

/* ─── Mock conversation ─── */
const mockConversation = [
  {
    role: "interviewer" as const,
    text: "안녕하세요. 서울대학교 의예과 심층 면접을 시작하겠습니다. 편안하게 답변해주세요.",
  },
  {
    role: "interviewer" as const,
    text: "첫 번째 질문입니다. 지원자가 의학을 선택하게 된 계기와, 특히 희귀질환 연구에 관심을 갖게 된 구체적인 경험이 있다면 말씀해주세요.",
  },
];

const followUpQuestions = [
  "그 경험에서 가장 인상 깊었던 순간은 무엇이었나요? 그리고 그것이 의학에 대한 생각을 어떻게 바꾸었나요?",
  "희귀질환 연구를 위해 고등학교 재학 중 어떤 준비를 해왔는지 구체적으로 설명해주세요.",
  "의사가 된다면 환자와의 관계에서 가장 중요하게 생각하는 가치는 무엇인가요?",
  "마지막 질문입니다. 10년 후 본인의 모습을 그려본다면, 어떤 의사가 되어 있을 것 같나요?",
];

/* ─── Mock feedback ─── */
const mockFeedback = {
  score: 78,
  strengths: [
    "진로 동기가 구체적인 경험에 기반하여 진정성이 느껴짐",
    "의학적 지식에 대한 기본적인 이해도가 높음",
    "답변 구조가 논리적이고 일관성이 있음",
  ],
  weaknesses: [
    "일부 답변에서 구체적인 사례 대신 추상적인 표현을 사용",
    "후속 질문에 대한 대응이 다소 경직됨",
    "시간 관리가 필요 — 첫 답변이 길어 후반 답변이 짧아짐",
  ],
  tips: [
    "STAR 기법(상황-과제-행동-결과)을 활용하여 답변을 구조화하세요",
    "면접관의 후속 질문은 더 깊은 성찰을 원하는 것이므로, 새로운 관점을 추가하세요",
    "답변 시간을 2~3분으로 조절하고, 핵심 메시지를 먼저 말한 후 보충 설명하세요",
  ],
};

/* ─── Past sessions ─── */
const pastSessions = [
  {
    id: 1,
    university: "서울대 의예과",
    type: "심층 면접",
    date: "2일 전",
    score: 78,
    questions: 5,
  },
  {
    id: 2,
    university: "연세대 의예과",
    type: "인성 면접",
    date: "5일 전",
    score: 82,
    questions: 4,
  },
  {
    id: 3,
    university: "서울대 의예과",
    type: "제시문 면접",
    date: "1주 전",
    score: 71,
    questions: 3,
  },
];

type Message = {
  role: "interviewer" | "student";
  text: string;
};

export default function InterviewSim() {
  const searchString = useSearch();
  const params = new URLSearchParams(searchString);
  const boardSlug = params.get("board");

  const [phase, setPhase] = useState<"setup" | "interview" | "feedback">(
    "setup"
  );
  const [selectedType, setSelectedType] = useState<string | null>(null);
  const [messages, setMessages] = useState<Message[]>([]);
  const [inputText, setInputText] = useState("");
  const [isTyping, setIsTyping] = useState(false);
  const [questionIndex, setQuestionIndex] = useState(0);
  const [showHistory, setShowHistory] = useState(false);
  const chatEndRef = useRef<HTMLDivElement>(null);

  const boardContext = boardSlug
    ? {
        name:
          boardSlug === "snu"
            ? "서울대"
            : boardSlug === "medicine"
            ? "의예과"
            : boardSlug,
      }
    : null;

  useEffect(() => {
    chatEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  const startInterview = (typeId: string) => {
    setSelectedType(typeId);
    setPhase("interview");
    setMessages([]);
    setQuestionIndex(0);

    // Simulate interviewer greeting
    setTimeout(() => {
      setMessages([...mockConversation]);
    }, 800);
  };

  const sendAnswer = () => {
    if (!inputText.trim()) return;

    const newMessages: Message[] = [
      ...messages,
      { role: "student", text: inputText },
    ];
    setMessages(newMessages);
    setInputText("");
    setIsTyping(true);

    setTimeout(() => {
      setIsTyping(false);
      if (questionIndex < followUpQuestions.length) {
        setMessages([
          ...newMessages,
          { role: "interviewer", text: followUpQuestions[questionIndex] },
        ]);
        setQuestionIndex((prev) => prev + 1);
      } else {
        // Interview complete
        setMessages([
          ...newMessages,
          {
            role: "interviewer",
            text: "면접이 종료되었습니다. 수고하셨습니다. 종합 피드백을 확인해보세요.",
          },
        ]);
        setTimeout(() => setPhase("feedback"), 1500);
      }
    }, 1500);
  };

  const typeInfo = interviewTypes.find((t) => t.id === selectedType);

  return (
    <div className="max-w-7xl mx-auto px-4 lg:px-8 py-6 lg:py-10">
      {/* Breadcrumb */}
      <div className="flex items-center gap-2 text-sm text-muted-foreground mb-6">
        {boardSlug ? (
          <>
            <Link href="/boards">
              <span className="hover:text-foreground ink-link flex items-center gap-1">
                <LayoutGrid size={14} />
                꿈 보드
              </span>
            </Link>
            <ChevronRight size={12} />
            <Link href={`/boards/${boardSlug}`}>
              <span className="hover:text-foreground ink-link">
                {boardContext?.name}
              </span>
            </Link>
            <ChevronRight size={12} />
          </>
        ) : (
          <>
            <Link href="/">
              <span className="hover:text-foreground ink-link">홈</span>
            </Link>
            <ChevronRight size={12} />
          </>
        )}
        <span className="text-foreground font-medium">AI 면접 시뮬레이터</span>
      </div>

      {/* ─── SETUP PHASE ─── */}
      {phase === "setup" && (
        <div>
          {/* Header */}
          <div className="mb-8">
            <div className="flex items-center gap-3 mb-3">
              <div className="w-10 h-10 bg-violet-100 text-violet-600 rounded-lg flex items-center justify-center">
                <Mic size={20} />
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <h1 className="text-2xl font-bold tracking-tight">
                    AI 면접 시뮬레이터
                  </h1>
                  <span className="inline-flex items-center gap-1 px-2 py-0.5 bg-dream/10 text-dream text-[10px] font-bold rounded-full">
                    <Crown size={10} /> Premium
                  </span>
                </div>
                <p className="text-sm text-muted-foreground">
                  실시간 AI 면접관과 연습하고, 종합 피드백을 받으세요
                </p>
              </div>
            </div>
            {/* Premium 무료 체험 안내 */}
            <div className="mt-3 p-3 bg-gradient-to-r from-violet-50 to-dream/5 border border-violet-200/50 rounded-lg flex items-center gap-3">
              <div className="w-8 h-8 bg-violet-100 rounded-full flex items-center justify-center shrink-0">
                <Sparkles size={14} className="text-violet-600" />
              </div>
              <div className="flex-1">
                <p className="text-xs font-semibold">무료 체험 1회 (3문항)</p>
                <p className="text-[10px] text-muted-foreground">각 면접 유형별 1회 무료 체험을 제공합니다. 풀세트(10문항) 이용은 Premium이 필요합니다.</p>
              </div>
              <Link href="/pricing">
                <span className="text-[10px] text-dream font-semibold hover:underline whitespace-nowrap">요금제 보기 →</span>
              </Link>
            </div>
            {boardContext && (
              <div className="mt-2 inline-flex items-center gap-2 px-3 py-1.5 bg-dream/10 text-dream text-xs font-medium rounded-full">
                <Target size={12} />
                <span>
                  "{boardContext.name}" 보드 맥락 — 대학·학과가 자동 반영됩니다
                </span>
              </div>
            )}
          </div>

          {/* Tabs: New / History */}
          <div className="flex gap-1 mb-6 border-b border-border">
            <button
              onClick={() => setShowHistory(false)}
              className={`px-4 py-2.5 text-sm font-medium border-b-2 transition-colors ${
                !showHistory
                  ? "border-dream text-dream"
                  : "border-transparent text-muted-foreground hover:text-foreground"
              }`}
            >
              새 면접 시작
            </button>
            <button
              onClick={() => setShowHistory(true)}
              className={`px-4 py-2.5 text-sm font-medium border-b-2 transition-colors ${
                showHistory
                  ? "border-dream text-dream"
                  : "border-transparent text-muted-foreground hover:text-foreground"
              }`}
            >
              면접 이력
            </button>
          </div>

          {!showHistory ? (
            <>
              {/* Interview Type Selection */}
              <h2 className="text-lg font-semibold mb-4">면접 유형 선택</h2>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-5 mb-8">
                {interviewTypes.map((type) => (
                  <motion.div
                    key={type.id}
                    whileHover={{ y: -4 }}
                    className="bg-card border border-border rounded-xl p-6 cursor-pointer hover:border-violet-300 hover:shadow-md transition-all"
                    onClick={() => startInterview(type.id)}
                  >
                    <div className="text-3xl mb-3">{type.icon}</div>
                    <h3 className="text-lg font-semibold mb-1">
                      {type.label}
                    </h3>
                    <p className="text-sm text-muted-foreground mb-4">
                      {type.description}
                    </p>
                    <div className="flex items-center gap-4 text-xs text-muted-foreground">
                      <span className="flex items-center gap-1">
                        <Clock size={12} />
                        {type.duration}
                      </span>
                      <span className="flex items-center gap-1">
                        <MessageSquare size={12} />
                        {type.questions}문항
                      </span>
                    </div>
                    <div className="mt-4 flex items-center gap-1.5 text-sm text-violet-600 font-medium">
                      <Play size={14} />
                      면접 시작하기
                    </div>
                  </motion.div>
                ))}
              </div>

              {/* Quick Stats */}
              <div className="grid grid-cols-3 gap-4">
                <div className="bg-card border border-border rounded-lg p-4 text-center">
                  <div className="text-2xl font-bold text-dream">12</div>
                  <div className="text-xs text-muted-foreground mt-1">
                    총 면접 횟수
                  </div>
                </div>
                <div className="bg-card border border-border rounded-lg p-4 text-center">
                  <div className="text-2xl font-bold text-emerald-600">78</div>
                  <div className="text-xs text-muted-foreground mt-1">
                    평균 점수
                  </div>
                </div>
                <div className="bg-card border border-border rounded-lg p-4 text-center">
                  <div className="text-2xl font-bold text-violet-600">
                    +12
                  </div>
                  <div className="text-xs text-muted-foreground mt-1">
                    최근 성장
                  </div>
                </div>
              </div>
            </>
          ) : (
            /* History */
            <div className="space-y-3">
              {pastSessions.map((session) => (
                <motion.div
                  key={session.id}
                  whileHover={{ x: 4 }}
                  className="bg-card border border-border rounded-lg p-4 flex items-center gap-4 cursor-pointer hover:border-violet-300 transition-all"
                  onClick={() => {
                    setPhase("feedback");
                  }}
                >
                  <div className="w-12 h-12 rounded-full bg-violet-50 flex items-center justify-center">
                    <span
                      className={`text-lg font-bold ${
                        session.score >= 80
                          ? "text-emerald-600"
                          : session.score >= 70
                          ? "text-amber-600"
                          : "text-red-500"
                      }`}
                    >
                      {session.score}
                    </span>
                  </div>
                  <div className="flex-1">
                    <h4 className="text-sm font-semibold">
                      {session.university}
                    </h4>
                    <div className="flex items-center gap-3 mt-1 text-xs text-muted-foreground">
                      <span>{session.type}</span>
                      <span>{session.questions}문항</span>
                      <span className="flex items-center gap-1">
                        <Clock size={10} />
                        {session.date}
                      </span>
                    </div>
                  </div>
                  <ChevronRight size={16} className="text-muted-foreground" />
                </motion.div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* ─── INTERVIEW PHASE ─── */}
      {phase === "interview" && (
        <div className="max-w-3xl mx-auto">
          {/* Interview Header */}
          <div className="flex items-center justify-between mb-6">
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 bg-violet-100 text-violet-600 rounded-full flex items-center justify-center">
                <Mic size={16} />
              </div>
              <div>
                <h2 className="text-sm font-semibold">
                  {boardContext
                    ? `${boardContext.name} ${typeInfo?.label}`
                    : typeInfo?.label}
                </h2>
                <p className="text-xs text-muted-foreground">
                  질문 {Math.min(questionIndex + 1, (typeInfo?.questions || 5))}/{typeInfo?.questions || 5}
                </p>
              </div>
            </div>
            <button
              onClick={() => {
                setPhase("feedback");
                toast.info("면접을 종료하고 피드백을 확인합니다");
              }}
              className="text-xs text-muted-foreground hover:text-foreground px-3 py-1.5 border border-border rounded-md"
            >
              면접 종료
            </button>
          </div>

          {/* Chat Area */}
          <div className="bg-card border border-border rounded-xl overflow-hidden">
            <div className="h-[500px] overflow-y-auto p-5 space-y-4">
              <AnimatePresence>
                {messages.map((msg, i) => (
                  <motion.div
                    key={i}
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    className={`flex gap-3 ${
                      msg.role === "student" ? "flex-row-reverse" : ""
                    }`}
                  >
                    <div
                      className={`w-8 h-8 rounded-full flex items-center justify-center shrink-0 ${
                        msg.role === "interviewer"
                          ? "bg-violet-100 text-violet-600"
                          : "bg-dream/10 text-dream"
                      }`}
                    >
                      {msg.role === "interviewer" ? (
                        <Bot size={16} />
                      ) : (
                        <User size={16} />
                      )}
                    </div>
                    <div
                      className={`max-w-[75%] px-4 py-3 rounded-2xl text-sm leading-relaxed ${
                        msg.role === "interviewer"
                          ? "bg-secondary text-foreground rounded-tl-sm"
                          : "bg-dream text-white rounded-tr-sm"
                      }`}
                    >
                      {msg.text}
                    </div>
                  </motion.div>
                ))}
              </AnimatePresence>

              {isTyping && (
                <div className="flex gap-3">
                  <div className="w-8 h-8 rounded-full bg-violet-100 text-violet-600 flex items-center justify-center">
                    <Bot size={16} />
                  </div>
                  <div className="bg-secondary px-4 py-3 rounded-2xl rounded-tl-sm">
                    <div className="flex gap-1">
                      <motion.span
                        animate={{ opacity: [0.3, 1, 0.3] }}
                        transition={{ repeat: Infinity, duration: 1.2 }}
                        className="w-2 h-2 bg-muted-foreground rounded-full"
                      />
                      <motion.span
                        animate={{ opacity: [0.3, 1, 0.3] }}
                        transition={{
                          repeat: Infinity,
                          duration: 1.2,
                          delay: 0.2,
                        }}
                        className="w-2 h-2 bg-muted-foreground rounded-full"
                      />
                      <motion.span
                        animate={{ opacity: [0.3, 1, 0.3] }}
                        transition={{
                          repeat: Infinity,
                          duration: 1.2,
                          delay: 0.4,
                        }}
                        className="w-2 h-2 bg-muted-foreground rounded-full"
                      />
                    </div>
                  </div>
                </div>
              )}
              <div ref={chatEndRef} />
            </div>

            {/* Input Area */}
            <div className="border-t border-border p-4">
              <div className="flex items-center gap-2">
                <input
                  type="text"
                  value={inputText}
                  onChange={(e) => setInputText(e.target.value)}
                  onKeyDown={(e) => e.key === "Enter" && sendAnswer()}
                  placeholder="답변을 입력하세요..."
                  className="flex-1 px-4 py-2.5 text-sm border border-border rounded-lg outline-none focus:border-violet-400 bg-transparent"
                />
                <button
                  onClick={sendAnswer}
                  disabled={!inputText.trim()}
                  className="p-2.5 bg-violet-600 text-white rounded-lg hover:bg-violet-700 transition-colors disabled:opacity-40"
                >
                  <Send size={16} />
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ─── FEEDBACK PHASE ─── */}
      {phase === "feedback" && (
        <div className="max-w-4xl mx-auto">
          {/* Back */}
          <button
            onClick={() => {
              setPhase("setup");
              setMessages([]);
            }}
            className="flex items-center gap-1.5 text-sm text-muted-foreground hover:text-foreground mb-6"
          >
            <ArrowLeft size={14} />
            면접 목록으로
          </button>

          {/* Score Hero */}
          <div className="bg-card border border-border rounded-xl p-8 text-center mb-6">
            <div className="w-20 h-20 mx-auto rounded-full bg-gradient-to-br from-violet-100 to-violet-50 flex items-center justify-center mb-4">
              <span className="text-3xl font-bold text-violet-600">
                {mockFeedback.score}
              </span>
            </div>
            <h2 className="text-xl font-bold mb-1">면접 종합 피드백</h2>
            <p className="text-sm text-muted-foreground">
              {boardContext
                ? `${boardContext.name} 심층 면접`
                : "서울대 의예과 심층 면접"}{" "}
              · 5문항 · 약 18분
            </p>
            <div className="flex items-center justify-center gap-1 mt-3">
              {[1, 2, 3, 4, 5].map((s) => (
                <Star
                  key={s}
                  size={18}
                  className={
                    s <= Math.round(mockFeedback.score / 20)
                      ? "text-amber-400 fill-amber-400"
                      : "text-gray-200"
                  }
                />
              ))}
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
            {/* Strengths */}
            <div className="bg-card border border-border rounded-xl p-5">
              <h3 className="flex items-center gap-2 text-sm font-semibold text-emerald-600 mb-4">
                <CheckCircle2 size={16} />
                강점
              </h3>
              <ul className="space-y-3">
                {mockFeedback.strengths.map((s, i) => (
                  <li
                    key={i}
                    className="flex items-start gap-2 text-sm text-muted-foreground"
                  >
                    <span className="text-emerald-400 mt-0.5 shrink-0">✓</span>
                    {s}
                  </li>
                ))}
              </ul>
            </div>

            {/* Weaknesses */}
            <div className="bg-card border border-border rounded-xl p-5">
              <h3 className="flex items-center gap-2 text-sm font-semibold text-amber-600 mb-4">
                <AlertTriangle size={16} />
                개선점
              </h3>
              <ul className="space-y-3">
                {mockFeedback.weaknesses.map((w, i) => (
                  <li
                    key={i}
                    className="flex items-start gap-2 text-sm text-muted-foreground"
                  >
                    <span className="text-amber-400 mt-0.5 shrink-0">!</span>
                    {w}
                  </li>
                ))}
              </ul>
            </div>

            {/* Tips */}
            <div className="md:col-span-2 bg-card border border-border rounded-xl p-5">
              <h3 className="flex items-center gap-2 text-sm font-semibold text-violet-600 mb-4">
                <Lightbulb size={16} />
                맞춤 조언
              </h3>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                {mockFeedback.tips.map((tip, i) => (
                  <div
                    key={i}
                    className="p-3 bg-violet-50/50 border border-violet-100 rounded-lg"
                  >
                    <div className="text-xs font-semibold text-violet-600 mb-1">
                      Tip {i + 1}
                    </div>
                    <p className="text-sm text-muted-foreground">{tip}</p>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Action Buttons */}
          <div className="flex items-center justify-center gap-3 mt-8">
            <button
              onClick={() => {
                setPhase("setup");
                setMessages([]);
              }}
              className="flex items-center gap-1.5 px-5 py-2.5 text-sm border border-border rounded-lg hover:bg-secondary transition-colors"
            >
              <RotateCcw size={14} />
              다시 연습하기
            </button>
            {boardSlug && (
              <Link href={`/boards/${boardSlug}`}>
                <span className="flex items-center gap-1.5 px-5 py-2.5 text-sm bg-dream text-white rounded-lg hover:bg-dream/90 transition-colors">
                  <LayoutGrid size={14} />
                  보드로 돌아가기
                </span>
              </Link>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
